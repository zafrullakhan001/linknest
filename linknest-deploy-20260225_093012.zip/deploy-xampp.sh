﻿#!/usr/bin/env bash
# ==========================================================
#  LinkNest XAMPP / Apache Deployment Script (Linux / macOS)
#  Run this script ONCE on the target computer to deploy.
# ==========================================================
set -euo pipefail

XAMPP_ROOT="${XAMPP_ROOT:-/opt/lampp}"
HTDOCS="$XAMPP_ROOT/htdocs"
INSTALL_DIR="$HTDOCS/linknest"
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo "  ============================================="
echo "     LinkNest - XAMPP Deployment (Linux/macOS)"
echo "  ============================================="
echo ""
echo "  XAMPP root  : $XAMPP_ROOT"
echo "  Install dir : $INSTALL_DIR"
echo ""

if [ ! -d "$HTDOCS" ]; then
    echo "  ERROR: Cannot find $HTDOCS"
    echo "  Set XAMPP_ROOT env var:  XAMPP_ROOT=/path/to/xampp ./deploy-xampp.sh"
    exit 1
fi

if [ -d "$INSTALL_DIR" ]; then
    echo "  Removing old installation..."
    rm -rf "$INSTALL_DIR"
fi
mkdir -p "$INSTALL_DIR"
echo "  [OK] Install directory ready"

echo "  Copying application files..."
cp -r "$PKG_DIR/." "$INSTALL_DIR/"
# Remove the deploy scripts themselves from the install
rm -f "$INSTALL_DIR/deploy-xampp.sh"
rm -f "$INSTALL_DIR/deploy-xampp.bat"
echo "  [OK] Files copied"

echo "  Writing .env for XAMPP sub-directory deployment..."
cat > "$INSTALL_DIR/.env" <<'ENVEOF'
VITE_BASE_PATH=/linknest
VITE_API_BASE=/linknest/api
ENVEOF
echo "  [OK] .env written"

mkdir -p "$INSTALL_DIR/data"
mkdir -p "$INSTALL_DIR/uploads"
mkdir -p "$INSTALL_DIR/logs"

chmod -R 755 "$INSTALL_DIR"
chmod -R 777 "$INSTALL_DIR/data"    2>/dev/null || true
chmod -R 777 "$INSTALL_DIR/uploads" 2>/dev/null || true
chmod -R 777 "$INSTALL_DIR/logs"    2>/dev/null || true
echo "  [OK] Permissions set"

echo ""
echo "  ============================================="
echo "  Deployment Complete!"
echo "  ============================================="
echo ""
echo "  NEXT STEPS:"
echo "  1. Start XAMPP:  sudo $XAMPP_ROOT/manager-linux-x64.run"
echo "  2. Open browser: http://localhost/linknest"
echo "  3. Default login: admin / admin123"
echo "     (Change the password right away!)"
echo ""
