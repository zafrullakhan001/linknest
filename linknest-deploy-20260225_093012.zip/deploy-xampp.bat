@echo off
setlocal enabledelayedexpansion
REM ==========================================================
REM  LinkNest XAMPP Deployment Script (Windows)
REM  Run this script ONCE on the target computer to deploy.
REM ==========================================================
echo.
echo  =============================================
echo     LinkNest - XAMPP Deployment (Windows)
echo  =============================================
echo.

REM ---- Configuration --------------------------------------------------
REM  Change XAMPP_ROOT if your XAMPP is installed elsewhere
set "XAMPP_ROOT=C:\xampp"
set "HTDOCS=%XAMPP_ROOT%\htdocs"
set "INSTALL_DIR=%HTDOCS%\linknest"

echo  XAMPP root  : %XAMPP_ROOT%
echo  Install dir : %INSTALL_DIR%
echo.

REM ---- Verify XAMPP ---------------------------------------------------
if not exist "%HTDOCS%" (
    echo  ERROR: Cannot find %HTDOCS%
    echo  Edit XAMPP_ROOT in this script to match your XAMPP installation.
    pause
    exit /b 1
)

REM ---- Create / wipe install directory --------------------------------
if exist "%INSTALL_DIR%" (
    echo  Removing old installation...
    rd /s /q "%INSTALL_DIR%"
)
mkdir "%INSTALL_DIR%"
echo  [OK] Install directory ready

REM ---- Copy all files from this package -------------------------------
echo  Copying application files...
set "PKG_DIR=%~dp0"
if "%PKG_DIR:~-1%"=="\" set "PKG_DIR=%PKG_DIR:~0,-1%"

xcopy "%PKG_DIR%\api"        "%INSTALL_DIR%\api\"        /E /I /Y >nul 2>&1
xcopy "%PKG_DIR%\components" "%INSTALL_DIR%\components\" /E /I /Y >nul 2>&1
xcopy "%PKG_DIR%\contexts"   "%INSTALL_DIR%\contexts\"   /E /I /Y >nul 2>&1
xcopy "%PKG_DIR%\services"   "%INSTALL_DIR%\services\"   /E /I /Y >nul 2>&1
xcopy "%PKG_DIR%\dist"       "%INSTALL_DIR%\dist\"       /E /I /Y >nul 2>&1
xcopy "%PKG_DIR%\docker"     "%INSTALL_DIR%\docker\"     /E /I /Y >nul 2>&1
xcopy "%PKG_DIR%\data"       "%INSTALL_DIR%\data\"       /E /I /Y >nul 2>&1
xcopy "%PKG_DIR%\uploads"    "%INSTALL_DIR%\uploads\"    /E /I /Y >nul 2>&1
xcopy "%PKG_DIR%\scripts"    "%INSTALL_DIR%\scripts\"    /E /I /Y >nul 2>&1

for %%F in (index.html index.tsx index.css App.tsx types.ts router.php landing.php clones.php backup_restore.php .htaccess package.json vite.config.ts tsconfig.json tailwind.config.js postcss.config.js composer.json sw-cache-first.php metadata.json) do (
    if exist "%PKG_DIR%\%%F" copy /Y "%PKG_DIR%\%%F" "%INSTALL_DIR%\%%F" >nul 2>&1
)

echo  [OK] Files copied

REM ---- Write .env for XAMPP sub-directory deployment ------------------
echo  Writing .env ...
(
echo VITE_BASE_PATH=/linknest
echo VITE_API_BASE=/linknest/api
) > "%INSTALL_DIR%\.env"
echo  [OK] .env written

REM ---- Ensure data/ and uploads/ exist and are writable ---------------
if not exist "%INSTALL_DIR%\data"    mkdir "%INSTALL_DIR%\data"
if not exist "%INSTALL_DIR%\uploads" mkdir "%INSTALL_DIR%\uploads"
if not exist "%INSTALL_DIR%\logs"    mkdir "%INSTALL_DIR%\logs"
echo  [OK] data/, uploads/, logs/ confirmed

echo.
echo  =============================================
echo  Deployment Complete!
echo  =============================================
echo.
echo  NEXT STEPS:
echo  1. Open XAMPP Control Panel
echo  2. Click [Start] next to Apache
echo  3. Open your browser and go to:
echo       http://localhost/linknest
echo  4. Default login: admin / admin123
echo     (Change the password right away!)
echo.
echo  If you see a 404 error, make sure mod_rewrite is enabled.
echo  See DEPLOYMENT_README.md for full troubleshooting.
echo.
pause
