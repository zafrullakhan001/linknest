﻿# LinkNest - Deployment Package

Created : 2026-02-25 09:30:12
Package : linknest-deploy-20260225_093012

---

## What Is Inside

| Path                  | Description                              |
|-----------------------|------------------------------------------|
| api/                  | PHP backend                              |
| components/           | React components (TypeScript)            |
| contexts/             | React contexts                           |
| services/             | Frontend service layer                   |
| dist/                 | Pre-built frontend (ready to serve)      |
| data/linknest.db      | SQLite database (your live data)         |
| uploads/              | User-uploaded files (logos, favicons)    |
| docker/               | Docker / Docker-Compose setup            |
| scripts/              | Helper scripts                           |
| deploy-xampp.bat      | One-click deploy for Windows + XAMPP     |
| deploy-xampp.sh       | One-click deploy for Linux/macOS + XAMPP |

---

## Quick Deploy on XAMPP (Recommended)

### Windows
1. Extract this ZIP anywhere (e.g. Desktop).
2. Double-click **deploy-xampp.bat**.
3. Start XAMPP and click Start next to Apache.
4. Open http://localhost/linknest in your browser.

### Linux / macOS
    chmod +x deploy-xampp.sh
    ./deploy-xampp.sh

Then start XAMPP and open http://localhost/linknest.

---

## Requirements on Target Computer

- XAMPP (Apache + PHP 8.1+) - https://www.apachefriends.org
- PHP Extensions (pre-installed with XAMPP): pdo_sqlite, sqlite3, json, mbstring, openssl

Node.js / npm are NOT required - the frontend is pre-built (dist/ is included).

---

## Database

The package includes data/linknest.db (your live SQLite database).
It will be used automatically on the new machine. No import steps needed.

---

## Default Credentials

Username : admin
Password : admin123

IMPORTANT: Change the admin password immediately after logging in!

---

## Troubleshooting

| Problem               | Fix                                                      |
|-----------------------|----------------------------------------------------------|
| Blank page / 404      | Make sure Apache is started in XAMPP                     |
| API errors            | Check that mod_rewrite is enabled in XAMPP               |
| Database errors       | Ensure data/ folder is writeable by Apache (chmod 777)   |
| Uploads missing       | Check uploads/ folder permissions                        |
| White screen          | Clear browser cache (Ctrl+Shift+R)                       |

For mod_rewrite on XAMPP Windows:
Open C:\xampp\apache\conf\httpd.conf and make sure AllowOverride All
is set for the htdocs directory, then restart Apache.

---

## Re-building the Frontend (Optional)

If you want to rebuild the frontend on the target machine (not usually needed):

    npm install
    npm run build
