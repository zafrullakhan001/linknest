-- Migration to add is_temp column to tile_versions table
-- This allows tracking temporary versions created when editing starts

-- Add is_temp column if it doesn't exist
ALTER TABLE tile_versions ADD COLUMN is_temp INTEGER DEFAULT 0;

-- Clean up any orphaned temp versions (shouldn't exist but just in case)
DELETE FROM tile_versions WHERE is_temp = 1;
