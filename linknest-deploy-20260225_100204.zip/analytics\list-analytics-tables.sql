-- List all tables and views in the analytics database (linknest_analytics)
-- Run: psql -h localhost -p 5433 -U postgres -d linknest_analytics -f list-analytics-tables.sql
-- Or from psql: \i list-analytics-tables.sql

-- All relation types: tables, views, materialized views
SELECT
    n.nspname AS schema_name,
    c.relname AS name,
    CASE c.relkind
        WHEN 'r' THEN 'table'
        WHEN 'v' THEN 'view'
        WHEN 'm' THEN 'materialized view'
        WHEN 'f' THEN 'foreign table'
        ELSE c.relkind::text
    END AS type
FROM pg_catalog.pg_class c
JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname NOT IN ('pg_catalog', 'information_schema')
  AND n.nspname !~ '^pg_toast'
  AND c.relkind IN ('r', 'v', 'm')
ORDER BY
    CASE c.relkind WHEN 'r' THEN 1 WHEN 'm' THEN 2 WHEN 'v' THEN 3 ELSE 4 END,
    n.nspname,
    c.relname;
