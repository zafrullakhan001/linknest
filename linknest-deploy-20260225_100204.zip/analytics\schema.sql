-- Performance Analytics Add-on Database Schema
-- PostgreSQL + TimescaleDB
-- Run with: psql -h localhost -p 5433 -U postgres -d linknest_analytics -f schema.sql

-- Enable TimescaleDB extension
CREATE EXTENSION IF NOT EXISTS timescaledb;

-- Metrics Queue Table (fast inserts, processed by worker)
CREATE TABLE IF NOT EXISTS metrics_queue (
    id BIGSERIAL PRIMARY KEY,
    payload JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    processed BOOLEAN DEFAULT FALSE,
    processed_at TIMESTAMPTZ
);

-- Index for fast worker queries
CREATE INDEX IF NOT EXISTS idx_metrics_queue_unprocessed 
ON metrics_queue(created_at) 
WHERE processed = FALSE;

-- Performance Metrics Table (TimescaleDB Hypertable)
CREATE TABLE IF NOT EXISTS performance_metrics (
    time TIMESTAMPTZ NOT NULL,
    
    -- URL context
    link_url TEXT NOT NULL,
    link_id TEXT,
    page_url TEXT,
    
    -- Measurement type
    measurement_type TEXT NOT NULL CHECK (measurement_type IN ('client', 'server')),
    
    -- User context
    user_id INTEGER,
    username VARCHAR(255),
    session_id VARCHAR(100),
    is_authenticated BOOLEAN DEFAULT FALSE,
    
    -- Geographic data
    ip_address INET,
    continent_code CHAR(2),
    country_code CHAR(2),
    country_name VARCHAR(100),
    region_name VARCHAR(100),
    city_name VARCHAR(100),
    latitude NUMERIC(9,6),
    longitude NUMERIC(9,6),
    timezone VARCHAR(50),
    isp VARCHAR(200),
    
    -- Performance timing metrics (all in milliseconds)
    dns_lookup_time INTEGER,
    tcp_connection_time INTEGER,
    tls_handshake_time INTEGER,
    time_to_first_byte INTEGER,
    dom_content_loaded_time INTEGER,
    full_response_time INTEGER NOT NULL,
    
    -- Additional context
    page_size_bytes INTEGER,
    http_status_code INTEGER,
    error_message TEXT,
    connection_type VARCHAR(50),
    device_type VARCHAR(50),
    browser_name VARCHAR(100),
    browser_version VARCHAR(50),
    os_name VARCHAR(100),
    screen_resolution VARCHAR(50),
    
    -- Metadata
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Convert to TimescaleDB hypertable (partitioned by time)
SELECT create_hypertable('performance_metrics', 'time', if_not_exists => TRUE);

-- Create compression policy (compress data older than 7 days)
ALTER TABLE performance_metrics SET (
    timescaledb.compress,
    timescaledb.compress_segmentby = 'link_url, country_code, region_name, measurement_type'
);

SELECT add_compression_policy('performance_metrics', INTERVAL '7 days', if_not_exists => TRUE);

-- Create retention policy (delete data older than 90 days)
SELECT add_retention_policy('performance_metrics', INTERVAL '90 days', if_not_exists => TRUE);

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_perf_url_time ON performance_metrics (link_url, time DESC);
CREATE INDEX IF NOT EXISTS idx_perf_region_time ON performance_metrics (country_code, region_name, time DESC);
CREATE INDEX IF NOT EXISTS idx_perf_user_time ON performance_metrics (user_id, time DESC) WHERE user_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_perf_username_time ON performance_metrics (username, time DESC) WHERE username IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_perf_ip_time ON performance_metrics (ip_address, time DESC) WHERE ip_address IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_perf_anonymous ON performance_metrics (ip_address, time DESC) WHERE is_authenticated = FALSE;
CREATE INDEX IF NOT EXISTS idx_perf_measurement_type ON performance_metrics (measurement_type, time DESC);

-- Link Latency Summary Table (real-time summary for quick UI display)
CREATE TABLE IF NOT EXISTS link_latency_summary (
    link_url TEXT PRIMARY KEY,
    link_id TEXT,
    
    -- Client-side metrics
    last_client_check TIMESTAMPTZ,
    client_avg_latency INTEGER,
    client_p50_latency INTEGER,
    client_p95_latency INTEGER,
    client_p99_latency INTEGER,
    client_min_latency INTEGER,
    client_max_latency INTEGER,
    client_measurement_count INTEGER DEFAULT 0,
    
    -- Server-side metrics
    last_server_check TIMESTAMPTZ,
    server_avg_latency INTEGER,
    server_p50_latency INTEGER,
    server_p95_latency INTEGER,
    server_p99_latency INTEGER,
    server_min_latency INTEGER,
    server_max_latency INTEGER,
    server_measurement_count INTEGER DEFAULT 0,
    
    -- Geographic context (from most recent client measurement)
    client_country_code CHAR(2),
    client_region_name VARCHAR(100),
    client_city_name VARCHAR(100),
    
    -- Delta and health
    latency_delta INTEGER, -- client_avg - server_avg
    performance_ratio NUMERIC(5,2), -- client_avg / server_avg
    health_status VARCHAR(20) CHECK (health_status IN ('excellent', 'good', 'degraded', 'poor', 'unknown')),
    
    -- Metadata
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_summary_health ON link_latency_summary(health_status);
CREATE INDEX IF NOT EXISTS idx_summary_delta ON link_latency_summary(latency_delta DESC);

-- User Geolocation Tracking (one row per user, updated on login/location change)
CREATE TABLE IF NOT EXISTS user_geolocations (
    id BIGSERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL UNIQUE,
    username VARCHAR(255),
    
    -- Login timestamp
    login_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Geographic data
    ip_address INET NOT NULL,
    continent_code CHAR(2),
    country_code CHAR(2),
    country_name VARCHAR(100),
    region_name VARCHAR(100),
    city_name VARCHAR(100),
    latitude NUMERIC(9,6),
    longitude NUMERIC(9,6),
    timezone VARCHAR(50),
    isp VARCHAR(200),
    
    -- Session context
    session_id VARCHAR(100),
    user_agent TEXT,
    device_type VARCHAR(50),
    browser_name VARCHAR(100),
    os_name VARCHAR(100),
    
    -- For tracking user movement patterns
    is_new_location BOOLEAN DEFAULT TRUE,
    
    -- Last seen (for upsert-style updates when using ON CONFLICT (user_id))
    last_seen TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_user_geo_user_time ON user_geolocations(user_id, login_time DESC);
CREATE INDEX IF NOT EXISTS idx_user_geo_location ON user_geolocations(country_code, region_name, city_name);
CREATE INDEX IF NOT EXISTS idx_user_geo_time ON user_geolocations(login_time DESC);

-- View for user's current/last known location
CREATE OR REPLACE VIEW user_current_location AS
SELECT DISTINCT ON (user_id)
    user_id,
    username,
    login_time,
    country_name,
    region_name,
    city_name,
    latitude,
    longitude,
    timezone
FROM user_geolocations
ORDER BY user_id, login_time DESC;

-- Alert Thresholds Configuration
CREATE TABLE IF NOT EXISTS alert_thresholds (
    id SERIAL PRIMARY KEY,
    link_url TEXT,
    country_code CHAR(2),
    region_name VARCHAR(100),
    
    -- Threshold type
    threshold_type VARCHAR(20) CHECK (threshold_type IN ('client', 'server', 'delta')),
    
    -- Thresholds (milliseconds)
    max_avg_latency INTEGER DEFAULT 3000,
    max_p95_latency INTEGER DEFAULT 5000,
    max_p99_latency INTEGER DEFAULT 10000,
    max_ttfb INTEGER DEFAULT 1000,
    max_delta_ms INTEGER, -- Alert if client-server diff exceeds this
    
    -- Alert settings
    alert_email TEXT[],
    is_enabled BOOLEAN DEFAULT TRUE,
    
    -- Metadata
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_thresholds_enabled ON alert_thresholds(is_enabled) WHERE is_enabled = TRUE;

-- Continuous Aggregate: Hourly Performance by Region
CREATE MATERIALIZED VIEW IF NOT EXISTS performance_by_region_hourly
WITH (timescaledb.continuous) AS
SELECT 
    -- Time bucket
    time_bucket('1 hour', time) AS bucket,
    
    -- URL and measurement context
    link_url,
    measurement_type,
    
    -- Geographic grouping
    country_code,
    country_name,
    region_name,
    
    -- Calculate average geo-coordinates for positioning
    AVG(latitude) as region_center_lat,
    AVG(longitude) as region_center_lon,
    
    -- Request volume
    COUNT(*) as measurement_count,
    COUNT(DISTINCT user_id) as unique_users,
    COUNT(DISTINCT session_id) as unique_sessions,
    COUNT(*) FILTER (WHERE is_authenticated) as authenticated_count,
    
    -- Latency statistics (milliseconds)
    ROUND(AVG(full_response_time)) as avg_latency,
    ROUND(PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY full_response_time)) as p50_latency,
    ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY full_response_time)) as p95_latency,
    ROUND(PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY full_response_time)) as p99_latency,
    MIN(full_response_time) as min_latency,
    MAX(full_response_time) as max_latency,
    
    -- Network timing breakdown
    ROUND(AVG(dns_lookup_time)) as avg_dns_time,
    ROUND(AVG(tcp_connection_time)) as avg_tcp_time,
    ROUND(AVG(tls_handshake_time)) as avg_tls_time,
    ROUND(AVG(time_to_first_byte)) as avg_ttfb,
    
    -- Connection analysis
    COUNT(*) FILTER (WHERE connection_type = 'wifi') as wifi_count,
    COUNT(*) FILTER (WHERE connection_type = '4g') as mobile_4g_count,
    COUNT(*) FILTER (WHERE connection_type = '5g') as mobile_5g_count,
    
    -- Device breakdown
    COUNT(*) FILTER (WHERE device_type = 'mobile') as mobile_count,
    COUNT(*) FILTER (WHERE device_type = 'desktop') as desktop_count,
    COUNT(*) FILTER (WHERE device_type = 'tablet') as tablet_count,
    
    -- Success rate
    COUNT(*) FILTER (WHERE http_status_code >= 200 AND http_status_code < 400) as successful_requests,
    ROUND(
        (COUNT(*) FILTER (WHERE http_status_code >= 200 AND http_status_code < 400)::numeric / 
        NULLIF(COUNT(*), 0) * 100)::numeric, 
        1
    ) as success_rate_pct
    
FROM performance_metrics
GROUP BY bucket, link_url, measurement_type, country_code, country_name, region_name
WITH NO DATA;

-- Refresh policy (update every 30 minutes)
SELECT add_continuous_aggregate_policy('performance_by_region_hourly',
    start_offset => INTERVAL '3 hours',
    end_offset => INTERVAL '30 minutes',
    schedule_interval => INTERVAL '30 minutes',
    if_not_exists => TRUE
);

-- View: Performance Alerts (current violations)
CREATE OR REPLACE VIEW performance_alerts AS
SELECT 
    p.bucket as time_period,
    p.link_url,
    p.country_name,
    p.region_name,
    p.measurement_type,
    p.avg_latency,
    p.p95_latency,
    p.p99_latency,
    p.avg_ttfb,
    t.max_avg_latency as threshold_avg,
    t.max_p95_latency as threshold_p95,
    t.max_ttfb as threshold_ttfb,
    
    -- Violation indicators
    (p.avg_latency > t.max_avg_latency) as avg_exceeded,
    (p.p95_latency > t.max_p95_latency) as p95_exceeded,
    (p.avg_ttfb > t.max_ttfb) as ttfb_exceeded,
    
    -- Severity calculation
    CASE 
        WHEN p.p95_latency > t.max_p95_latency * 2 THEN 'critical'
        WHEN p.p95_latency > t.max_p95_latency THEN 'warning'
        ELSE 'ok'
    END as severity,
    
    t.alert_email
FROM performance_by_region_hourly p
INNER JOIN alert_thresholds t ON 
    (t.link_url IS NULL OR t.link_url = p.link_url) AND
    (t.country_code IS NULL OR t.country_code = p.country_code) AND
    (t.region_name IS NULL OR t.region_name = p.region_name)
WHERE 
    t.is_enabled = TRUE
    AND p.bucket >= NOW() - INTERVAL '24 hours'
    AND (
        p.avg_latency > t.max_avg_latency OR
        p.p95_latency > t.max_p95_latency OR
        p.avg_ttfb > t.max_ttfb
    )
ORDER BY p.bucket DESC, severity DESC;

-- Function to update link_latency_summary after new measurements
CREATE OR REPLACE FUNCTION update_link_latency_summary()
RETURNS TRIGGER AS $$
BEGIN
    -- Insert or update summary for this link
    INSERT INTO link_latency_summary (
        link_url,
        link_id,
        last_client_check,
        client_avg_latency,
        client_measurement_count,
        last_server_check,
        server_avg_latency,
        server_measurement_count,
        updated_at
    )
    SELECT
        NEW.link_url,
        NEW.link_id,
        CASE WHEN NEW.measurement_type = 'client' THEN NEW.time ELSE NULL END,
        CASE WHEN NEW.measurement_type = 'client' THEN NEW.full_response_time ELSE NULL END,
        CASE WHEN NEW.measurement_type = 'client' THEN 1 ELSE 0 END,
        CASE WHEN NEW.measurement_type = 'server' THEN NEW.time ELSE NULL END,
        CASE WHEN NEW.measurement_type = 'server' THEN NEW.full_response_time ELSE NULL END,
        CASE WHEN NEW.measurement_type = 'server' THEN 1 ELSE 0 END,
        NOW()
    ON CONFLICT (link_url) DO UPDATE SET
        -- Update client metrics if this is a client measurement
        last_client_check = CASE 
            WHEN NEW.measurement_type = 'client' THEN NEW.time 
            ELSE link_latency_summary.last_client_check 
        END,
        client_avg_latency = CASE 
            WHEN NEW.measurement_type = 'client' THEN 
                ROUND((COALESCE(link_latency_summary.client_avg_latency, 0) * link_latency_summary.client_measurement_count + NEW.full_response_time) / 
                      (link_latency_summary.client_measurement_count + 1))
            ELSE link_latency_summary.client_avg_latency 
        END,
        client_measurement_count = CASE 
            WHEN NEW.measurement_type = 'client' THEN link_latency_summary.client_measurement_count + 1 
            ELSE link_latency_summary.client_measurement_count 
        END,
        -- Update server metrics if this is a server measurement
        last_server_check = CASE 
            WHEN NEW.measurement_type = 'server' THEN NEW.time 
            ELSE link_latency_summary.last_server_check 
        END,
        server_avg_latency = CASE 
            WHEN NEW.measurement_type = 'server' THEN 
                ROUND((COALESCE(link_latency_summary.server_avg_latency, 0) * link_latency_summary.server_measurement_count + NEW.full_response_time) / 
                      (link_latency_summary.server_measurement_count + 1))
            ELSE link_latency_summary.server_avg_latency 
        END,
        server_measurement_count = CASE 
            WHEN NEW.measurement_type = 'server' THEN link_latency_summary.server_measurement_count + 1 
            ELSE link_latency_summary.server_measurement_count 
        END,
        -- Update geographic context from client measurements
        client_country_code = CASE 
            WHEN NEW.measurement_type = 'client' THEN NEW.country_code 
            ELSE link_latency_summary.client_country_code 
        END,
        client_region_name = CASE 
            WHEN NEW.measurement_type = 'client' THEN NEW.region_name 
            ELSE link_latency_summary.client_region_name 
        END,
        client_city_name = CASE 
            WHEN NEW.measurement_type = 'client' THEN NEW.city_name 
            ELSE link_latency_summary.client_city_name 
        END,
        -- Calculate delta and health status
        latency_delta = COALESCE(
            CASE WHEN NEW.measurement_type = 'client' THEN NEW.full_response_time ELSE link_latency_summary.client_avg_latency END
            - 
            CASE WHEN NEW.measurement_type = 'server' THEN NEW.full_response_time ELSE link_latency_summary.server_avg_latency END,
            0
        ),
        health_status = CASE
            WHEN COALESCE(link_latency_summary.client_avg_latency, NEW.full_response_time) < 100 THEN 'excellent'
            WHEN COALESCE(link_latency_summary.client_avg_latency, NEW.full_response_time) < 300 THEN 'good'
            WHEN COALESCE(link_latency_summary.client_avg_latency, NEW.full_response_time) < 1000 THEN 'degraded'
            ELSE 'poor'
        END,
        updated_at = NOW();
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update summary on new measurements
DROP TRIGGER IF EXISTS trg_update_link_summary ON performance_metrics;
CREATE TRIGGER trg_update_link_summary
    AFTER INSERT ON performance_metrics
    FOR EACH ROW
    EXECUTE FUNCTION update_link_latency_summary();

-- =============================================================================
-- Geo location lookup table (for offline reverse geocoding)
-- =============================================================================
CREATE TABLE IF NOT EXISTS location_lookup (
    id SERIAL PRIMARY KEY,
    country_code VARCHAR(2) NOT NULL,
    country_name VARCHAR(100) NOT NULL,
    region_name VARCHAR(100),
    city_name VARCHAR(100),
    latitude NUMERIC(10, 7) NOT NULL,
    longitude NUMERIC(10, 7) NOT NULL,
    population INTEGER,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_location_lookup_coords
    ON location_lookup(latitude, longitude);
CREATE INDEX IF NOT EXISTS idx_location_lookup_country
    ON location_lookup(country_code);

-- Optional: unique constraint for (country_code, region_name, city_name, lat, lon)
-- Used by import scripts to avoid duplicate cities
CREATE UNIQUE INDEX IF NOT EXISTS idx_location_lookup_unique_city
    ON location_lookup(country_code, region_name, city_name, latitude, longitude);

-- Grant permissions (adjust username as needed)
-- GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO your_user;
-- GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO your_user;

-- Success message
DO $$
BEGIN
    RAISE NOTICE 'Performance Analytics schema created successfully!';
    RAISE NOTICE 'Tables created: metrics_queue, performance_metrics (hypertable), link_latency_summary, user_geolocations, alert_thresholds, location_lookup';
    RAISE NOTICE 'Views created: user_current_location, performance_alerts';
    RAISE NOTICE 'Continuous aggregate created: performance_by_region_hourly';
    RAISE NOTICE 'Compression policy: 7 days';
    RAISE NOTICE 'Retention policy: 90 days';
END $$;
