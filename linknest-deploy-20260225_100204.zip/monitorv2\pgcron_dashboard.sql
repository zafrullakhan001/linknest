-- Monitorv2 Dashboard: pg_cron jobs that run in zmonitoring.
-- Run this script in linknest_analytics (the database set in cron.database_name).
-- Jobs are scheduled with cron.schedule_in_database(..., 'zmonitoring', ...) so the SQL runs in zmonitoring.
--
-- Prerequisites:
--   1. pg_cron is installed in linknest_analytics (cron.database_name = linknest_analytics in postgresql.conf).
--   2. Run pgcron_dashboard_views.sql in zmonitoring first (creates the dashboard views there).
--
-- Usage:
--   psql -h localhost -p 5433 -U postgres -d linknest_analytics -f monitorv2/pgcron_dashboard.sql

-- ============================================
-- 1. CREATE EXTENSION (in linknest_analytics; skip if already created)
-- ============================================
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- ============================================
-- 2. PG_CRON JOBS (scheduled here, run in zmonitoring)
-- ============================================
-- Remove existing jobs so this script is idempotent
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'zmonitoring_every_minute') THEN
        PERFORM cron.unschedule('zmonitoring_every_minute');
    END IF;
    IF EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'zmonitoring_aggregate_hourly') THEN
        PERFORM cron.unschedule('zmonitoring_aggregate_hourly');
    END IF;
    IF EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'zmonitoring_cleanup_old_data') THEN
        PERFORM cron.unschedule('zmonitoring_cleanup_old_data');
    END IF;
END $$;

-- Run every minute in zmonitoring: request monitor checks (app endpoint run-scheduled-checks processes these)
SELECT cron.schedule_in_database(
    'zmonitoring_every_minute',
    '* * * * *',
    $$INSERT INTO zmonitoring.cron_trigger (action, requested_at) VALUES ('run_monitor_checks', NOW())$$,
    'zmonitoring',
    'postgres',
    true
);

-- Run hourly in zmonitoring: aggregate monitor_checks into monitor_hourly_stats (previous hour)
SELECT cron.schedule_in_database(
    'zmonitoring_aggregate_hourly',
    '0 * * * *',
    $$SELECT zmonitoring.aggregate_hourly_stats(date_trunc('hour', NOW() - INTERVAL '1 hour'))$$,
    'zmonitoring',
    'postgres',
    true
);

-- Run daily at 02:00 in zmonitoring: cleanup old checks (90 days), notification logs (365 days), old hourly stats
SELECT cron.schedule_in_database(
    'zmonitoring_cleanup_old_data',
    '0 2 * * *',
    $$SELECT * FROM zmonitoring.cleanup_old_data(90, 365)$$,
    'zmonitoring',
    'postgres',
    true
);

-- ============================================
-- 3. VERIFY
-- ============================================
-- List scheduled jobs (run in linknest_analytics):
--   SELECT jobid, jobname, schedule, command, database FROM cron.job ORDER BY jobname;
-- Query dashboard (run in zmonitoring):
--   SELECT * FROM zmonitoring.v_dashboard_summary;
--   SELECT * FROM zmonitoring.v_dashboard_monitors;
--   SELECT * FROM zmonitoring.v_dashboard_recent_checks ORDER BY checked_at DESC LIMIT 50;
