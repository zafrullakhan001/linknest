-- Add link-level analytics columns to performance_metrics (client payload extensions)
-- This enables dashboards from the "link perspective": latency, errors, and grouping by tile/link.

-- Context identifiers (from LinkNest)
ALTER TABLE performance_metrics
  ADD COLUMN IF NOT EXISTS tile_id TEXT,
  ADD COLUMN IF NOT EXISTS link_id TEXT,
  ADD COLUMN IF NOT EXISTS link_url_normalized TEXT;

-- Result classification (client-side best effort)
ALTER TABLE performance_metrics
  ADD COLUMN IF NOT EXISTS ok BOOLEAN,
  ADD COLUMN IF NOT EXISTS error_category TEXT,
  ADD COLUMN IF NOT EXISTS response_type TEXT,
  ADD COLUMN IF NOT EXISTS redirected BOOLEAN,
  ADD COLUMN IF NOT EXISTS final_url TEXT;

-- Request metadata
ALTER TABLE performance_metrics
  ADD COLUMN IF NOT EXISTS method TEXT,
  ADD COLUMN IF NOT EXISTS cache_mode TEXT,
  ADD COLUMN IF NOT EXISTS timeout_ms INTEGER,
  ADD COLUMN IF NOT EXISTS attempted_at BIGINT;

-- Useful indexes for dashboards (safe to run multiple times)
CREATE INDEX IF NOT EXISTS idx_perf_tile_time
  ON performance_metrics (tile_id, time DESC)
  WHERE tile_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_perf_link_time
  ON performance_metrics (link_id, time DESC)
  WHERE link_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_perf_normurl_time
  ON performance_metrics (link_url_normalized, time DESC)
  WHERE link_url_normalized IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_perf_error_category_time
  ON performance_metrics (error_category, time DESC)
  WHERE error_category IS NOT NULL;

-- Documentation
COMMENT ON COLUMN performance_metrics.tile_id IS 'LinkNest tile id (TEXT). Enables per-tile performance dashboards.';
COMMENT ON COLUMN performance_metrics.link_id IS 'LinkNest link id (TEXT). Enables per-link performance dashboards.';
COMMENT ON COLUMN performance_metrics.link_url_normalized IS 'Normalized URL for grouping (query+fragment stripped, host lowercased).';
COMMENT ON COLUMN performance_metrics.ok IS 'Client-side best-effort success flag (true when fetch resolved, false when it threw).';
COMMENT ON COLUMN performance_metrics.error_category IS 'Client-side error category (e.g., timeout, network, cors_opaque, invalid_url).';
COMMENT ON COLUMN performance_metrics.response_type IS 'Fetch response type when available (basic/cors/opaque/error).';
COMMENT ON COLUMN performance_metrics.redirected IS 'Fetch redirected flag when available.';
COMMENT ON COLUMN performance_metrics.final_url IS 'Final response URL when available (often null for opaque).';
COMMENT ON COLUMN performance_metrics.method IS 'HTTP method used for measurement (usually HEAD).';
COMMENT ON COLUMN performance_metrics.cache_mode IS 'Fetch cache mode used for measurement (e.g., no-store).';
COMMENT ON COLUMN performance_metrics.timeout_ms IS 'Client-side timeout threshold for the measurement.';
COMMENT ON COLUMN performance_metrics.attempted_at IS 'Client epoch-ms timestamp when measurement started.';

DO $$
BEGIN
  RAISE NOTICE 'Successfully added link-level analytics columns to performance_metrics';
END $$;

