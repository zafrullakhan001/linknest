-- Monitorv2 Dashboard: VIEWs + cron trigger table (run in zmonitoring).
-- Prerequisite: schema (monitorv2/schema.sql) must exist in zmonitoring.
--
-- Usage:
--   psql -h localhost -p 5433 -U postgres -d zmonitoring -f monitorv2/pgcron_dashboard_views.sql

-- Table: pg_cron inserts a row here every minute; app endpoint run-scheduled-checks processes and runs monitor checks
CREATE TABLE IF NOT EXISTS zmonitoring.cron_trigger (
    id BIGSERIAL PRIMARY KEY,
    action TEXT NOT NULL DEFAULT 'run_monitor_checks',
    requested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    processed_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_cron_trigger_unprocessed ON zmonitoring.cron_trigger (processed_at) WHERE processed_at IS NULL;

-- One-row summary: total monitors, up/down/warning counts, checks in last 24h
CREATE OR REPLACE VIEW zmonitoring.v_dashboard_summary AS
SELECT
    (SELECT COUNT(*) FROM zmonitoring.monitors) AS total_monitors,
    (SELECT COUNT(*) FROM zmonitoring.monitors WHERE is_active = TRUE AND current_status = 'up') AS up,
    (SELECT COUNT(*) FROM zmonitoring.monitors WHERE is_active = TRUE AND current_status = 'down') AS down,
    (SELECT COUNT(*) FROM zmonitoring.monitors WHERE is_active = TRUE AND current_status = 'warning') AS warning,
    (SELECT COUNT(*) FROM zmonitoring.monitors WHERE is_active = TRUE AND (current_status IS NULL OR current_status NOT IN ('up','down','warning'))) AS unknown,
    (SELECT COUNT(*) FROM zmonitoring.monitor_checks WHERE checked_at >= NOW() - INTERVAL '24 hours') AS checks_24h;

-- Monitor list for dashboard (same columns as Python). Order by tab_name, group_name, name when selecting.
CREATE OR REPLACE VIEW zmonitoring.v_dashboard_monitors AS
SELECT
    id, name, type, target, current_status, last_checked_at,
    last_response_time_ms, uptime_percentage, is_active,
    tab_name, group_name, interval_minutes
FROM zmonitoring.monitors;

-- Recent checks with monitor name (caller should ORDER BY checked_at DESC LIMIT 50)
CREATE OR REPLACE VIEW zmonitoring.v_dashboard_recent_checks AS
SELECT
    c.id,
    c.monitor_id,
    m.name AS monitor_name,
    c.status,
    c.response_time_ms,
    c.checked_at,
    c.details
FROM zmonitoring.monitor_checks c
JOIN zmonitoring.monitors m ON m.id = c.monitor_id;
