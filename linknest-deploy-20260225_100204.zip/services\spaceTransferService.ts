import { Tile, LinkSection, Link } from '../types';

export type SpaceExportType = 'tile' | 'category' | 'all_categories';

export interface SpaceExportFile {
  version: '1.2'; // Includes all current fields: decorations, messages, allowedGroups, link richTextContent, section/tab positions, etc.
  type: SpaceExportType;
  exportedAt: number;
  tile?: Tile;
  tiles?: Tile[];
  categoryName?: string;
  categories?: string[];
}

export interface ParsedSpaceImport {
  type: SpaceExportType;
  tiles: Tile[];
  categoryName?: string;
  categories?: string[];
}

// Simple ID generator for imported items (client-side only)
const generateId = () => Math.random().toString(36).substring(2, 11);

const slugify = (value: string) =>
  value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 50) || 'space';

const triggerDownload = (data: unknown, filename: string) => {
  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: 'application/json;charset=utf-8' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.URL.revokeObjectURL(url);
};

/** Export a single space/tile to a JSON file */
export const exportTileToFile = (tile: Tile) => {
  const payload: SpaceExportFile = {
    version: '1.2',
    type: 'tile',
    exportedAt: Date.now(),
    tile
  };

  const filename = `linknest-space-${slugify(tile.title)}.json`;
  triggerDownload(payload, filename);
};

/** Export all tiles in a category (group) to a JSON file */
export const exportCategoryToFile = (categoryName: string, tiles: Tile[]) => {
  const categoryTiles = tiles.filter(
    (t) => (t.group || 'General') === categoryName
  );

  if (categoryTiles.length === 0) {
    alert(`No spaces found in category "${categoryName}".`);
    return;
  }

  const payload: SpaceExportFile = {
    version: '1.2',
    type: 'category',
    exportedAt: Date.now(),
    categoryName,
    tiles: categoryTiles
  };

  const filename = `linknest-category-${slugify(categoryName)}.json`;
  triggerDownload(payload, filename);
};

/** Export all spaces (all categories) to a JSON file */
export const exportAllCategoriesToFile = (tiles: Tile[], categoryOrder: string[] | undefined) => {
  if (!tiles.length) {
    alert('No spaces to export.');
    return;
  }

  // Derive categories from tiles, preserving the provided order if any
  const categoriesFromTiles = Array.from(
    new Set(tiles.map((t) => t.group || 'General'))
  );

  let categories: string[];
  if (categoryOrder && categoryOrder.length > 0) {
    const seen = new Set<string>();
    const ordered: string[] = [];
    categoryOrder.forEach((cat) => {
      if (categoriesFromTiles.includes(cat) && !seen.has(cat)) {
        ordered.push(cat);
        seen.add(cat);
      }
    });
    categoriesFromTiles.forEach((cat) => {
      if (!seen.has(cat)) {
        ordered.push(cat);
        seen.add(cat);
      }
    });
    categories = ordered;
  } else {
    categories = categoriesFromTiles;
  }

  const payload: SpaceExportFile = {
    version: '1.2',
    type: 'all_categories',
    exportedAt: Date.now(),
    tiles,
    categories
  };

  const filename = 'linknest-spaces-all-categories.json';
  triggerDownload(payload, filename);
};

/** Parse and lightly validate an imported JSON object */
export const parseSpaceExportObject = (data: any): ParsedSpaceImport => {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid file: expected a JSON object.');
  }

  // Support 1.0, 1.1, and 1.2 for backward compatibility
  if (data.version !== '1.0' && data.version !== '1.1' && data.version !== '1.2') {
    console.warn('Unknown space export version, proceeding anyway:', data.version);
  }

  const type: SpaceExportType = data.type;
  if (type !== 'tile' && type !== 'category' && type !== 'all_categories') {
    throw new Error('Invalid export type. Expected "tile", "category", or "all_categories".');
  }

  let tiles: Tile[] = [];
  if (type === 'tile') {
    if (!data.tile || typeof data.tile !== 'object') {
      throw new Error('Invalid tile export: missing "tile" object.');
    }
    tiles = [data.tile as Tile];
  } else {
    if (!Array.isArray(data.tiles)) {
      throw new Error('Invalid export: missing "tiles" array.');
    }
    tiles = data.tiles as Tile[];
  }

  const categoryName: string | undefined =
    typeof data.categoryName === 'string' ? data.categoryName : undefined;

  const categories: string[] | undefined = Array.isArray(data.categories)
    ? data.categories.filter((c: unknown) => typeof c === 'string')
    : undefined;

  return { type, tiles, categoryName, categories };
};

/** Create fresh Tile objects from imported data with new IDs to avoid collisions */
export const normalizeImportedTiles = (
  parsed: ParsedSpaceImport
): Tile[] => {
  const now = Date.now();

  const normalized: Tile[] = parsed.tiles.map((src, index) => {
    const baseGroup =
      (src.group && typeof src.group === 'string'
        ? src.group
        : parsed.categoryName) || 'Imported';

    // Handle tabs structure (new structure)
    const tabs = Array.isArray(src.tabs) && src.tabs.length > 0
      ? src.tabs.map((tab: any) => ({
          id: generateId(),
          title: String(tab.title || 'New Tab'),
          position: typeof tab.position === 'number' ? tab.position : 0,
          textColor: typeof tab.textColor === 'string' ? tab.textColor : undefined,
          visibility: tab.visibility || 'public',
          allowedUsers: Array.isArray(tab.allowedUsers)
            ? tab.allowedUsers
            : undefined,
          visibleFrom: typeof tab.visibleFrom === 'string' ? tab.visibleFrom : undefined,
          expiresAt: typeof tab.expiresAt === 'string' ? tab.expiresAt : undefined,
          sections: Array.isArray(tab.sections)
            ? tab.sections.map((section: any) => {
                const links: Link[] = Array.isArray(section.links)
                  ? section.links.map((link: any) => ({
                      id: generateId(),
                      label: String(link.label || ''),
                      url: String(link.url || ''),
                      icon: typeof link.icon === 'string' ? link.icon : undefined,
                      textColor: typeof link.textColor === 'string' ? link.textColor : undefined,
                      browser: typeof link.browser === 'string' ? link.browser : undefined,
                      position: typeof link.position === 'number' ? link.position : undefined,
                      visibility: link.visibility || 'public',
                      allowedUsers: Array.isArray(link.allowedUsers)
                        ? link.allowedUsers
                        : undefined,
                      notes: link.notes || undefined,
                      tooltip: link.tooltip || undefined,
                      richTextContent: typeof link.richTextContent === 'string' ? link.richTextContent : undefined,
                      health: link.health || undefined,
                      visibleFrom: typeof link.visibleFrom === 'string' ? link.visibleFrom : undefined,
                      expiresAt: typeof link.expiresAt === 'string' ? link.expiresAt : undefined
                    }))
                  : [];

                // Handle rich text content
                const richTextContent = Array.isArray(section.richTextContent)
                  ? section.richTextContent.map((rtc: any) => ({
                      id: generateId(),
                      content: String(rtc.content || ''),
                      position: typeof rtc.position === 'number' ? rtc.position : 0,
                      visibility: rtc.visibility || 'public',
                      allowedUsers: Array.isArray(rtc.allowedUsers)
                        ? rtc.allowedUsers
                        : undefined,
                      visibleFrom: typeof rtc.visibleFrom === 'string' ? rtc.visibleFrom : undefined,
                      expiresAt: typeof rtc.expiresAt === 'string' ? rtc.expiresAt : undefined
                    }))
                  : undefined;

                return {
                  id: generateId(),
                  title: String(section.title || ''),
                  position: typeof section.position === 'number' ? section.position : undefined,
                  textColor: typeof section.textColor === 'string' ? section.textColor : undefined,
                  forceStackedView: typeof section.forceStackedView === 'boolean' ? section.forceStackedView : undefined,
                  visibility: section.visibility || 'public',
                  allowedUsers: Array.isArray(section.allowedUsers)
                    ? section.allowedUsers
                    : undefined,
                  visibleFrom: typeof section.visibleFrom === 'string' ? section.visibleFrom : undefined,
                  expiresAt: typeof section.expiresAt === 'string' ? section.expiresAt : undefined,
                  links,
                  richTextContent
                };
              })
            : []
        }))
      : [];

    // Handle sections structure (backward compatibility)
    const sections: LinkSection[] = Array.isArray(src.sections)
      ? src.sections.map((section: any) => {
          const links: Link[] = Array.isArray(section.links)
            ? section.links.map((link: any) => ({
                id: generateId(),
                label: String(link.label || ''),
                url: String(link.url || ''),
                icon: typeof link.icon === 'string' ? link.icon : undefined,
                textColor: typeof link.textColor === 'string' ? link.textColor : undefined,
                browser: typeof link.browser === 'string' ? link.browser : undefined,
                position: typeof link.position === 'number' ? link.position : undefined,
                visibility: link.visibility || 'public',
                allowedUsers: Array.isArray(link.allowedUsers)
                  ? link.allowedUsers
                  : undefined,
                notes: link.notes || undefined,
                tooltip: link.tooltip || undefined,
                richTextContent: typeof link.richTextContent === 'string' ? link.richTextContent : undefined,
                health: link.health || undefined,
                visibleFrom: typeof link.visibleFrom === 'string' ? link.visibleFrom : undefined,
                expiresAt: typeof link.expiresAt === 'string' ? link.expiresAt : undefined
              }))
            : [];

          // Handle rich text content
          const richTextContent = Array.isArray(section.richTextContent)
            ? section.richTextContent.map((rtc: any) => ({
                id: generateId(),
                content: String(rtc.content || ''),
                position: typeof rtc.position === 'number' ? rtc.position : 0,
                visibility: rtc.visibility || 'public',
                allowedUsers: Array.isArray(rtc.allowedUsers)
                  ? rtc.allowedUsers
                  : undefined,
                visibleFrom: typeof rtc.visibleFrom === 'string' ? rtc.visibleFrom : undefined,
                expiresAt: typeof rtc.expiresAt === 'string' ? rtc.expiresAt : undefined
              }))
            : undefined;

          return {
            id: generateId(),
            title: String(section.title || ''),
            position: typeof section.position === 'number' ? section.position : undefined,
            textColor: typeof section.textColor === 'string' ? section.textColor : undefined,
            forceStackedView: typeof section.forceStackedView === 'boolean' ? section.forceStackedView : undefined,
            visibility: section.visibility || 'public',
            allowedUsers: Array.isArray(section.allowedUsers)
              ? section.allowedUsers
              : undefined,
            visibleFrom: typeof section.visibleFrom === 'string' ? section.visibleFrom : undefined,
            expiresAt: typeof section.expiresAt === 'string' ? section.expiresAt : undefined,
            links,
            richTextContent
          };
        })
      : [];

    const tile: Tile = {
      id: generateId(),
      title: String(src.title || `Imported Space ${index + 1}`),
      description: String(src.description || ''),
      htmlContent: src.htmlContent || '',
      emoji: src.emoji || '📁',
      themeColor: (src.themeColor as any) || 'blue',
      tabs: tabs.length > 0 ? tabs : undefined,
      sections: sections.length > 0 ? sections : [],
      group: baseGroup,
      createdAt: typeof src.createdAt === 'number' ? src.createdAt : now,
      visibility: src.visibility || 'public',
      allowedUsers: Array.isArray(src.allowedUsers) ? src.allowedUsers : undefined,
      allowedGroups: Array.isArray(src.allowedGroups) ? src.allowedGroups : undefined,
      isHyperlink: src.isHyperlink || false,
      hyperlinkUrl: src.hyperlinkUrl || undefined,
      openInNewTab: src.openInNewTab !== undefined ? src.openInNewTab : undefined,
      browser: typeof src.browser === 'string' ? src.browser : undefined,
      visibleFrom: typeof src.visibleFrom === 'string' ? src.visibleFrom : undefined,
      expiresAt: typeof src.expiresAt === 'string' ? src.expiresAt : undefined,
      // Preserve tile decoration properties
      tileBackgroundColor: typeof src.tileBackgroundColor === 'string' ? src.tileBackgroundColor : undefined,
      tileGradientEnabled: typeof src.tileGradientEnabled === 'boolean' ? src.tileGradientEnabled : undefined,
      tileGradientColors: Array.isArray(src.tileGradientColors) ? src.tileGradientColors : undefined,
      tileGradientDirection: (typeof src.tileGradientDirection === 'string' || typeof src.tileGradientDirection === 'number') ? src.tileGradientDirection : undefined,
      tileGradientType: (typeof src.tileGradientType === 'string' && ['linear', 'radial', 'conic', 'repeating-linear', 'repeating-radial', 'repeating-conic'].includes(src.tileGradientType)) ? src.tileGradientType as any : undefined,
      tileGradientColorPositions: Array.isArray(src.tileGradientColorPositions) ? src.tileGradientColorPositions : undefined,
      tileBorderRadius: typeof src.tileBorderRadius === 'number' ? src.tileBorderRadius : undefined,
      tileTextColor: typeof src.tileTextColor === 'string' ? src.tileTextColor : undefined,
      // Preserve tile messages (message board messages)
      messages: Array.isArray(src.messages) && src.messages.length > 0
        ? src.messages.map((msg: any) => ({
            id: generateId(), // Generate new ID for imported message
            content: String(msg.content || ''),
            type: (typeof msg.type === 'string' && ['info', 'warning', 'celebration', 'alert', 'custom'].includes(msg.type)) ? msg.type as any : 'info',
            startDate: typeof msg.startDate === 'string' ? msg.startDate : new Date().toISOString(),
            endDate: typeof msg.endDate === 'string' ? msg.endDate : new Date().toISOString(),
            isActive: typeof msg.isActive === 'boolean' ? msg.isActive : false,
            priority: typeof msg.priority === 'number' ? msg.priority : undefined,
            textColor: typeof msg.textColor === 'string' ? msg.textColor : undefined,
            fontStyle: typeof msg.fontStyle === 'string' ? msg.fontStyle : undefined,
            displayLocation: (typeof msg.displayLocation === 'string' && ['tile', 'detail', 'both'].includes(msg.displayLocation)) ? msg.displayLocation as any : 'both',
            animationType: (typeof msg.animationType === 'string' && ['rollover', 'still', 'flash', 'flip-horizontal', 'flip-vertical', 'bounce', 'pulse', 'shake', 'fade', 'slide'].includes(msg.animationType)) ? msg.animationType as any : 'rollover',
            delayBefore: typeof msg.delayBefore === 'number' ? msg.delayBefore : undefined,
            celebrationEffect: (typeof msg.celebrationEffect === 'string' && ['none', 'fireworks', 'confetti', 'snowfall', 'hearts-rising', 'hearts-falling', 'bubbles', 'butterflies', 'birds-flying', 'rocket-launch', 'burst-fireworks', 'sparkles', 'petals', 'shooting-stars', 'leaves', 'fireflies', 'balloons', 'stars', 'rainbow'].includes(msg.celebrationEffect)) ? msg.celebrationEffect as any : undefined,
            celebrationConfig: typeof msg.celebrationConfig === 'object' && msg.celebrationConfig !== null ? msg.celebrationConfig : undefined
          }))
        : undefined
    };

    return tile;
  });

  return normalized;
};











