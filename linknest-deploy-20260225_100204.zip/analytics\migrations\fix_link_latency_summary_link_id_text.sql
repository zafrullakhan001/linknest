-- Fix column type for link_latency_summary.link_id (must accept LinkNest text IDs)
-- Some installations created link_id as INTEGER; LinkNest uses TEXT ids (e.g. "link_dash_home").
-- This migration converts link_latency_summary.link_id to TEXT safely.

DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_name = 'link_latency_summary'
      AND column_name = 'link_id'
      AND data_type <> 'text'
  ) THEN
    -- Drop any indexes that could depend on the old type (safe if missing)
    EXECUTE 'DROP INDEX IF EXISTS idx_summary_link_id';

    -- Convert existing integer values to text
    EXECUTE 'ALTER TABLE link_latency_summary ALTER COLUMN link_id TYPE TEXT USING link_id::text';
  END IF;
END $$;

DO $$
BEGIN
  RAISE NOTICE 'Ensured link_latency_summary.link_id is TEXT';
END $$;

