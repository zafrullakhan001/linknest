--
-- PostgreSQL database dump
--

\restrict WRhjzb7xXUoqa9Tr5YeUkfjsAxq9KA5y8cqvMqSswtFv73AW9c70jiI8aEbBSV3

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: timescaledb; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS timescaledb WITH SCHEMA public;


--
-- Name: EXTENSION timescaledb; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION timescaledb IS 'Enables scalable inserts and complex queries for time-series data (Community Edition)';


--
-- Name: update_link_latency_summary(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_link_latency_summary() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Insert or update summary for this link
    INSERT INTO link_latency_summary (
        link_url,
        link_id,
        last_client_check,
        client_avg_latency,
        client_measurement_count,
        last_server_check,
        server_avg_latency,
        server_measurement_count,
        updated_at
    )
    SELECT
        NEW.link_url,
        NEW.link_id,
        CASE WHEN NEW.measurement_type = 'client' THEN NEW.time ELSE NULL END,
        CASE WHEN NEW.measurement_type = 'client' THEN NEW.full_response_time ELSE NULL END,
        CASE WHEN NEW.measurement_type = 'client' THEN 1 ELSE 0 END,
        CASE WHEN NEW.measurement_type = 'server' THEN NEW.time ELSE NULL END,
        CASE WHEN NEW.measurement_type = 'server' THEN NEW.full_response_time ELSE NULL END,
        CASE WHEN NEW.measurement_type = 'server' THEN 1 ELSE 0 END,
        NOW()
    ON CONFLICT (link_url) DO UPDATE SET
        -- Update client metrics if this is a client measurement
        last_client_check = CASE 
            WHEN NEW.measurement_type = 'client' THEN NEW.time 
            ELSE link_latency_summary.last_client_check 
        END,
        client_avg_latency = CASE 
            WHEN NEW.measurement_type = 'client' THEN 
                ROUND((COALESCE(link_latency_summary.client_avg_latency, 0) * link_latency_summary.client_measurement_count + NEW.full_response_time) / 
                      (link_latency_summary.client_measurement_count + 1))
            ELSE link_latency_summary.client_avg_latency 
        END,
        client_measurement_count = CASE 
            WHEN NEW.measurement_type = 'client' THEN link_latency_summary.client_measurement_count + 1 
            ELSE link_latency_summary.client_measurement_count 
        END,
        -- Update server metrics if this is a server measurement
        last_server_check = CASE 
            WHEN NEW.measurement_type = 'server' THEN NEW.time 
            ELSE link_latency_summary.last_server_check 
        END,
        server_avg_latency = CASE 
            WHEN NEW.measurement_type = 'server' THEN 
                ROUND((COALESCE(link_latency_summary.server_avg_latency, 0) * link_latency_summary.server_measurement_count + NEW.full_response_time) / 
                      (link_latency_summary.server_measurement_count + 1))
            ELSE link_latency_summary.server_avg_latency 
        END,
        server_measurement_count = CASE 
            WHEN NEW.measurement_type = 'server' THEN link_latency_summary.server_measurement_count + 1 
            ELSE link_latency_summary.server_measurement_count 
        END,
        -- Update geographic context from client measurements
        client_country_code = CASE 
            WHEN NEW.measurement_type = 'client' THEN NEW.country_code 
            ELSE link_latency_summary.client_country_code 
        END,
        client_region_name = CASE 
            WHEN NEW.measurement_type = 'client' THEN NEW.region_name 
            ELSE link_latency_summary.client_region_name 
        END,
        client_city_name = CASE 
            WHEN NEW.measurement_type = 'client' THEN NEW.city_name 
            ELSE link_latency_summary.client_city_name 
        END,
        -- Calculate delta and health status
        latency_delta = COALESCE(
            CASE WHEN NEW.measurement_type = 'client' THEN NEW.full_response_time ELSE link_latency_summary.client_avg_latency END
            - 
            CASE WHEN NEW.measurement_type = 'server' THEN NEW.full_response_time ELSE link_latency_summary.server_avg_latency END,
            0
        ),
        health_status = CASE
            WHEN COALESCE(link_latency_summary.client_avg_latency, NEW.full_response_time) < 100 THEN 'excellent'
            WHEN COALESCE(link_latency_summary.client_avg_latency, NEW.full_response_time) < 300 THEN 'good'
            WHEN COALESCE(link_latency_summary.client_avg_latency, NEW.full_response_time) < 1000 THEN 'degraded'
            ELSE 'poor'
        END,
        updated_at = NOW();
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_link_latency_summary() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _compressed_hypertable_2; Type: TABLE; Schema: _timescaledb_internal; Owner: postgres
--

CREATE TABLE _timescaledb_internal._compressed_hypertable_2 (
);


ALTER TABLE _timescaledb_internal._compressed_hypertable_2 OWNER TO postgres;

--
-- Name: performance_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.performance_metrics (
    "time" timestamp with time zone NOT NULL,
    link_url text NOT NULL,
    link_id text,
    page_url text,
    measurement_type text NOT NULL,
    user_id integer,
    username character varying(255),
    session_id character varying(100),
    is_authenticated boolean DEFAULT false,
    ip_address inet,
    continent_code character(2),
    country_code character(2),
    country_name character varying(100),
    region_name character varying(100),
    city_name character varying(100),
    latitude numeric(9,6),
    longitude numeric(9,6),
    timezone character varying(50),
    isp character varying(200),
    dns_lookup_time integer,
    tcp_connection_time integer,
    tls_handshake_time integer,
    time_to_first_byte integer,
    dom_content_loaded_time integer,
    full_response_time integer NOT NULL,
    page_size_bytes integer,
    http_status_code integer,
    error_message text,
    connection_type character varying(50),
    device_type character varying(50),
    browser_name character varying(100),
    browser_version character varying(50),
    os_name character varying(100),
    screen_resolution character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT performance_metrics_measurement_type_check CHECK ((measurement_type = ANY (ARRAY['client'::text, 'server'::text])))
);


ALTER TABLE public.performance_metrics OWNER TO postgres;

--
-- Name: _direct_view_3; Type: VIEW; Schema: _timescaledb_internal; Owner: postgres
--

CREATE VIEW _timescaledb_internal._direct_view_3 AS
 SELECT public.time_bucket('01:00:00'::interval, "time") AS bucket,
    link_url,
    measurement_type,
    country_code,
    country_name,
    region_name,
    avg(latitude) AS region_center_lat,
    avg(longitude) AS region_center_lon,
    count(*) AS measurement_count,
    count(DISTINCT user_id) AS unique_users,
    count(DISTINCT session_id) AS unique_sessions,
    count(*) FILTER (WHERE is_authenticated) AS authenticated_count,
    round(avg(full_response_time)) AS avg_latency,
    round(percentile_cont((0.50)::double precision) WITHIN GROUP (ORDER BY ((full_response_time)::double precision))) AS p50_latency,
    round(percentile_cont((0.95)::double precision) WITHIN GROUP (ORDER BY ((full_response_time)::double precision))) AS p95_latency,
    round(percentile_cont((0.99)::double precision) WITHIN GROUP (ORDER BY ((full_response_time)::double precision))) AS p99_latency,
    min(full_response_time) AS min_latency,
    max(full_response_time) AS max_latency,
    round(avg(dns_lookup_time)) AS avg_dns_time,
    round(avg(tcp_connection_time)) AS avg_tcp_time,
    round(avg(tls_handshake_time)) AS avg_tls_time,
    round(avg(time_to_first_byte)) AS avg_ttfb,
    count(*) FILTER (WHERE ((connection_type)::text = 'wifi'::text)) AS wifi_count,
    count(*) FILTER (WHERE ((connection_type)::text = '4g'::text)) AS mobile_4g_count,
    count(*) FILTER (WHERE ((connection_type)::text = '5g'::text)) AS mobile_5g_count,
    count(*) FILTER (WHERE ((device_type)::text = 'mobile'::text)) AS mobile_count,
    count(*) FILTER (WHERE ((device_type)::text = 'desktop'::text)) AS desktop_count,
    count(*) FILTER (WHERE ((device_type)::text = 'tablet'::text)) AS tablet_count,
    count(*) FILTER (WHERE ((http_status_code >= 200) AND (http_status_code < 400))) AS successful_requests,
    round((((count(*) FILTER (WHERE ((http_status_code >= 200) AND (http_status_code < 400))))::numeric / (NULLIF(count(*), 0))::numeric) * (100)::numeric), 1) AS success_rate_pct
   FROM public.performance_metrics
  GROUP BY (public.time_bucket('01:00:00'::interval, "time")), link_url, measurement_type, country_code, country_name, region_name;


ALTER VIEW _timescaledb_internal._direct_view_3 OWNER TO postgres;

--
-- Name: _hyper_1_1_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: postgres
--

CREATE TABLE _timescaledb_internal._hyper_1_1_chunk (
    CONSTRAINT constraint_1 CHECK ((("time" >= '2026-01-22 00:00:00+00'::timestamp with time zone) AND ("time" < '2026-01-29 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.performance_metrics);


ALTER TABLE _timescaledb_internal._hyper_1_1_chunk OWNER TO postgres;

--
-- Name: _materialized_hypertable_3; Type: TABLE; Schema: _timescaledb_internal; Owner: postgres
--

CREATE TABLE _timescaledb_internal._materialized_hypertable_3 (
    bucket timestamp with time zone,
    link_url text,
    measurement_type text,
    country_code character(2),
    country_name character varying(100),
    region_name character varying(100),
    region_center_lat numeric,
    region_center_lon numeric,
    measurement_count bigint,
    unique_users bigint,
    unique_sessions bigint,
    authenticated_count bigint,
    avg_latency numeric,
    p50_latency double precision,
    p95_latency double precision,
    p99_latency double precision,
    min_latency integer,
    max_latency integer,
    avg_dns_time numeric,
    avg_tcp_time numeric,
    avg_tls_time numeric,
    avg_ttfb numeric,
    wifi_count bigint,
    mobile_4g_count bigint,
    mobile_5g_count bigint,
    mobile_count bigint,
    desktop_count bigint,
    tablet_count bigint,
    successful_requests bigint,
    success_rate_pct numeric
);


ALTER TABLE _timescaledb_internal._materialized_hypertable_3 OWNER TO postgres;

--
-- Name: _partial_view_3; Type: VIEW; Schema: _timescaledb_internal; Owner: postgres
--

CREATE VIEW _timescaledb_internal._partial_view_3 AS
 SELECT public.time_bucket('01:00:00'::interval, "time") AS bucket,
    link_url,
    measurement_type,
    country_code,
    country_name,
    region_name,
    avg(latitude) AS region_center_lat,
    avg(longitude) AS region_center_lon,
    count(*) AS measurement_count,
    count(DISTINCT user_id) AS unique_users,
    count(DISTINCT session_id) AS unique_sessions,
    count(*) FILTER (WHERE is_authenticated) AS authenticated_count,
    round(avg(full_response_time)) AS avg_latency,
    round(percentile_cont((0.50)::double precision) WITHIN GROUP (ORDER BY ((full_response_time)::double precision))) AS p50_latency,
    round(percentile_cont((0.95)::double precision) WITHIN GROUP (ORDER BY ((full_response_time)::double precision))) AS p95_latency,
    round(percentile_cont((0.99)::double precision) WITHIN GROUP (ORDER BY ((full_response_time)::double precision))) AS p99_latency,
    min(full_response_time) AS min_latency,
    max(full_response_time) AS max_latency,
    round(avg(dns_lookup_time)) AS avg_dns_time,
    round(avg(tcp_connection_time)) AS avg_tcp_time,
    round(avg(tls_handshake_time)) AS avg_tls_time,
    round(avg(time_to_first_byte)) AS avg_ttfb,
    count(*) FILTER (WHERE ((connection_type)::text = 'wifi'::text)) AS wifi_count,
    count(*) FILTER (WHERE ((connection_type)::text = '4g'::text)) AS mobile_4g_count,
    count(*) FILTER (WHERE ((connection_type)::text = '5g'::text)) AS mobile_5g_count,
    count(*) FILTER (WHERE ((device_type)::text = 'mobile'::text)) AS mobile_count,
    count(*) FILTER (WHERE ((device_type)::text = 'desktop'::text)) AS desktop_count,
    count(*) FILTER (WHERE ((device_type)::text = 'tablet'::text)) AS tablet_count,
    count(*) FILTER (WHERE ((http_status_code >= 200) AND (http_status_code < 400))) AS successful_requests,
    round((((count(*) FILTER (WHERE ((http_status_code >= 200) AND (http_status_code < 400))))::numeric / (NULLIF(count(*), 0))::numeric) * (100)::numeric), 1) AS success_rate_pct
   FROM public.performance_metrics
  GROUP BY (public.time_bucket('01:00:00'::interval, "time")), link_url, measurement_type, country_code, country_name, region_name;


ALTER VIEW _timescaledb_internal._partial_view_3 OWNER TO postgres;

--
-- Name: alert_thresholds; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alert_thresholds (
    id integer NOT NULL,
    link_url text,
    country_code character(2),
    region_name character varying(100),
    threshold_type character varying(20),
    max_avg_latency integer DEFAULT 3000,
    max_p95_latency integer DEFAULT 5000,
    max_p99_latency integer DEFAULT 10000,
    max_ttfb integer DEFAULT 1000,
    max_delta_ms integer,
    alert_email text[],
    is_enabled boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT alert_thresholds_threshold_type_check CHECK (((threshold_type)::text = ANY ((ARRAY['client'::character varying, 'server'::character varying, 'delta'::character varying])::text[])))
);


ALTER TABLE public.alert_thresholds OWNER TO postgres;

--
-- Name: alert_thresholds_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.alert_thresholds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.alert_thresholds_id_seq OWNER TO postgres;

--
-- Name: alert_thresholds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.alert_thresholds_id_seq OWNED BY public.alert_thresholds.id;


--
-- Name: link_latency_summary; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.link_latency_summary (
    link_url text NOT NULL,
    link_id text,
    last_client_check timestamp with time zone,
    client_avg_latency integer,
    client_p50_latency integer,
    client_p95_latency integer,
    client_p99_latency integer,
    client_min_latency integer,
    client_max_latency integer,
    client_measurement_count integer DEFAULT 0,
    last_server_check timestamp with time zone,
    server_avg_latency integer,
    server_p50_latency integer,
    server_p95_latency integer,
    server_p99_latency integer,
    server_min_latency integer,
    server_max_latency integer,
    server_measurement_count integer DEFAULT 0,
    client_country_code character(2),
    client_region_name character varying(100),
    client_city_name character varying(100),
    latency_delta integer,
    performance_ratio numeric(5,2),
    health_status character varying(20),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT link_latency_summary_health_status_check CHECK (((health_status)::text = ANY ((ARRAY['excellent'::character varying, 'good'::character varying, 'degraded'::character varying, 'poor'::character varying, 'unknown'::character varying])::text[])))
);


ALTER TABLE public.link_latency_summary OWNER TO postgres;

--
-- Name: location_lookup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.location_lookup (
    id integer NOT NULL,
    country_code character varying(2) NOT NULL,
    country_name character varying(100) NOT NULL,
    region_name character varying(100),
    city_name character varying(100),
    latitude numeric(10,7) NOT NULL,
    longitude numeric(10,7) NOT NULL,
    population integer,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.location_lookup OWNER TO postgres;

--
-- Name: location_lookup_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.location_lookup_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.location_lookup_id_seq OWNER TO postgres;

--
-- Name: location_lookup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.location_lookup_id_seq OWNED BY public.location_lookup.id;


--
-- Name: metrics_queue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.metrics_queue (
    id bigint NOT NULL,
    payload jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    processed boolean DEFAULT false,
    processed_at timestamp with time zone
);


ALTER TABLE public.metrics_queue OWNER TO postgres;

--
-- Name: metrics_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.metrics_queue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.metrics_queue_id_seq OWNER TO postgres;

--
-- Name: metrics_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.metrics_queue_id_seq OWNED BY public.metrics_queue.id;


--
-- Name: performance_by_region_hourly; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.performance_by_region_hourly AS
 SELECT bucket,
    link_url,
    measurement_type,
    country_code,
    country_name,
    region_name,
    region_center_lat,
    region_center_lon,
    measurement_count,
    unique_users,
    unique_sessions,
    authenticated_count,
    avg_latency,
    p50_latency,
    p95_latency,
    p99_latency,
    min_latency,
    max_latency,
    avg_dns_time,
    avg_tcp_time,
    avg_tls_time,
    avg_ttfb,
    wifi_count,
    mobile_4g_count,
    mobile_5g_count,
    mobile_count,
    desktop_count,
    tablet_count,
    successful_requests,
    success_rate_pct
   FROM _timescaledb_internal._materialized_hypertable_3;


ALTER VIEW public.performance_by_region_hourly OWNER TO postgres;

--
-- Name: performance_alerts; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.performance_alerts AS
 SELECT p.bucket AS time_period,
    p.link_url,
    p.country_name,
    p.region_name,
    p.measurement_type,
    p.avg_latency,
    p.p95_latency,
    p.p99_latency,
    p.avg_ttfb,
    t.max_avg_latency AS threshold_avg,
    t.max_p95_latency AS threshold_p95,
    t.max_ttfb AS threshold_ttfb,
    (p.avg_latency > (t.max_avg_latency)::numeric) AS avg_exceeded,
    (p.p95_latency > (t.max_p95_latency)::double precision) AS p95_exceeded,
    (p.avg_ttfb > (t.max_ttfb)::numeric) AS ttfb_exceeded,
        CASE
            WHEN (p.p95_latency > ((t.max_p95_latency * 2))::double precision) THEN 'critical'::text
            WHEN (p.p95_latency > (t.max_p95_latency)::double precision) THEN 'warning'::text
            ELSE 'ok'::text
        END AS severity,
    t.alert_email
   FROM (public.performance_by_region_hourly p
     JOIN public.alert_thresholds t ON ((((t.link_url IS NULL) OR (t.link_url = p.link_url)) AND ((t.country_code IS NULL) OR (t.country_code = p.country_code)) AND ((t.region_name IS NULL) OR ((t.region_name)::text = (p.region_name)::text)))))
  WHERE ((t.is_enabled = true) AND (p.bucket >= (now() - '24:00:00'::interval)) AND ((p.avg_latency > (t.max_avg_latency)::numeric) OR (p.p95_latency > (t.max_p95_latency)::double precision) OR (p.avg_ttfb > (t.max_ttfb)::numeric)))
  ORDER BY p.bucket DESC,
        CASE
            WHEN (p.p95_latency > ((t.max_p95_latency * 2))::double precision) THEN 'critical'::text
            WHEN (p.p95_latency > (t.max_p95_latency)::double precision) THEN 'warning'::text
            ELSE 'ok'::text
        END DESC;


ALTER VIEW public.performance_alerts OWNER TO postgres;

--
-- Name: user_geolocations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_geolocations (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    username character varying(255),
    login_time timestamp with time zone DEFAULT now() NOT NULL,
    ip_address inet NOT NULL,
    continent_code character(2),
    country_code character(2),
    country_name character varying(100),
    region_name character varying(100),
    city_name character varying(100),
    latitude numeric(9,6),
    longitude numeric(9,6),
    timezone character varying(50),
    isp character varying(200),
    session_id character varying(100),
    user_agent text,
    device_type character varying(50),
    browser_name character varying(100),
    os_name character varying(100),
    is_new_location boolean DEFAULT true,
    last_seen timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_geolocations OWNER TO postgres;

--
-- Name: user_current_location; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.user_current_location AS
 SELECT DISTINCT ON (user_id) user_id,
    username,
    login_time,
    country_name,
    region_name,
    city_name,
    latitude,
    longitude,
    timezone
   FROM public.user_geolocations
  ORDER BY user_id, login_time DESC;


ALTER VIEW public.user_current_location OWNER TO postgres;

--
-- Name: user_geolocations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_geolocations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_geolocations_id_seq OWNER TO postgres;

--
-- Name: user_geolocations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_geolocations_id_seq OWNED BY public.user_geolocations.id;


--
-- Name: _hyper_1_1_chunk is_authenticated; Type: DEFAULT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_1_chunk ALTER COLUMN is_authenticated SET DEFAULT false;


--
-- Name: _hyper_1_1_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_1_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: alert_thresholds id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_thresholds ALTER COLUMN id SET DEFAULT nextval('public.alert_thresholds_id_seq'::regclass);


--
-- Name: location_lookup id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location_lookup ALTER COLUMN id SET DEFAULT nextval('public.location_lookup_id_seq'::regclass);


--
-- Name: metrics_queue id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.metrics_queue ALTER COLUMN id SET DEFAULT nextval('public.metrics_queue_id_seq'::regclass);


--
-- Name: user_geolocations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_geolocations ALTER COLUMN id SET DEFAULT nextval('public.user_geolocations_id_seq'::regclass);


--
-- Data for Name: hypertable; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.hypertable (id, schema_name, table_name, associated_schema_name, associated_table_prefix, num_dimensions, chunk_sizing_func_schema, chunk_sizing_func_name, chunk_target_size, compression_state, compressed_hypertable_id, status) FROM stdin;
2	_timescaledb_internal	_compressed_hypertable_2	_timescaledb_internal	_hyper_2	0	_timescaledb_functions	calculate_chunk_interval	0	2	\N	0
1	public	performance_metrics	_timescaledb_internal	_hyper_1	1	_timescaledb_functions	calculate_chunk_interval	0	1	2	0
3	_timescaledb_internal	_materialized_hypertable_3	_timescaledb_internal	_hyper_3	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
\.


--
-- Data for Name: chunk; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.chunk (id, hypertable_id, schema_name, table_name, compressed_chunk_id, dropped, status, osm_chunk, creation_time) FROM stdin;
1	1	_timescaledb_internal	_hyper_1_1_chunk	\N	f	0	f	2026-01-25 22:45:13.355302+00
\.


--
-- Data for Name: chunk_column_stats; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.chunk_column_stats (id, hypertable_id, chunk_id, column_name, range_start, range_end, valid) FROM stdin;
\.


--
-- Data for Name: dimension; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.dimension (id, hypertable_id, column_name, column_type, aligned, num_slices, partitioning_func_schema, partitioning_func, interval_length, compress_interval_length, integer_now_func_schema, integer_now_func) FROM stdin;
1	1	time	timestamp with time zone	t	\N	\N	\N	604800000000	\N	\N	\N
2	3	bucket	timestamp with time zone	t	\N	\N	\N	6048000000000	\N	\N	\N
\.


--
-- Data for Name: dimension_slice; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.dimension_slice (id, dimension_id, range_start, range_end) FROM stdin;
1	1	1769040000000000	1769644800000000
\.


--
-- Data for Name: chunk_constraint; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.chunk_constraint (chunk_id, dimension_slice_id, constraint_name, hypertable_constraint_name) FROM stdin;
1	1	constraint_1	\N
\.


--
-- Data for Name: compression_chunk_size; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.compression_chunk_size (chunk_id, compressed_chunk_id, uncompressed_heap_size, uncompressed_toast_size, uncompressed_index_size, compressed_heap_size, compressed_toast_size, compressed_index_size, numrows_pre_compression, numrows_post_compression, numrows_frozen_immediately) FROM stdin;
\.


--
-- Data for Name: compression_settings; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.compression_settings (relid, compress_relid, segmentby, orderby, orderby_desc, orderby_nullsfirst, index) FROM stdin;
public.performance_metrics	\N	{link_url,country_code,region_name,measurement_type}	\N	\N	\N	\N
\.


--
-- Data for Name: continuous_agg; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_agg (mat_hypertable_id, raw_hypertable_id, parent_mat_hypertable_id, user_view_schema, user_view_name, partial_view_schema, partial_view_name, direct_view_schema, direct_view_name, materialized_only, finalized) FROM stdin;
3	1	\N	public	performance_by_region_hourly	_timescaledb_internal	_partial_view_3	_timescaledb_internal	_direct_view_3	t	t
\.


--
-- Data for Name: continuous_agg_migrate_plan; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_agg_migrate_plan (mat_hypertable_id, start_ts, end_ts, user_view_definition) FROM stdin;
\.


--
-- Data for Name: continuous_agg_migrate_plan_step; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_agg_migrate_plan_step (mat_hypertable_id, step_id, status, start_ts, end_ts, type, config) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_bucket_function; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_aggs_bucket_function (mat_hypertable_id, bucket_func, bucket_width, bucket_origin, bucket_offset, bucket_timezone, bucket_fixed_width) FROM stdin;
3	public.time_bucket(interval,timestamp with time zone)	01:00:00	\N	\N	\N	t
\.


--
-- Data for Name: continuous_aggs_hypertable_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_aggs_hypertable_invalidation_log (hypertable_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_invalidation_threshold; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_aggs_invalidation_threshold (hypertable_id, watermark) FROM stdin;
1	1769378400000000
\.


--
-- Data for Name: continuous_aggs_materialization_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_aggs_materialization_invalidation_log (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
3	-9223372036854775808	1769371199999999
3	1769378400000000	9223372036854775807
\.


--
-- Data for Name: continuous_aggs_materialization_ranges; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_aggs_materialization_ranges (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_watermark; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_aggs_watermark (mat_hypertable_id, watermark) FROM stdin;
3	-210866803200000000
\.


--
-- Data for Name: metadata; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.metadata (key, value, include_in_telemetry) FROM stdin;
install_timestamp	2026-01-25 19:36:09.609917+00	t
timescaledb_version	2.24.0	f
exported_uuid	a9f7df11-0f97-4f8c-93fb-af222bfcea48	t
\.


--
-- Data for Name: tablespace; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.tablespace (id, hypertable_id, tablespace_name) FROM stdin;
\.


--
-- Data for Name: bgw_job; Type: TABLE DATA; Schema: _timescaledb_config; Owner: postgres
--

COPY _timescaledb_config.bgw_job (id, application_name, schedule_interval, max_runtime, max_retries, retry_period, proc_schema, proc_name, owner, scheduled, fixed_schedule, initial_start, hypertable_id, config, check_schema, check_name, timezone) FROM stdin;
1000	Columnstore Policy [1000]	12:00:00	00:00:00	-1	01:00:00	_timescaledb_functions	policy_compression	postgres	t	f	\N	1	{"hypertable_id": 1, "compress_after": "7 days"}	_timescaledb_functions	policy_compression_check	\N
1001	Retention Policy [1001]	1 day	00:05:00	-1	00:05:00	_timescaledb_functions	policy_retention	postgres	t	f	\N	1	{"drop_after": "90 days", "hypertable_id": 1}	_timescaledb_functions	policy_retention_check	\N
1002	Refresh Continuous Aggregate Policy [1002]	00:30:00	00:00:00	-1	00:30:00	_timescaledb_functions	policy_refresh_continuous_aggregate	postgres	t	f	\N	3	{"end_offset": "00:30:00", "start_offset": "03:00:00", "mat_hypertable_id": 3}	_timescaledb_functions	policy_refresh_continuous_aggregate_check	\N
\.


--
-- Data for Name: _compressed_hypertable_2; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: postgres
--

COPY _timescaledb_internal._compressed_hypertable_2  FROM stdin;
\.


--
-- Data for Name: _hyper_1_1_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: postgres
--

COPY _timescaledb_internal._hyper_1_1_chunk ("time", link_url, link_id, page_url, measurement_type, user_id, username, session_id, is_authenticated, ip_address, continent_code, country_code, country_name, region_name, city_name, latitude, longitude, timezone, isp, dns_lookup_time, tcp_connection_time, tls_handshake_time, time_to_first_byte, dom_content_loaded_time, full_response_time, page_size_bytes, http_status_code, error_message, connection_type, device_type, browser_name, browser_version, os_name, screen_resolution, created_at) FROM stdin;
2026-01-25 22:43:07+00	https://example.com/	link_dash_home	http://localhost/linknest/#/tile/tile_dashboard?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	34	\N	0	\N	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:45:13.35109+00
2026-01-25 22:43:07+00	https://portal.example.com/	link_dash_portal	http://localhost/linknest/#/tile/tile_dashboard?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	40	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:45:13.35109+00
2026-01-25 22:43:07+00	https://mail.example.com/	link_dash_email	http://localhost/linknest/#/tile/tile_dashboard?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	40	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:45:13.35109+00
2026-01-25 22:43:07+00	https://reports.example.com/sales	link_dash_sales	http://localhost/linknest/#/tile/tile_dashboard?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	40	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:45:13.35109+00
2026-01-25 22:43:07+00	https://reports.example.com/hr	link_dash_hr	http://localhost/linknest/#/tile/tile_dashboard?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	28	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:45:13.35109+00
2026-01-25 22:43:07+00	https://admin.example.com/	link_dash_admin	http://localhost/linknest/#/tile/tile_dashboard?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	46	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:45:13.35109+00
2026-01-25 22:45:20+00	https://example.com/	link_dash_home	http://localhost/linknest/#/tile/tile_dashboard?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	43	\N	0	\N	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:45:21.425016+00
2026-01-25 22:45:20+00	https://portal.example.com/	link_dash_portal	http://localhost/linknest/#/tile/tile_dashboard?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	35	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:45:21.425016+00
2026-01-25 22:45:20+00	https://mail.example.com/	link_dash_email	http://localhost/linknest/#/tile/tile_dashboard?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	41	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:45:21.425016+00
2026-01-25 22:45:20+00	https://reports.example.com/sales	link_dash_sales	http://localhost/linknest/#/tile/tile_dashboard?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	40	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:45:21.425016+00
2026-01-25 22:45:20+00	https://reports.example.com/hr	link_dash_hr	http://localhost/linknest/#/tile/tile_dashboard?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	45	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:45:21.425016+00
2026-01-25 22:45:20+00	https://admin.example.com/	link_dash_admin	http://localhost/linknest/#/tile/tile_dashboard?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	45	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:45:21.425016+00
2026-01-25 22:46:27+00	https://example.com/	link_dash_home	http://localhost/linknest/#/tile/tile_dashboard?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	38	\N	0	\N	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:46:27.822425+00
2026-01-25 22:46:27+00	https://portal.example.com/	link_dash_portal	http://localhost/linknest/#/tile/tile_dashboard?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	58	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:46:27.822425+00
2026-01-25 22:46:27+00	https://mail.example.com/	link_dash_email	http://localhost/linknest/#/tile/tile_dashboard?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	43	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:46:27.822425+00
2026-01-25 22:46:27+00	https://reports.example.com/sales	link_dash_sales	http://localhost/linknest/#/tile/tile_dashboard?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	58	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:46:27.822425+00
2026-01-25 22:46:27+00	https://reports.example.com/hr	link_dash_hr	http://localhost/linknest/#/tile/tile_dashboard?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	42	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:46:27.822425+00
2026-01-25 22:46:27+00	https://admin.example.com/	link_dash_admin	http://localhost/linknest/#/tile/tile_dashboard?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	62	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:46:27.822425+00
2026-01-25 22:46:32+00	https://bi.example.com/	link_analytics_bi	http://localhost/linknest/#/tile/tile_analytics?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	98	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:46:33.867467+00
2026-01-25 22:46:32+00	https://analytics.example.com/	link_analytics_reports	http://localhost/linknest/#/tile/tile_analytics?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	143	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:46:33.867467+00
2026-01-25 22:46:32+00	https://analytics.google.com/	link_analytics_google	http://localhost/linknest/#/tile/tile_analytics?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	216	\N	0	\N	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:46:33.867467+00
2026-01-25 22:46:33+00	https://bi.example.com/	link_analytics_bi	http://localhost/linknest/#/tile/tile_analytics?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	41	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:46:33.867467+00
2026-01-25 22:46:33+00	https://analytics.example.com/	link_analytics_reports	http://localhost/linknest/#/tile/tile_analytics?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	41	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:46:33.867467+00
2026-01-25 22:46:33+00	https://analytics.google.com/	link_analytics_google	http://localhost/linknest/#/tile/tile_analytics?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	130	\N	0	\N	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:46:33.867467+00
2026-01-25 22:47:20+00	https://bi.example.com/	link_analytics_bi	http://localhost/linknest/#/tile/tile_analytics?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	48	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:47:22.149866+00
2026-01-25 22:47:20+00	https://analytics.example.com/	link_analytics_reports	http://localhost/linknest/#/tile/tile_analytics?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	48	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:47:22.149866+00
2026-01-25 22:47:20+00	https://analytics.google.com/	link_analytics_google	http://localhost/linknest/#/tile/tile_analytics?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703550	-81.415655	UTC	\N	\N	\N	\N	\N	\N	131	\N	0	\N	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:47:22.149866+00
2026-01-25 22:49:56+00	https://accounting.example.com/	link_finance_accounting	http://localhost/linknest/#/tile/tile_finance?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703690	-81.415403	UTC	\N	\N	\N	\N	\N	\N	33	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:49:57.002854+00
2026-01-25 22:49:56+00	https://invoices.example.com/	link_finance_invoicing	http://localhost/linknest/#/tile/tile_finance?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703690	-81.415403	UTC	\N	\N	\N	\N	\N	\N	27	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:49:57.002854+00
2026-01-25 22:49:56+00	https://finance.example.com/reports	link_finance_reports	http://localhost/linknest/#/tile/tile_finance?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703690	-81.415403	UTC	\N	\N	\N	\N	\N	\N	33	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:49:57.002854+00
2026-01-25 22:49:56+00	https://accounting.example.com/	link_finance_accounting	http://localhost/linknest/#/tile/tile_finance?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703690	-81.415403	UTC	\N	\N	\N	\N	\N	\N	28	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:49:57.002854+00
2026-01-25 22:49:56+00	https://invoices.example.com/	link_finance_invoicing	http://localhost/linknest/#/tile/tile_finance?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703690	-81.415403	UTC	\N	\N	\N	\N	\N	\N	39	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:49:57.002854+00
2026-01-25 22:49:56+00	https://finance.example.com/reports	link_finance_reports	http://localhost/linknest/#/tile/tile_finance?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703690	-81.415403	UTC	\N	\N	\N	\N	\N	\N	39	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:49:57.002854+00
2026-01-25 22:50:09+00	https://accounting.example.com/	link_finance_accounting	http://localhost/linknest/#/tile/tile_finance?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703690	-81.415403	UTC	\N	\N	\N	\N	\N	\N	50	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:50:09.096422+00
2026-01-25 22:50:09+00	https://invoices.example.com/	link_finance_invoicing	http://localhost/linknest/#/tile/tile_finance?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703690	-81.415403	UTC	\N	\N	\N	\N	\N	\N	43	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:50:09.096422+00
2026-01-25 22:50:09+00	https://finance.example.com/reports	link_finance_reports	http://localhost/linknest/#/tile/tile_finance?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703690	-81.415403	UTC	\N	\N	\N	\N	\N	\N	50	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:50:09.096422+00
2026-01-25 22:50:13+00	https://customers.example.com/	link_cust_portal	http://localhost/linknest/#/tile/tile_customer_portal?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703690	-81.415403	UTC	\N	\N	\N	\N	\N	\N	31	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:50:15.145867+00
2026-01-25 22:50:13+00	https://support.example.com/	link_cust_support	http://localhost/linknest/#/tile/tile_customer_portal?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703690	-81.415403	UTC	\N	\N	\N	\N	\N	\N	33	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:50:15.145867+00
2026-01-25 22:50:13+00	https://tickets.example.com/	link_cust_tickets	http://localhost/linknest/#/tile/tile_customer_portal?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703690	-81.415403	UTC	\N	\N	\N	\N	\N	\N	49	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:50:15.145867+00
2026-01-25 22:50:18+00	https://nagios.example.com/	link_servers_nagios	http://localhost/linknest/#/tile/tile_servers?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703690	-81.415403	UTC	\N	\N	\N	\N	\N	\N	32	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:50:19.175642+00
2026-01-25 22:50:18+00	https://config.example.com/	link_servers_config	http://localhost/linknest/#/tile/tile_servers?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703690	-81.415403	UTC	\N	\N	\N	\N	\N	\N	49	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:50:19.175642+00
2026-01-25 22:50:20+00	https://nagios.example.com/	link_servers_nagios	http://localhost/linknest/#/tile/tile_servers?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703690	-81.415403	UTC	\N	\N	\N	\N	\N	\N	38	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:50:21.200363+00
2026-01-25 22:50:20+00	https://config.example.com/	link_servers_config	http://localhost/linknest/#/tile/tile_servers?from=public	client	2	admin	bt7dgr3u28nerma8v5hhnpp7p7	t	::1	\N	US	United States	Florida	Wekiwa Springs	28.703690	-81.415403	UTC	\N	\N	\N	\N	\N	\N	37	\N	0	Failed to fetch	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:50:21.200363+00
2026-01-25 22:59:00+00	https://stackoverflow.com/	\N	http://localhost:9333/diagnostic.html	client	1	zafar	diagnostic-1769381937246	t	::1	\N	XX	Unknown	Unknown	Unknown	0.000000	0.000000	UTC	\N	0	0	0	0	\N	326	\N	0	\N	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:59:00.11905+00
2026-01-25 22:59:00+00	https://google.com/	\N	http://localhost:9333/diagnostic.html	client	1	zafar	diagnostic-1769381937246	t	::1	\N	XX	Unknown	Unknown	Unknown	0.000000	0.000000	UTC	\N	0	0	0	0	\N	689	\N	0	\N	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:59:00.11905+00
2026-01-25 22:59:00+00	https://github.com/	\N	http://localhost:9333/diagnostic.html	client	1	zafar	diagnostic-1769381937246	t	::1	\N	XX	Unknown	Unknown	Unknown	0.000000	0.000000	UTC	\N	0	0	0	0	\N	158	\N	0	\N	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:59:00.11905+00
2026-01-25 22:59:04+00	https://github.com/	\N	http://localhost:9333/diagnostic.html	client	1	zafar	diagnostic-1769381937246	t	::1	\N	XX	Unknown	Unknown	Unknown	0.000000	0.000000	UTC	\N	0	0	0	0	\N	48	\N	0	\N	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:59:06.166972+00
2026-01-25 22:59:04+00	https://stackoverflow.com/	\N	http://localhost:9333/diagnostic.html	client	1	zafar	diagnostic-1769381937246	t	::1	\N	XX	Unknown	Unknown	Unknown	0.000000	0.000000	UTC	\N	0	0	0	0	\N	216	\N	0	\N	4g	desktop	Chrome	144	Windows	1829x1029	2026-01-25 22:59:06.166972+00
\.


--
-- Data for Name: _materialized_hypertable_3; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: postgres
--

COPY _timescaledb_internal._materialized_hypertable_3 (bucket, link_url, measurement_type, country_code, country_name, region_name, region_center_lat, region_center_lon, measurement_count, unique_users, unique_sessions, authenticated_count, avg_latency, p50_latency, p95_latency, p99_latency, min_latency, max_latency, avg_dns_time, avg_tcp_time, avg_tls_time, avg_ttfb, wifi_count, mobile_4g_count, mobile_5g_count, mobile_count, desktop_count, tablet_count, successful_requests, success_rate_pct) FROM stdin;
\.


--
-- Data for Name: alert_thresholds; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alert_thresholds (id, link_url, country_code, region_name, threshold_type, max_avg_latency, max_p95_latency, max_p99_latency, max_ttfb, max_delta_ms, alert_email, is_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: link_latency_summary; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.link_latency_summary (link_url, link_id, last_client_check, client_avg_latency, client_p50_latency, client_p95_latency, client_p99_latency, client_min_latency, client_max_latency, client_measurement_count, last_server_check, server_avg_latency, server_p50_latency, server_p95_latency, server_p99_latency, server_min_latency, server_max_latency, server_measurement_count, client_country_code, client_region_name, client_city_name, latency_delta, performance_ratio, health_status, updated_at) FROM stdin;
https://example.com/	link_dash_home	2026-01-25 22:46:27+00	38	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	\N	0	US	Florida	Wekiwa Springs	0	\N	excellent	2026-01-25 22:46:27.822425+00
https://portal.example.com/	link_dash_portal	2026-01-25 22:46:27+00	44	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	\N	0	US	Florida	Wekiwa Springs	0	\N	excellent	2026-01-25 22:46:27.822425+00
https://mail.example.com/	link_dash_email	2026-01-25 22:46:27+00	41	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	\N	0	US	Florida	Wekiwa Springs	0	\N	excellent	2026-01-25 22:46:27.822425+00
https://reports.example.com/sales	link_dash_sales	2026-01-25 22:46:27+00	46	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	\N	0	US	Florida	Wekiwa Springs	0	\N	excellent	2026-01-25 22:46:27.822425+00
https://reports.example.com/hr	link_dash_hr	2026-01-25 22:46:27+00	38	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	\N	0	US	Florida	Wekiwa Springs	0	\N	excellent	2026-01-25 22:46:27.822425+00
https://admin.example.com/	link_dash_admin	2026-01-25 22:46:27+00	50	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	\N	0	US	Florida	Wekiwa Springs	0	\N	excellent	2026-01-25 22:46:27.822425+00
https://bi.example.com/	link_analytics_bi	2026-01-25 22:47:20+00	62	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	\N	0	US	Florida	Wekiwa Springs	0	\N	excellent	2026-01-25 22:47:22.149866+00
https://analytics.example.com/	link_analytics_reports	2026-01-25 22:47:20+00	77	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	\N	0	US	Florida	Wekiwa Springs	0	\N	excellent	2026-01-25 22:47:22.149866+00
https://analytics.google.com/	link_analytics_google	2026-01-25 22:47:20+00	159	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	\N	0	US	Florida	Wekiwa Springs	0	\N	good	2026-01-25 22:47:22.149866+00
https://accounting.example.com/	link_finance_accounting	2026-01-25 22:50:09+00	36	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	\N	0	US	Florida	Wekiwa Springs	0	\N	excellent	2026-01-25 22:50:09.096422+00
https://invoices.example.com/	link_finance_invoicing	2026-01-25 22:50:09+00	36	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	\N	0	US	Florida	Wekiwa Springs	0	\N	excellent	2026-01-25 22:50:09.096422+00
https://finance.example.com/reports	link_finance_reports	2026-01-25 22:50:09+00	40	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	\N	0	US	Florida	Wekiwa Springs	0	\N	excellent	2026-01-25 22:50:09.096422+00
https://customers.example.com/	link_cust_portal	2026-01-25 22:50:13+00	31	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-01-25 22:50:15.145867+00
https://support.example.com/	link_cust_support	2026-01-25 22:50:13+00	33	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-01-25 22:50:15.145867+00
https://tickets.example.com/	link_cust_tickets	2026-01-25 22:50:13+00	49	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-01-25 22:50:15.145867+00
https://nagios.example.com/	link_servers_nagios	2026-01-25 22:50:20+00	35	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	\N	0	US	Florida	Wekiwa Springs	0	\N	excellent	2026-01-25 22:50:21.200363+00
https://config.example.com/	link_servers_config	2026-01-25 22:50:20+00	43	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	\N	0	US	Florida	Wekiwa Springs	0	\N	excellent	2026-01-25 22:50:21.200363+00
https://google.com/	\N	2026-01-25 22:59:00+00	689	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-01-25 22:59:00.11905+00
https://github.com/	\N	2026-01-25 22:59:04+00	103	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	\N	0	XX	Unknown	Unknown	0	\N	good	2026-01-25 22:59:06.166972+00
https://stackoverflow.com/	\N	2026-01-25 22:59:04+00	271	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	\N	0	XX	Unknown	Unknown	0	\N	degraded	2026-01-25 22:59:06.166972+00
\.


--
-- Data for Name: location_lookup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.location_lookup (id, country_code, country_name, region_name, city_name, latitude, longitude, population, created_at) FROM stdin;
1	JP	Japan	Tōkyō	Tokyo	35.6870000	139.7495000	37785000	2026-01-25 22:40:04.497497+00
2	ID	Indonesia	Jakarta	Jakarta	-6.1750000	106.8275000	33756000	2026-01-25 22:40:04.497497+00
3	IN	India	Delhi	Delhi	28.6100000	77.2300000	32226000	2026-01-25 22:40:04.497497+00
4	CN	China	Guangdong	Guangzhou	23.1300000	113.2600000	26940000	2026-01-25 22:40:04.497497+00
5	IN	India	Mahārāshtra	Mumbai	19.0761000	72.8775000	24973000	2026-01-25 22:40:04.497497+00
6	PH	Philippines	Manila	Manila	14.5958000	120.9772000	24922000	2026-01-25 22:40:04.497497+00
7	CN	China	Shanghai	Shanghai	31.2286000	121.4747000	24073000	2026-01-25 22:40:04.497497+00
8	BR	Brazil	São Paulo	São Paulo	-23.5504000	-46.6339000	23086000	2026-01-25 22:40:04.497497+00
9	KR	Korea, South	Seoul	Seoul	37.5667000	126.9833000	23016000	2026-01-25 22:40:04.497497+00
10	MX	Mexico	Ciudad de México	Mexico City	19.4333000	-99.1333000	21804000	2026-01-25 22:40:04.497497+00
11	IN	India	West Bengal	Kolkāta	22.5675000	88.3700000	21747000	2026-01-25 22:40:04.497497+00
12	EG	Egypt	Al Qāhirah	Cairo	30.0444000	31.2358000	20296000	2026-01-25 22:40:04.497497+00
13	PK	Pakistan	Sindh	Karachi	24.8600000	67.0100000	20249000	2026-01-25 22:40:04.497497+00
14	BD	Bangladesh	Dhaka	Dhaka	23.7289000	90.3944000	19134000	2026-01-25 22:40:04.497497+00
15	US	United States	New York	New York	40.6943000	-73.9249000	18832416	2026-01-25 22:40:04.497497+00
16	CN	China	Beijing	Beijing	39.9067000	116.3975000	18522000	2026-01-25 22:40:04.497497+00
17	TH	Thailand	Krung Thep Maha Nakhon	Bangkok	13.7525000	100.4942000	18007000	2026-01-25 22:40:04.497497+00
18	CN	China	Guangdong	Shenzhen	22.5415000	114.0596000	17619000	2026-01-25 22:40:04.497497+00
19	RU	Russia	Moskva	Moscow	55.7506000	37.6175000	17332000	2026-01-25 22:40:04.497497+00
20	AR	Argentina	Buenos Aires, Ciudad Autónoma de	Buenos Aires	-34.6036000	-58.3814000	16710000	2026-01-25 22:40:04.497497+00
21	NG	Nigeria	Lagos	Lagos	6.4550000	3.3841000	16637000	2026-01-25 22:40:04.497497+00
22	IN	India	Karnātaka	Bangalore	12.9789000	77.5917000	15386000	2026-01-25 22:40:04.497497+00
23	VN	Vietnam	Hồ Chí Minh	Ho Chi Minh City	10.7756000	106.7019000	15136000	2026-01-25 22:40:04.497497+00
24	JP	Japan	Ōsaka	Ōsaka	34.6939000	135.5022000	15126000	2026-01-25 22:40:04.497497+00
25	CN	China	Sichuan	Chengdu	30.6600000	104.0633000	14645000	2026-01-25 22:40:04.497497+00
26	TR	Turkey	İstanbul	Istanbul	41.0136000	28.9550000	14441000	2026-01-25 22:40:04.497497+00
27	IR	Iran	Tehrān	Tehran	35.6889000	51.3897000	14148000	2026-01-25 22:40:04.497497+00
28	CD	Congo (Kinshasa)	Kinshasa	Kinshasa	-4.3219000	15.3119000	12836000	2026-01-25 22:40:04.497497+00
29	BR	Brazil	Rio de Janeiro	Rio de Janeiro	-22.9111000	-43.2056000	12592000	2026-01-25 22:40:04.497497+00
30	IN	India	Tamil Nādu	Chennai	13.0825000	80.2750000	12395000	2026-01-25 22:40:04.497497+00
31	CN	China	Shaanxi	Xi’an	34.2611000	108.9422000	12328000	2026-01-25 22:40:04.497497+00
32	PK	Pakistan	Punjab	Lahore	31.5497000	74.3436000	12306000	2026-01-25 22:40:04.497497+00
33	CN	China	Chongqing	Chongqing	29.5637000	106.5504000	12135000	2026-01-25 22:40:04.497497+00
34	US	United States	California	Los Angeles	34.1141000	-118.4068000	11885717	2026-01-25 22:40:04.497497+00
35	GB	United Kingdom	London, City of	London	51.5072000	-0.1275000	11262000	2026-01-25 22:40:04.497497+00
36	FR	France	Île-de-France	Paris	48.8567000	2.3522000	11060000	2026-01-25 22:40:04.497497+00
37	CN	China	Shandong	Linyi	35.1038000	118.3564000	10820000	2026-01-25 22:40:04.497497+00
38	CN	China	Guangdong	Dongguan	23.0210000	113.7520000	10646000	2026-01-25 22:40:04.497497+00
39	CN	China	Hebei	Baoding	38.8740000	115.4640000	10546831	2026-01-25 22:40:04.497497+00
40	IN	India	Telangāna	Hyderābād	17.3617000	78.4747000	10494000	2026-01-25 22:40:04.497497+00
41	CN	China	Tianjin	Tianjin	39.1336000	117.2054000	10368000	2026-01-25 22:40:04.497497+00
42	PE	Peru	Lima	Lima	-12.0600000	-77.0375000	10320000	2026-01-25 22:40:04.497497+00
43	CN	China	Hubei	Wuhan	30.5934000	114.3046000	10251000	2026-01-25 22:40:04.497497+00
44	CN	China	Henan	Nanyang	32.9902000	112.5285000	9577771	2026-01-25 22:40:04.497497+00
45	CN	China	Zhejiang	Hangzhou	30.2670000	120.1530000	9523000	2026-01-25 22:40:04.497497+00
46	JP	Japan	Aichi	Nagoya	35.1833000	136.9000000	9197000	2026-01-25 22:40:04.497497+00
47	AO	Angola	Luanda	Luanda	-8.8383000	13.2344000	9051000	2026-01-25 22:40:04.497497+00
48	CN	China	Guangdong	Foshan	23.0214000	113.1216000	9042500	2026-01-25 22:40:04.497497+00
49	MY	Malaysia	Kuala Lumpur	Kuala Lumpur	3.1686000	101.6980000	8911000	2026-01-25 22:40:04.497497+00
50	CN	China	Henan	Zhoukou	33.6367000	114.7014000	8677800	2026-01-25 22:40:04.497497+00
51	CN	China	Jiangsu	Tongshan	34.2610000	117.1859000	8669000	2026-01-25 22:40:04.497497+00
52	VN	Vietnam	Hà Nội	Hanoi	21.0000000	105.8500000	8587100	2026-01-25 22:40:04.497497+00
53	US	United States	Illinois	Chicago	41.8375000	-87.6866000	8489066	2026-01-25 22:40:04.497497+00
54	CN	China	Jiangsu	Nanjing	32.0608000	118.7789000	8422000	2026-01-25 22:40:04.497497+00
55	CN	China	Shandong	Heze	35.2343000	115.4796000	8287693	2026-01-25 22:40:04.497497+00
56	IN	India	Mahārāshtra	Pune	18.5203000	73.8567000	8231000	2026-01-25 22:40:04.497497+00
57	CN	China	Shandong	Jining	35.4151000	116.5871000	8081905	2026-01-25 22:40:04.497497+00
58	CO	Colombia	Bogotá	Bogotá	4.7111000	-74.0722000	8034649	2026-01-25 22:40:04.497497+00
59	IN	India	Gujarāt	Ahmedabad	23.0225000	72.5714000	8009000	2026-01-25 22:40:04.497497+00
60	CN	China	Liaoning	Shenyang	41.8025000	123.4281000	7964000	2026-01-25 22:40:04.497497+00
61	TZ	Tanzania	Dar es Salaam	Dar es Salaam	-6.8161000	39.2803000	7962000	2026-01-25 22:40:04.497497+00
62	SD	Sudan	Khartoum	Khartoum	15.6031000	32.5265000	7869000	2026-01-25 22:40:04.497497+00
63	ZA	South Africa	Gauteng	Johannesburg	-26.2044000	28.0456000	7860781	2026-01-25 22:40:04.497497+00
64	CN	China	Anhui	Fuyang	32.8900000	115.8140000	7599913	2026-01-25 22:40:04.497497+00
65	HK	Hong Kong	\N	Hong Kong	22.3000000	114.2000000	7450000	2026-01-25 22:40:04.497497+00
66	CN	China	Jiangxi	Ganzhou	25.8310000	114.9330000	7396873	2026-01-25 22:40:04.497497+00
67	CN	China	Henan	Shangqiu	34.4150000	115.6560000	7325300	2026-01-25 22:40:04.497497+00
68	CN	China	Hebei	Cangzhou	38.3047000	116.8387000	7300783	2026-01-25 22:40:04.497497+00
69	SA	Saudi Arabia	Ar Riyāḑ	Riyadh	24.6500000	46.7100000	7237000	2026-01-25 22:40:04.497497+00
70	CL	Chile	Región Metropolitana	Santiago	-33.4372000	-70.6506000	7171000	2026-01-25 22:40:04.497497+00
71	CN	China	Henan	Zhumadian	33.0140000	114.0220000	7008427	2026-01-25 22:40:04.497497+00
72	CN	China	Guangdong	Zhanjiang	21.2701000	110.3575000	6981236	2026-01-25 22:40:04.497497+00
73	MM	Burma	Yangon	Rangoon	16.7950000	96.1600000	6874000	2026-01-25 22:40:04.497497+00
74	CN	China	Jiangsu	Yancheng	33.3500000	120.1569000	6709629	2026-01-25 22:40:04.497497+00
75	CN	China	Guizhou	Bijie	27.2840000	105.2920000	6686100	2026-01-25 22:40:04.497497+00
76	CN	China	Hebei	Xingtai	37.0717000	114.5048000	6645766	2026-01-25 22:40:04.497497+00
77	CN	China	Hunan	Hengyang	26.8940000	112.5720000	6645243	2026-01-25 22:40:04.497497+00
78	CN	China	Hunan	Shaoyang	27.2395000	111.4679000	6563520	2026-01-25 22:40:04.497497+00
79	ID	Indonesia	Jawa Timur	Surabaya	-7.2458000	112.7378000	6556000	2026-01-25 22:40:04.497497+00
80	IN	India	Gujarāt	Sūrat	21.2050000	72.8400000	6538000	2026-01-25 22:40:04.497497+00
81	CN	China	Fujian	Quanzhou	24.8744000	118.6757000	6480000	2026-01-25 22:40:04.497497+00
82	CN	China	Jiangxi	Shangrao	28.4551000	117.9431000	6435300	2026-01-25 22:40:04.497497+00
83	CN	China	Guizhou	Zunyi	27.7220000	107.0310000	6270700	2026-01-25 22:40:04.497497+00
84	ES	Spain	Madrid	Madrid	40.4169000	-3.7033000	6211000	2026-01-25 22:40:04.497497+00
85	IQ	Iraq	Baghdād	Baghdad	33.3153000	44.3661000	6183000	2026-01-25 22:40:04.497497+00
86	CN	China	Guangdong	Maoming	21.6627000	110.9255000	6174050	2026-01-25 22:40:04.497497+00
87	US	United States	Florida	Miami	25.7840000	-80.2101000	6113982	2026-01-25 22:40:04.497497+00
88	CN	China	Henan	Xinyang	32.1490000	114.0910000	6109106	2026-01-25 22:40:04.497497+00
89	US	United States	Texas	Houston	29.7860000	-95.3885000	6046392	2026-01-25 22:40:04.497497+00
90	SG	Singapore	\N	Singapore	1.3000000	103.8000000	5983000	2026-01-25 22:40:04.497497+00
91	IN	India	Uttar Pradesh	Prayagraj	25.4358000	81.8464000	5954391	2026-01-25 22:40:04.497497+00
92	CN	China	Hubei	Huanggang	30.4537000	114.8724000	5882719	2026-01-25 22:40:04.497497+00
93	CN	China	Liaoning	Dalian	38.9000000	121.6000000	5871474	2026-01-25 22:40:04.497497+00
94	TR	Turkey	Ankara	Ankara	39.9300000	32.8500000	5864049	2026-01-25 22:40:04.497497+00
95	US	United States	Texas	Dallas	32.7935000	-96.7667000	5843632	2026-01-25 22:40:04.497497+00
96	CN	China	Shandong	Qingdao	36.0669000	120.3827000	5818255	2026-01-25 22:40:04.497497+00
97	CN	China	Guangxi	Yulin	22.6540000	110.1810000	5796766	2026-01-25 22:40:04.497497+00
98	CN	China	Shandong	Liaocheng	36.4559000	115.9852000	5789863	2026-01-25 22:40:04.497497+00
99	CM	Cameroon	Littoral	Douala	4.0500000	9.7000000	5768400	2026-01-25 22:40:04.497497+00
100	CN	China	Yunnan	Qujing	25.4910000	103.7960000	5765775	2026-01-25 22:40:04.497497+00
101	CN	China	Henan	Nangandao	35.3036000	113.9268000	5708191	2026-01-25 22:40:04.497497+00
102	ET	Ethiopia	Ādīs Ābeba	Addis Ababa	9.0300000	38.7400000	5704000	2026-01-25 22:40:04.497497+00
103	US	United States	Pennsylvania	Philadelphia	40.0077000	-75.1339000	5696588	2026-01-25 22:40:04.497497+00
104	CA	Canada	Ontario	Toronto	43.7417000	-79.3733000	5647656	2026-01-25 22:40:04.497497+00
105	CN	China	Henan	Zhengzhou	34.7640000	113.6840000	5621593	2026-01-25 22:40:04.497497+00
106	CN	China	Sichuan	Nanchong	30.8372000	106.1106000	5607565	2026-01-25 22:40:04.497497+00
107	CN	China	Shandong	Jinan	36.6702000	117.0207000	5606374	2026-01-25 22:40:04.497497+00
108	EG	Egypt	Al Jīzah	Giza	29.9870000	31.2118000	5598402	2026-01-25 22:40:04.497497+00
109	RU	Russia	Sankt-Peterburg	Saint Petersburg	59.9375000	30.3086000	5597763	2026-01-25 22:40:04.497497+00
110	CN	China	Guangdong	Jieyang	23.5510000	116.3727000	5577814	2026-01-25 22:40:04.497497+00
111	CN	China	Shandong	Dezhou	37.4360000	116.3590000	5568235	2026-01-25 22:40:04.497497+00
112	KE	Kenya	Nairobi City	Nairobi	-1.2864000	36.8172000	5545000	2026-01-25 22:40:04.497497+00
113	MX	Mexico	Jalisco	Guadalajara	20.6767000	-103.3475000	5525000	2026-01-25 22:40:04.497497+00
114	CN	China	Shandong	Tai’an	36.2020000	117.0870000	5472217	2026-01-25 22:40:04.497497+00
115	CN	China	Sichuan	Dazhou	31.2093000	107.4678000	5385422	2026-01-25 22:40:04.497497+00
116	BR	Brazil	Minas Gerais	Belo Horizonte	-19.9281000	-43.9419000	5328000	2026-01-25 22:40:04.497497+00
117	CN	China	Anhui	Suzhou	33.6480000	116.9640000	5324476	2026-01-25 22:40:04.497497+00
118	MX	Mexico	Nuevo León	Monterrey	25.6844000	-100.3181000	5324281	2026-01-25 22:40:04.497497+00
119	CN	China	Hunan	Yongzhou	26.4200000	111.6130000	5289824	2026-01-25 22:40:04.497497+00
120	CN	China	Hunan	Changde	29.0310000	111.6990000	5279102	2026-01-25 22:40:04.497497+00
121	CN	China	Hubei	Xiangyang	32.0100000	112.1220000	5260951	2026-01-25 22:40:04.497497+00
122	US	United States	Georgia	Atlanta	33.7628000	-84.4220000	5211164	2026-01-25 22:40:04.497497+00
123	CN	China	Shanghai	Pudong	31.2347000	121.5064000	5187200	2026-01-25 22:40:04.497497+00
124	US	United States	District of Columbia	Washington	38.9047000	-77.0163000	5146120	2026-01-25 22:40:04.497497+00
125	CN	China	Yunnan	Zhaotong	27.3380000	103.7170000	5092611	2026-01-25 22:40:04.497497+00
126	CN	China	Fujian	Zhangzhou	24.5130000	117.6470000	5054328	2026-01-25 22:40:04.497497+00
127	CN	China	Hunan	Yueyang	29.3647000	113.1309000	5051922	2026-01-25 22:40:04.497497+00
128	AU	Australia	Victoria	Melbourne	-37.8142000	144.9631000	5031195	2026-01-25 22:40:04.497497+00
129	CN	China	Jiangxi	Yichun	27.8160000	114.4170000	5007702	2026-01-25 22:40:04.497497+00
130	CI	Côte d’Ivoire	Abidjan	Abidjan	5.3364000	-4.0267000	4980000	2026-01-25 22:40:04.497497+00
131	CN	China	Guangxi	Guilin	25.2750000	110.2960000	4931137	2026-01-25 22:40:04.497497+00
132	CN	China	Henan	Pingdingshan	33.7666000	113.1926000	4904701	2026-01-25 22:40:04.497497+00
133	EG	Egypt	Al Iskandarīyah	Alexandria	31.1975000	29.8925000	4870000	2026-01-25 22:40:04.497497+00
134	CN	China	Anhui	Bozhou	33.8463000	115.7786000	4850657	2026-01-25 22:40:04.497497+00
135	AU	Australia	New South Wales	Sydney	-33.8667000	151.2000000	4840600	2026-01-25 22:40:04.497497+00
136	ES	Spain	Catalonia	Barcelona	41.3833000	2.1833000	4800000	2026-01-25 22:40:04.497497+00
137	CN	China	Shanxi	Yuncheng	35.0267000	111.0070000	4774508	2026-01-25 22:40:04.497497+00
138	ZA	South Africa	Western Cape	Cape Town	-33.9253000	18.4239000	4770313	2026-01-25 22:40:04.497497+00
139	CN	China	Hunan	Changsha	28.2280000	112.9390000	4766296	2026-01-25 22:40:04.497497+00
140	CN	China	Jiangsu	Suqian	33.9630000	118.2750000	4719178	2026-01-25 22:40:04.497497+00
141	SA	Saudi Arabia	Makkah al Mukarramah	Jeddah	21.5428000	39.1728000	4697000	2026-01-25 22:40:04.497497+00
142	CN	China	Shaanxi	Weinan	34.5206000	109.4710000	4688744	2026-01-25 22:40:04.497497+00
143	DE	Germany	Berlin	Berlin	52.5200000	13.4050000	4679500	2026-01-25 22:40:04.497497+00
144	CN	China	Hunan	Chenzhou	25.7700000	113.0160000	4667134	2026-01-25 22:40:04.497497+00
145	CN	China	Guangdong	Jiangmen	22.5789000	113.0815000	4630300	2026-01-25 22:40:04.497497+00
146	CN	China	Sichuan	Mianyang	31.4680000	104.6790000	4613862	2026-01-25 22:40:04.497497+00
147	CN	China	Jiangxi	Jiujiang	29.6610000	115.9540000	4600276	2026-01-25 22:40:04.497497+00
148	CN	China	Hunan	Huaihua	27.5698000	110.0016000	4587594	2026-01-25 22:40:04.497497+00
149	CN	China	Henan	Huanglongsi	34.7950000	114.3450000	4564900	2026-01-25 22:40:04.497497+00
150	CN	China	Jiangsu	Taizhou	32.4567000	119.9229000	4512762	2026-01-25 22:40:04.497497+00
151	IN	India	Bihār	Belāhi	26.4000000	86.2500000	4487379	2026-01-25 22:40:04.497497+00
152	CN	China	Sichuan	Yibin	28.7520000	104.6430000	4471896	2026-01-25 22:40:04.497497+00
153	CN	China	Jiangxi	Ji’an	27.0912000	114.9668000	4469176	2026-01-25 22:40:04.497497+00
154	CN	China	Jiangsu	Yangzhou	32.3944000	119.4128000	4459760	2026-01-25 22:40:04.497497+00
155	CN	China	Yunnan	Kunming	25.0464000	102.7094000	4422686	2026-01-25 22:40:04.497497+00
156	CN	China	Jilin	Changchun	43.8970000	125.3260000	4408154	2026-01-25 22:40:04.497497+00
157	CN	China	Anhui	Lu’an	31.7360000	116.5200000	4393699	2026-01-25 22:40:04.497497+00
158	CN	China	Jiangsu	Xinpu	34.5966000	119.2214000	4393482	2026-01-25 22:40:04.497497+00
159	CN	China	Hebei	Langfang	39.5383000	116.6835000	4358839	2026-01-25 22:40:04.497497+00
160	US	United States	Massachusetts	Boston	42.3188000	-71.0852000	4355184	2026-01-25 22:40:04.497497+00
161	CN	China	Xinjiang	Ürümqi	43.8225000	87.6125000	4335017	2026-01-25 22:40:04.497497+00
162	CN	China	Jiangsu	Suzhou	31.3000000	120.6194000	4330000	2026-01-25 22:40:04.497497+00
163	CN	China	Guangxi	Guigang	23.1120000	109.5990000	4316262	2026-01-25 22:40:04.497497+00
164	CN	China	Guangdong	Shantou	23.3540000	116.6820000	4312192	2026-01-25 22:40:04.497497+00
165	CN	China	Henan	Jiangguanchi	34.0370000	113.8520000	4307488	2026-01-25 22:40:04.497497+00
166	AF	Afghanistan	Kābul	Kabul	34.5253000	69.1783000	4273156	2026-01-25 22:40:04.497497+00
167	CN	China	Hubei	Xiaoganzhan	30.9180000	113.9570000	4270371	2026-01-25 22:40:04.497497+00
168	ML	Mali	Bamako	Bamako	12.6458000	-7.9922000	4227569	2026-01-25 22:40:04.497497+00
169	NG	Nigeria	Kano	Kano	12.0000000	8.5167000	4224966	2026-01-25 22:40:04.497497+00
170	CN	China	Sichuan	Luzhou	28.8710000	105.4420000	4218427	2026-01-25 22:40:04.497497+00
171	CN	China	Anhui	Hefei	31.8206000	117.2273000	4216940	2026-01-25 22:40:04.497497+00
172	CN	China	Hebei	Hengshui	37.7390000	115.6690000	4212933	2026-01-25 22:40:04.497497+00
173	BR	Brazil	Ceará	Fortaleza	-3.7275000	-38.5275000	4167996	2026-01-25 22:40:04.497497+00
174	CN	China	Anhui	Anqing	30.5318000	117.1153000	4165284	2026-01-25 22:40:04.497497+00
175	CN	China	Hebei	Zhangjiakou	40.7690000	114.8860000	4118908	2026-01-25 22:40:04.497497+00
176	CN	China	Guangdong	Zhaoqing	23.0500000	112.4667000	4113594	2026-01-25 22:40:04.497497+00
177	CN	China	Hebei	Shijiazhuang	38.0425000	114.5100000	4098243	2026-01-25 22:40:04.497497+00
178	CN	China	Zhejiang	Ningbo	29.8603000	121.6245000	4087523	2026-01-25 22:40:04.497497+00
179	CN	China	Heilongjiang	Qiqihar	47.3549000	123.9182000	4067489	2026-01-25 22:40:04.497497+00
180	US	United States	Arizona	Phoenix	33.5722000	-112.0892000	4065338	2026-01-25 22:40:04.497497+00
181	CN	China	Guangxi	Liuzhou	24.3278000	109.4278000	4041700	2026-01-25 22:40:04.497497+00
182	CN	China	Inner Mongolia	Chifeng	42.2550000	118.8825000	4035967	2026-01-25 22:40:04.497497+00
183	CN	China	Hubei	Xiaoxita	30.6920000	111.2870000	4017607	2026-01-25 22:40:04.497497+00
184	JO	Jordan	Al ‘Āşimah	Amman	31.9497000	35.9328000	4007526	2026-01-25 22:40:04.497497+00
185	CN	China	Shanxi	Linfen	36.0880000	111.5190000	3976481	2026-01-25 22:40:04.497497+00
186	CN	China	Shaanxi	Xianyang	34.3299000	108.7088000	3959842	2026-01-25 22:40:04.497497+00
187	CN	China	Anhui	Chuzhou	32.2560000	118.3330000	3937868	2026-01-25 22:40:04.497497+00
188	GH	Ghana	Ashanti	Kumasi	6.7000000	-1.6250000	3903480	2026-01-25 22:40:04.497497+00
189	CN	China	Hunan	Zhuzhou	27.8290000	113.1330000	3902738	2026-01-25 22:40:04.497497+00
190	CN	China	Shanxi	Taiyuan	37.8704000	112.5497000	3875053	2026-01-25 22:40:04.497497+00
191	CN	China	Guangdong	Qingyuan	23.6820000	113.0560000	3874000	2026-01-25 22:40:04.497497+00
192	CN	China	Guangdong	Meizhou	24.2890000	116.1220000	3873239	2026-01-25 22:40:04.497497+00
193	CN	China	Hunan	Yiyang	28.5549000	112.3560000	3851564	2026-01-25 22:40:04.497497+00
194	CN	China	Guangxi	Nanning	22.8167000	108.3275000	3837978	2026-01-25 22:40:04.497497+00
195	CN	China	Heilongjiang	Harbin	45.7576000	126.6409000	3830000	2026-01-25 22:40:04.497497+00
196	CN	China	Hunan	Loudi	27.6998000	111.9944000	3826996	2026-01-25 22:40:04.497497+00
197	NG	Nigeria	Federal Capital Territory	Abuja	9.0667000	7.4833000	3770000	2026-01-25 22:40:04.497497+00
198	JP	Japan	Kanagawa	Yokohama	35.4442000	139.6381000	3757630	2026-01-25 22:40:04.497497+00
199	CN	China	Heilongjiang	Suihua	46.6540000	126.9690000	3756167	2026-01-25 22:40:04.497497+00
200	CN	China	Shandong	Binzhou	37.3830000	117.9710000	3748474	2026-01-25 22:40:04.497497+00
201	CN	China	Shandong	Zaozhuang	34.8109000	117.3238000	3729140	2026-01-25 22:40:04.497497+00
202	US	United States	Michigan	Detroit	42.3834000	-83.1024000	3716929	2026-01-25 22:40:04.497497+00
203	CN	China	Fujian	Xiamen	24.4796000	118.0889000	3707090	2026-01-25 22:40:04.497497+00
204	IR	Iran	Khorāsān-e Raẕavī	Mashhad	36.3264000	59.5433000	3700000	2026-01-25 22:40:04.497497+00
205	CA	Canada	Quebec	Montréal	45.5089000	-73.5617000	3675219	2026-01-25 22:40:04.497497+00
206	CN	China	Fujian	Fuzhou	26.0743000	119.2964000	3671192	2026-01-25 22:40:04.497497+00
207	CN	China	Anhui	Wuhu	31.3526000	118.4331000	3644420	2026-01-25 22:40:04.497497+00
208	ID	Indonesia	Sumatera Utara	Medan	3.5894000	98.6739000	3632000	2026-01-25 22:40:04.497497+00
209	CN	China	Shaanxi	Yulinshi	38.2858000	109.7341000	3624750	2026-01-25 22:40:04.497497+00
210	CN	China	Jiangxi	Fuzhou	27.9490000	116.3580000	3614866	2026-01-25 22:40:04.497497+00
211	CN	China	Zhejiang	Wenzhou	27.9938000	120.6993000	3604446	2026-01-25 22:40:04.497497+00
212	CN	China	Jiangsu	Changzhou	31.8110000	119.9740000	3601079	2026-01-25 22:40:04.497497+00
213	CN	China	Henan	Puyang	35.7627000	115.0292000	3598740	2026-01-25 22:40:04.497497+00
214	CN	China	Jiangxi	Nanchang	28.6830000	115.8580000	3576547	2026-01-25 22:40:04.497497+00
215	CN	China	Guangxi	Baicheng	23.9030000	106.6190000	3571505	2026-01-25 22:40:04.497497+00
216	US	United States	Washington	Seattle	47.6211000	-122.3244000	3555253	2026-01-25 22:40:04.497497+00
217	NG	Nigeria	Oyo	Ibadan	7.3964000	3.9167000	3552000	2026-01-25 22:40:04.497497+00
218	CN	China	Henan	Jiaozuo	35.2157000	113.2419000	3521078	2026-01-25 22:40:04.497497+00
219	IN	India	Tamil Nādu	Nādampālaiyam	11.0125000	76.9714000	3458045	2026-01-25 22:40:04.497497+00
220	CN	China	Sichuan	Deyang	31.1270000	104.3980000	3456161	2026-01-25 22:40:04.497497+00
221	KR	Korea, South	Busan	Busan	35.1800000	129.0750000	3453198	2026-01-25 22:40:04.497497+00
222	CN	China	Guangxi	Hechi	24.6930000	108.0850000	3417945	2026-01-25 22:40:04.497497+00
223	CN	China	Hebei	Tangshan	39.6294000	118.1739000	3399231	2026-01-25 22:40:04.497497+00
224	IN	India	Uttar Pradesh	Lucknow	26.8500000	80.9500000	3382000	2026-01-25 22:40:04.497497+00
225	US	United States	California	San Francisco	37.7558000	-122.4449000	3364862	2026-01-25 22:40:04.497497+00
226	GH	Ghana	Ashanti	Boankra	6.6919000	-1.4051000	3348000	2026-01-25 22:40:04.497497+00
227	AE	United Arab Emirates	Dubayy	Dubai	25.2631000	55.2972000	3331420	2026-01-25 22:40:04.497497+00
228	CN	China	Liaoning	Anshan	41.1080000	122.9940000	3325372	2026-01-25 22:40:04.497497+00
229	CN	China	Shaanxi	Guozhen	34.3609000	107.1751000	3321853	2026-01-25 22:40:04.497497+00
230	CN	China	Shaanxi	Baojishi	34.3630000	107.2380000	3321853	2026-01-25 22:40:04.497497+00
231	CN	China	Guangxi	Qinzhou	21.9810000	108.6540000	3302238	2026-01-25 22:40:04.497497+00
232	CN	China	Guizhou	Guiyang	26.6470000	106.6300000	3299724	2026-01-25 22:40:04.497497+00
233	CN	China	Jiangsu	Wuxi	31.5667000	120.2833000	3245179	2026-01-25 22:40:04.497497+00
234	IN	India	Kerala	Kannankulam	10.5200000	76.2100000	3243170	2026-01-25 22:40:04.497497+00
235	VE	Venezuela	Distrito Capital	Caracas	10.4806000	-66.9036000	3242000	2026-01-25 22:40:04.497497+00
236	PK	Pakistan	Punjab	Kotla Qasim Khan	32.5833000	73.7500000	3219375	2026-01-25 22:40:04.497497+00
237	MA	Morocco	Casablanca-Settat	Casablanca	33.5333000	-7.5833000	3215935	2026-01-25 22:40:04.497497+00
238	CN	China	Shaanxi	Hanzhong	33.0664000	107.0232000	3211462	2026-01-25 22:40:04.497497+00
239	CN	China	Hubei	Shiyan	32.6290000	110.7987000	3209004	2026-01-25 22:40:04.497497+00
240	CN	China	Sichuan	Guang’an	30.4564000	106.6326000	3205476	2026-01-25 22:40:04.497497+00
241	PK	Pakistan	Punjab	Faisalabad	31.4167000	73.0911000	3203846	2026-01-25 22:40:04.497497+00
242	CN	China	Shanxi	Changzhi	36.1950000	113.1170000	3180884	2026-01-25 22:40:04.497497+00
243	CN	China	Guizhou	Tongren	27.7316000	109.1895000	3168800	2026-01-25 22:40:04.497497+00
244	CN	China	Anhui	Bengbu	32.9170000	117.3890000	3164467	2026-01-25 22:40:04.497497+00
245	CN	China	Sichuan	Leshan	29.5520000	103.7660000	3160168	2026-01-25 22:40:04.497497+00
246	BO	Bolivia	Santa Cruz	Santa Cruz de la Sierra	-17.7892000	-63.1975000	3151676	2026-01-25 22:40:04.497497+00
247	CN	China	Sichuan	Neijiang	29.5802000	105.0580000	3140678	2026-01-25 22:40:04.497497+00
248	CN	China	Jiangsu	Zhenjiang	32.1880000	119.4240000	3113384	2026-01-25 22:40:04.497497+00
249	CN	China	Hebei	Qinhuangdao	39.8882000	119.5202000	3107400	2026-01-25 22:40:04.497497+00
250	TR	Turkey	Bursa	Bursa	40.1833000	29.0500000	3101833	2026-01-25 22:40:04.497497+00
251	UZ	Uzbekistan	Toshkent	Tashkent	41.3111000	69.2797000	3095498	2026-01-25 22:40:04.497497+00
252	EC	Ecuador	Guayas	Guayaquil	-2.1900000	-79.8875000	3094420	2026-01-25 22:40:04.497497+00
253	IN	India	Rājasthān	Jaipur	26.9000000	75.8000000	3073350	2026-01-25 22:40:04.497497+00
254	CN	China	Gansu	Lanzhou	36.0606000	103.8268000	3067141	2026-01-25 22:40:04.497497+00
255	BF	Burkina Faso	Centre	Ouagadougou	12.3686000	-1.5275000	3063271	2026-01-25 22:40:04.497497+00
256	GR	Greece	Attikí	Athens	37.9842000	23.7281000	3059764	2026-01-25 22:40:04.497497+00
257	US	United States	California	San Diego	32.8313000	-117.1222000	3057778	2026-01-25 22:40:04.497497+00
258	GT	Guatemala	Guatemala	Guatemala City	14.6417000	-90.5133000	3014000	2026-01-25 22:40:04.497497+00
259	KW	Kuwait	Al ‘Āşimah	Kuwait City	29.3697000	47.9783000	2989000	2026-01-25 22:40:04.497497+00
260	CN	China	Gansu	Qincheng	34.5815000	105.7248000	2984659	2026-01-25 22:40:04.497497+00
261	TR	Turkey	İzmir	İzmir	38.4200000	27.1400000	2965900	2026-01-25 22:40:04.497497+00
262	PH	Philippines	Quezon	Quezon City	14.6500000	121.0475000	2960048	2026-01-25 22:40:04.497497+00
263	UA	Ukraine	Kyiv, Misto	Kyiv	50.4500000	30.5233000	2952301	2026-01-25 22:40:04.497497+00
264	IN	India	Kerala	Kottārasshēri	10.7750000	76.6510000	2952254	2026-01-25 22:40:04.497497+00
265	CN	China	Sichuan	Meishan	30.0771000	103.8484000	2950545	2026-01-25 22:40:04.497497+00
266	KR	Korea, South	Incheon	Incheon	37.4833000	126.6333000	2936117	2026-01-25 22:40:04.497497+00
267	CN	China	Fujian	Ningde	26.6662000	119.5477000	2910000	2026-01-25 22:40:04.497497+00
268	CN	China	Guangdong	Zhongshan	22.5170000	113.3925000	2909633	2026-01-25 22:40:04.497497+00
269	US	United States	Minnesota	Minneapolis	44.9635000	-93.2678000	2906807	2026-01-25 22:40:04.497497+00
270	US	United States	Florida	Tampa	27.9945000	-82.4447000	2906035	2026-01-25 22:40:04.497497+00
271	CN	China	Fujian	Putian	25.4526000	119.0078000	2900000	2026-01-25 22:40:04.497497+00
272	CD	Congo (Kinshasa)	Kasaï Oriental	Mbuji-Mayi	-6.1500000	23.6000000	2892000	2026-01-25 22:40:04.497497+00
273	CN	China	Inner Mongolia	Tongliao	43.6540000	122.2430000	2873168	2026-01-25 22:40:04.497497+00
274	CN	China	Liaoning	Chaoyang	41.5710000	120.4530000	2872857	2026-01-25 22:40:04.497497+00
275	CN	China	Inner Mongolia	Hohhot	40.8420000	111.7490000	2866615	2026-01-25 22:40:04.497497+00
276	KP	Korea, North	P’yŏngyang	Pyongyang	39.0167000	125.7475000	2863000	2026-01-25 22:40:04.497497+00
277	CN	China	Guangdong	Shaoguan	24.8110000	113.5970000	2855131	2026-01-25 22:40:04.497497+00
278	TW	Taiwan	Taichung	Taichung	24.1439000	120.6794000	2850285	2026-01-25 22:40:04.497497+00
279	CO	Colombia	Valle del Cauca	Cali	3.4206000	-76.5222000	2838333	2026-01-25 22:40:04.497497+00
280	CN	China	Guangdong	Heyuan	23.7443000	114.7002000	2837686	2026-01-25 22:40:04.497497+00
281	CN	China	Guangxi	Wuzhou	23.4767000	111.2790000	2820977	2026-01-25 22:40:04.497497+00
282	ZA	South Africa	Gauteng	Pretoria	-25.7461000	28.1881000	2818100	2026-01-25 22:40:04.497497+00
283	CN	China	Sichuan	Suining	30.5330000	105.5930000	2814196	2026-01-25 22:40:04.497497+00
284	SD	Sudan	Khartoum	Omdurman	15.6835000	32.4629000	2805396	2026-01-25 22:40:04.497497+00
285	CN	China	Shandong	Weihai	37.5133000	122.1205000	2804771	2026-01-25 22:40:04.497497+00
286	CN	China	Shandong	Rizhao	35.4170000	119.5270000	2801013	2026-01-25 22:40:04.497497+00
287	ID	Indonesia	Jawa Timur	Malang	-7.9800000	112.6200000	2795209	2026-01-25 22:40:04.497497+00
288	DE	Germany	Baden-Württemberg	Stuttgart	48.7775000	9.1800000	2787724	2026-01-25 22:40:04.497497+00
289	CN	China	Heilongjiang	Daqing	46.5890000	125.1040000	2781562	2026-01-25 22:40:04.497497+00
290	IT	Italy	Lazio	Rome	41.8931000	12.4828000	2748109	2026-01-25 22:40:04.497497+00
291	TW	Taiwan	Kaohsiung	Kaohsiung	22.6150000	120.2975000	2737660	2026-01-25 22:40:04.497497+00
292	US	United States	New York	Brooklyn	40.6501000	-73.9496000	2736074	2026-01-25 22:40:04.497497+00
293	CN	China	Hunan	Xiangtan	27.8313000	112.9454000	2726181	2026-01-25 22:40:04.497497+00
294	CN	China	Sichuan	Bazhou	31.8680000	106.7480000	2712894	2026-01-25 22:40:04.497497+00
295	CN	China	Hebei	Handan	36.6010000	114.4870000	2708015	2026-01-25 22:40:04.497497+00
296	AU	Australia	Queensland	Brisbane	-27.4678000	153.0281000	2706966	2026-01-25 22:40:04.497497+00
297	CN	China	Liaoning	Jinzhou	41.1290000	121.1480000	2703853	2026-01-25 22:40:04.497497+00
298	US	United States	Colorado	Denver	39.7620000	-104.8758000	2691349	2026-01-25 22:40:04.497497+00
299	CN	China	Shanxi	Xinzhou	38.4160000	112.7340000	2689668	2026-01-25 22:40:04.497497+00
300	CN	China	Fujian	Nanping	26.6418000	118.1774000	2680645	2026-01-25 22:40:04.497497+00
301	BD	Bangladesh	Dhaka	Gāzipura	23.9234000	90.3959000	2674697	2026-01-25 22:40:04.497497+00
302	CN	China	Guangdong	Shanwei	22.7872000	115.3756000	2672819	2026-01-25 22:40:04.497497+00
303	VE	Venezuela	Zulia	Maracaibo	10.6333000	-71.6333000	2658355	2026-01-25 22:40:04.497497+00
304	CN	China	Guangdong	Chaozhou	23.6580000	116.6220000	2656600	2026-01-25 22:40:04.497497+00
305	CN	China	Inner Mongolia	Baotou	40.6213000	109.9532000	2650364	2026-01-25 22:40:04.497497+00
306	CN	China	Fujian	Longyan	25.0760000	117.0170000	2640000	2026-01-25 22:40:04.497497+00
307	CN	China	Shandong	Weifang	36.7080000	119.1620000	2636154	2026-01-25 22:40:04.497497+00
308	CN	China	Jiangsu	Huai’an	33.5510000	119.1130000	2632788	2026-01-25 22:40:04.497497+00
309	CN	China	Shandong	Zibo	36.8138000	118.0550000	2631647	2026-01-25 22:40:04.497497+00
310	IN	India	Kerala	Attadappa	11.8689000	75.3555000	2615266	2026-01-25 22:40:04.497497+00
311	DE	Germany	Bavaria	Munich	48.1375000	11.5750000	2606021	2026-01-25 22:40:04.497497+00
312	CN	China	Fujian	Gulou	26.0865000	119.2980000	2606000	2026-01-25 22:40:04.497497+00
313	GB	United Kingdom	Birmingham	Birmingham	52.4800000	-1.9025000	2590363	2026-01-25 22:40:04.497497+00
314	VE	Venezuela	Carabobo	Valencia	10.1833000	-68.0000000	2585202	2026-01-25 22:40:04.497497+00
315	SY	Syria	Dimashq	Damascus	33.5020000	36.2981000	2584771	2026-01-25 22:40:04.497497+00
316	BD	Bangladesh	Chattogram	Chattogram	22.3350000	91.8325000	2581643	2026-01-25 22:40:04.497497+00
317	CG	Congo (Brazzaville)	Brazzaville	Brazzaville	-4.2667000	15.2667000	2557100	2026-01-25 22:40:04.497497+00
318	CN	China	Guangdong	Yangjiang	21.8570000	111.9830000	2555600	2026-01-25 22:40:04.497497+00
319	YE	Yemen	Amānat al ‘Āşimah	Sanaa	15.3483000	44.2064000	2545000	2026-01-25 22:40:04.497497+00
320	IN	India	Madhya Pradesh	Barmhān Kalān	19.1972000	72.9722000	2537000	2026-01-25 22:40:04.497497+00
321	CO	Colombia	Antioquia	Medellín	6.2308000	-75.5906000	2529403	2026-01-25 22:40:04.497497+00
322	CN	China	Gansu	Dingxi	35.6080000	104.5920000	2524097	2026-01-25 22:40:04.497497+00
323	CN	China	Zhejiang	Shaoxing	30.0511000	120.5833000	2521964	2026-01-25 22:40:04.497497+00
324	CN	China	Shandong	Yantai	37.4646000	121.4478000	2511053	2026-01-25 22:40:04.497497+00
325	CN	China	Guangdong	Huizhou	23.1120000	114.4160000	2509243	2026-01-25 22:40:04.497497+00
326	CN	China	Anhui	Xuanzhou	30.9390000	118.7590000	2500063	2026-01-25 22:40:04.497497+00
327	IN	India	Uttar Pradesh	Mirzāpur	25.1460000	82.5690000	2496970	2026-01-25 22:40:04.497497+00
328	DE	Germany	Hamburg	Hamburg	53.5500000	10.0000000	2496600	2026-01-25 22:40:04.497497+00
329	TW	Taiwan	Taipei	Taipei	25.0375000	121.5625000	2494813	2026-01-25 22:40:04.497497+00
330	CN	China	Shaanxi	Ankang	32.6854000	109.0290000	2493436	2026-01-25 22:40:04.497497+00
331	CN	China	Sichuan	Zigong	29.3390000	104.7790000	2489256	2026-01-25 22:40:04.497497+00
332	CN	China	Fujian	Sanming	26.2634000	117.6389000	2486450	2026-01-25 22:40:04.497497+00
333	MX	Mexico	México	Toluca	19.2925000	-99.6569000	2476689	2026-01-25 22:40:04.497497+00
334	CN	China	Hubei	Huangshi	30.2011000	115.0390000	2469079	2026-01-25 22:40:04.497497+00
335	CM	Cameroon	Centre	Yaoundé	3.8667000	11.5167000	2440462	2026-01-25 22:40:04.497497+00
336	CN	China	Guangdong	Zhuhai	22.2742000	113.5719000	2439585	2026-01-25 22:40:04.497497+00
337	CN	China	Liaoning	Huludao	40.7110000	120.8370000	2434194	2026-01-25 22:40:04.497497+00
338	CN	China	Yunnan	Baoshan	25.1120000	99.1610000	2431211	2026-01-25 22:40:04.497497+00
339	SA	Saudi Arabia	Makkah al Mukarramah	Mecca	21.4225000	39.8261000	2427924	2026-01-25 22:40:04.497497+00
340	CA	Canada	British Columbia	Vancouver	49.2500000	-123.1000000	2426160	2026-01-25 22:40:04.497497+00
341	CN	China	Liaoning	Lianshan	40.7523000	120.8280000	2426000	2026-01-25 22:40:04.497497+00
342	LB	Lebanon	Beyrouth	Beirut	33.8981000	35.5058000	2421354	2026-01-25 22:40:04.497497+00
343	BR	Brazil	Bahia	Salvador	-12.9831000	-38.4928000	2417678	2026-01-25 22:40:04.497497+00
344	RO	Romania	Bucureşti	Bucharest	44.4325000	26.1039000	2412530	2026-01-25 22:40:04.497497+00
345	CN	China	Gansu	Longba	33.3702000	104.9603000	2407272	2026-01-25 22:40:04.497497+00
346	IN	India	Mahārāshtra	Nāgpur	21.1497000	79.0806000	2405665	2026-01-25 22:40:04.497497+00
347	US	United States	New York	Queens	40.7498000	-73.7976000	2405464	2026-01-25 22:40:04.497497+00
348	CN	China	Liaoning	Tieling	42.2237000	123.7260000	2388294	2026-01-25 22:40:04.497497+00
349	CN	China	Guangdong	Yunfu	22.9152000	112.0445000	2383350	2026-01-25 22:40:04.497497+00
350	ID	Indonesia	Jawa Barat	Bekasi	-6.2333000	107.0000000	2381053	2026-01-25 22:40:04.497497+00
351	KR	Korea, South	Daegu	Daegu	35.8717000	128.6017000	2376044	2026-01-25 22:40:04.497497+00
352	IN	India	Uttar Pradesh	Ghāziābād	28.6700000	77.4200000	2375820	2026-01-25 22:40:04.497497+00
353	CN	China	Henan	Luoyang	34.6197000	112.4539000	2372571	2026-01-25 22:40:04.497497+00
354	CN	China	Henan	Luohe	33.5804000	114.0166000	2367490	2026-01-25 22:40:04.497497+00
355	DZ	Algeria	Alger	Algiers	36.7325000	3.0872000	2364230	2026-01-25 22:40:04.497497+00
356	CN	China	Guizhou	Anshun	26.2531000	105.9476000	2353100	2026-01-25 22:40:04.497497+00
357	CN	China	Anhui	Huainan	32.6314000	117.0194000	2333896	2026-01-25 22:40:04.497497+00
358	ID	Indonesia	Jawa Barat	Depok	-6.3940000	106.8225000	2330333	2026-01-25 22:40:04.497497+00
359	TR	Turkey	Konya	Konya	37.8667000	32.4833000	2320241	2026-01-25 22:40:04.497497+00
360	VN	Vietnam	Hải Phòng	Haiphong	20.8651000	106.6838000	2310280	2026-01-25 22:40:04.497497+00
361	CN	China	Sichuan	Yanjiang	30.1290000	104.6270000	2308631	2026-01-25 22:40:04.497497+00
362	CN	China	Sichuan	Guangyuan	32.4360000	105.8440000	2305657	2026-01-25 22:40:04.497497+00
363	AZ	Azerbaijan	Bakı	Baku	40.3667000	49.8352000	2300500	2026-01-25 22:40:04.497497+00
364	CN	China	Liaoning	Yingkou	40.6250000	122.2190000	2296540	2026-01-25 22:40:04.497497+00
365	CN	China	Heilongjiang	Mudanjiang	44.5514000	129.6329000	2290208	2026-01-25 22:40:04.497497+00
366	US	United States	California	Riverside	33.9381000	-117.3949000	2288508	2026-01-25 22:40:04.497497+00
367	JP	Japan	Fukuoka	Fukuoka	33.5900000	130.4017000	2286000	2026-01-25 22:40:04.497497+00
368	CN	China	Jiangsu	Nantong	31.9810000	120.8940000	2261382	2026-01-25 22:40:04.497497+00
369	CN	China	Yunnan	Lincang	23.8840000	100.0890000	2257991	2026-01-25 22:40:04.497497+00
370	US	United States	Nevada	Las Vegas	36.2333000	-115.2654000	2256509	2026-01-25 22:40:04.497497+00
371	CN	China	Hainan	Haikou	20.0186000	110.3488000	2250000	2026-01-25 22:40:04.497497+00
372	CN	China	Yunnan	Yuxi	24.3470000	102.5270000	2249502	2026-01-25 22:40:04.497497+00
373	ID	Indonesia	Jawa Barat	Tangerang	-6.1703000	106.6403000	2237006	2026-01-25 22:40:04.497497+00
374	IN	India	Bihār	Supaul	26.1260000	86.6050000	2229076	2026-01-25 22:40:04.497497+00
375	KZ	Kazakhstan	Almaty	Almaty	43.2400000	76.9150000	2228675	2026-01-25 22:40:04.497497+00
376	AT	Austria	Wien	Vienna	48.2083000	16.3725000	2223236	2026-01-25 22:40:04.497497+00
377	IR	Iran	Eşfahān	Eşfahān	32.6653000	51.6703000	2219343	2026-01-25 22:40:04.497497+00
378	CN	China	Qinghai	Xining	36.6224000	101.7804000	2208708	2026-01-25 22:40:04.497497+00
379	CN	China	Shanxi	Jincheng	35.4910000	112.8520000	2194545	2026-01-25 22:40:04.497497+00
380	US	United States	Maryland	Baltimore	39.3051000	-76.6144000	2189589	2026-01-25 22:40:04.497497+00
381	CN	China	Liaoning	Dandong	40.1167000	124.3833000	2188436	2026-01-25 22:40:04.497497+00
382	CN	China	Shaanxi	Yan’an	36.6500000	109.4940000	2187009	2026-01-25 22:40:04.497497+00
383	CN	China	Gansu	Qinbaling	35.7091000	107.6436000	2179716	2026-01-25 22:40:04.497497+00
384	CN	China	Sichuan	Gaoping	30.7824000	106.1281000	2174000	2026-01-25 22:40:04.497497+00
385	NG	Nigeria	Anambra	Awka	6.2069000	7.0678000	2171900	2026-01-25 22:40:04.497497+00
386	CN	China	Zhejiang	Taizhou	28.6557000	121.4208000	2162461	2026-01-25 22:40:04.497497+00
387	CN	China	Anhui	Ma’anshan	31.6690000	118.5070000	2159930	2026-01-25 22:40:04.497497+00
388	CN	China	Heilongjiang	Jiamusi	46.8000000	130.3190000	2156505	2026-01-25 22:40:04.497497+00
389	AU	Australia	Western Australia	Perth	-31.9558000	115.8597000	2141834	2026-01-25 22:40:04.497497+00
390	TR	Turkey	Gaziantep	Gaziantep	37.0628000	37.3792000	2130432	2026-01-25 22:40:04.497497+00
391	KH	Cambodia	Phnom Penh	Phnom Penh	11.5696000	104.9210000	2129371	2026-01-25 22:40:04.497497+00
392	US	United States	Missouri	St. Louis	38.6359000	-90.2451000	2127843	2026-01-25 22:40:04.497497+00
393	SO	Somalia	Banaadir	Mogadishu	2.0392000	45.3419000	2120000	2026-01-25 22:40:04.497497+00
394	CN	China	Zhejiang	Lishui	28.4680000	119.9230000	2116957	2026-01-25 22:40:04.497497+00
395	HK	Hong Kong	\N	Kowloon	22.3167000	114.1833000	2108419	2026-01-25 22:40:04.497497+00
396	AR	Argentina	Córdoba	Córdoba	-31.4167000	-64.1833000	2106734	2026-01-25 22:40:04.497497+00
397	PH	Philippines	Zamboanga	Zamboanga City	6.9042000	122.0761000	2100000	2026-01-25 22:40:04.497497+00
398	PK	Pakistan	Punjab	Rawalpindi	33.6000000	73.0333000	2098231	2026-01-25 22:40:04.497497+00
399	CU	Cuba	La Habana	Havana	23.1367000	-82.3589000	2089532	2026-01-25 22:40:04.497497+00
400	CN	China	Guangxi	Chongzuo	22.3770000	107.3650000	2088692	2026-01-25 22:40:04.497497+00
401	US	United States	Oregon	Portland	45.5371000	-122.6500000	2084045	2026-01-25 22:40:04.497497+00
402	CN	China	Guangxi	Laibin	23.7501000	109.2212000	2074611	2026-01-25 22:40:04.497497+00
403	US	United States	Texas	San Antonio	29.4632000	-98.5238000	2069843	2026-01-25 22:40:04.497497+00
404	IN	India	Gujarāt	Vadodara	22.3000000	73.2000000	2065771	2026-01-25 22:40:04.497497+00
405	CN	China	Fujian	Qingyang	24.7816000	118.5517000	2061600	2026-01-25 22:40:04.497497+00
406	IN	India	Gujarāt	Rājkot	22.3000000	70.7833000	2043000	2026-01-25 22:40:04.497497+00
407	CN	China	Shaanxi	Shangzhou	33.8734000	109.9186000	2041231	2026-01-25 22:40:04.497497+00
408	IN	India	Andhra Pradesh	Vishākhapatnam	17.7042000	83.2978000	2035922	2026-01-25 22:40:04.497497+00
409	CN	China	Shandong	Shengli	37.4340000	118.6746000	2035338	2026-01-25 22:40:04.497497+00
410	CN	China	Henan	Sanmenxia	34.7732000	111.2004000	2034872	2026-01-25 22:40:04.497497+00
411	PL	Poland	Mazowieckie	Warsaw	52.2300000	21.0111000	2028000	2026-01-25 22:40:04.497497+00
412	PK	Pakistan	Punjab	Gujranwala	32.1567000	74.1900000	2027001	2026-01-25 22:40:04.497497+00
413	CN	China	Guangxi	Hezhou	24.4042000	111.5672000	2007858	2026-01-25 22:40:04.497497+00
414	SY	Syria	Ḩalab	Aleppo	36.2319000	37.1681000	2003671	2026-01-25 22:40:04.497497+00
415	MX	Mexico	Baja California	Tijuana	32.5250000	-117.0333000	2002000	2026-01-25 22:40:04.497497+00
416	CN	China	Guangdong	Puning	23.2980000	116.1660000	1998619	2026-01-25 22:40:04.497497+00
417	IN	India	Madhya Pradesh	Indore	22.7167000	75.8472000	1994397	2026-01-25 22:40:04.497497+00
418	BY	Belarus	Minsk	Minsk	53.9006000	27.5586000	1992862	2026-01-25 22:40:04.497497+00
419	IR	Iran	Alborz	Karaj	35.8292000	50.9675000	1973470	2026-01-25 22:40:04.497497+00
420	CD	Congo (Kinshasa)	Kasaï Central	Kananga	-5.8970000	22.4488000	1971704	2026-01-25 22:40:04.497497+00
421	CN	China	Anhui	Huaibei	33.9560000	116.7980000	1970265	2026-01-25 22:40:04.497497+00
422	PK	Pakistan	Khyber Pakhtunkhwa	Peshawar	34.0144000	71.5675000	1970042	2026-01-25 22:40:04.497497+00
423	US	United States	California	Sacramento	38.5677000	-121.4685000	1962998	2026-01-25 22:40:04.497497+00
424	JP	Japan	Hokkaidō	Sapporo	43.0619000	141.3544000	1959313	2026-01-25 22:40:04.497497+00
425	NL	Netherlands	Noord-Brabant	Tilburg	51.5572000	5.0911000	1944588	2026-01-25 22:40:04.497497+00
426	US	United States	Texas	Austin	30.3005000	-97.7522000	1915031	2026-01-25 22:40:04.497497+00
427	US	United States	Florida	Orlando	28.4773000	-81.3370000	1913597	2026-01-25 22:40:04.497497+00
428	PH	Philippines	Davao	Davao	7.0700000	125.6000000	1910167	2026-01-25 22:40:04.497497+00
429	CN	China	Shanghai	Songjiang	31.0058000	121.2333000	1909713	2026-01-25 22:40:04.497497+00
430	CN	China	Ningxia	Yinchuan	38.4850000	106.2250000	1901793	2026-01-25 22:40:04.497497+00
431	IN	India	Haryāna	Abhepur	39.4100000	116.3800000	1895686	2026-01-25 22:40:04.497497+00
432	IN	India	Mahārāshtra	Thāne	19.1972000	72.9722000	1886941	2026-01-25 22:40:04.497497+00
433	PK	Pakistan	Punjab	Multan	30.1978000	71.4697000	1871843	2026-01-25 22:40:04.497497+00
434	NG	Nigeria	Rivers	Port Harcourt	4.8242000	7.0336000	1865000	2026-01-25 22:40:04.497497+00
435	CN	China	Liaoning	Fushun	41.8810000	123.9570000	1861372	2026-01-25 22:40:04.497497+00
436	TW	Taiwan	Tainan	Tainan	22.9833000	120.1833000	1856642	2026-01-25 22:40:04.497497+00
437	CN	China	Gansu	Pingliang	35.5424000	106.6649000	1848607	2026-01-25 22:40:04.497497+00
438	CN	China	Jilin	Siping	43.1668000	124.3506000	1814733	2026-01-25 22:40:04.497497+00
439	PR	Puerto Rico	Puerto Rico	San Juan	18.3985000	-66.0610000	1809800	2026-01-25 22:40:04.497497+00
440	CN	China	Jiangxi	Pingxiang	27.6590000	113.8870000	1804805	2026-01-25 22:40:04.497497+00
441	IN	India	Madhya Pradesh	Bhopāl	23.2599000	77.4126000	1798218	2026-01-25 22:40:04.497497+00
442	IQ	Iraq	Nīnawá	Mosul	36.3667000	43.1167000	1792000	2026-01-25 22:40:04.497497+00
443	TR	Turkey	Diyarbakır	Diyarbakır	37.9100000	40.2400000	1791373	2026-01-25 22:40:04.497497+00
444	CD	Congo (Kinshasa)	Haut-Katanga	Lubumbashi	-11.6647000	27.4794000	1786397	2026-01-25 22:40:04.497497+00
445	NG	Nigeria	Edo	Benin City	6.3333000	5.6222000	1780000	2026-01-25 22:40:04.497497+00
446	BR	Brazil	Paraná	Curitiba	-25.4297000	-49.2719000	1773718	2026-01-25 22:40:04.497497+00
447	US	United States	California	San Jose	37.3012000	-121.8480000	1771563	2026-01-25 22:40:04.497497+00
448	CN	China	Jiangsu	Shuyangzha	34.1299000	118.7734000	1770000	2026-01-25 22:40:04.497497+00
449	TR	Turkey	Adana	Adana	37.0000000	35.3213000	1765981	2026-01-25 22:40:04.497497+00
450	EC	Ecuador	Pichincha	Quito	-0.2200000	-78.5125000	1763275	2026-01-25 22:40:04.497497+00
451	IN	India	Uttar Pradesh	Āgra	27.1800000	78.0200000	1760285	2026-01-25 22:40:04.497497+00
452	IN	India	Tamil Nādu	Peyanvilai	8.9000000	77.9833000	1750176	2026-01-25 22:40:04.497497+00
453	ZM	Zambia	Lusaka	Lusaka	-15.4167000	28.2833000	1747152	2026-01-25 22:40:04.497497+00
454	US	United States	Indiana	Indianapolis	39.7771000	-86.1458000	1740984	2026-01-25 22:40:04.497497+00
455	PK	Pakistan	Sindh	Hyderabad City	25.3792000	68.3683000	1732693	2026-01-25 22:40:04.497497+00
456	IN	India	Mahārāshtra	Pimpri-Chinchwad	18.6186000	73.8037000	1729320	2026-01-25 22:40:04.497497+00
457	VE	Venezuela	Aragua	Maracay	10.2469000	-67.5961000	1723236	2026-01-25 22:40:04.497497+00
458	OM	Oman	Masqaţ	Masqaţ	23.6140000	58.5911000	1720000	2026-01-25 22:40:04.497497+00
459	UY	Uruguay	Montevideo	Montevideo	-34.9056000	-56.1842000	1719453	2026-01-25 22:40:04.497497+00
460	US	United States	Pennsylvania	Pittsburgh	40.4397000	-79.9763000	1712828	2026-01-25 22:40:04.497497+00
461	US	United States	Ohio	Cincinnati	39.1413000	-84.5060000	1704916	2026-01-25 22:40:04.497497+00
462	US	United States	New York	Manhattan	40.7834000	-73.9662000	1694263	2026-01-25 22:40:04.497497+00
463	US	United States	Missouri	Kansas City	39.1238000	-94.5541000	1686807	2026-01-25 22:40:04.497497+00
464	HU	Hungary	Budapest	Budapest	47.4983000	19.0408000	1686222	2026-01-25 22:40:04.497497+00
465	IN	India	Bihār	Patna	25.5940000	85.1376000	1684222	2026-01-25 22:40:04.497497+00
466	UG	Uganda	Kampala	Kampala	0.3136000	32.5811000	1680600	2026-01-25 22:40:04.497497+00
467	CN	China	Guangxi	Beihai	21.4810000	109.1200000	1680000	2026-01-25 22:40:04.497497+00
468	CN	China	Chongqing	Sanzhou	30.8200000	108.4000000	1680000	2026-01-25 22:40:04.497497+00
469	US	United States	Ohio	Cleveland	41.4764000	-81.6805000	1679247	2026-01-25 22:40:04.497497+00
470	GN	Guinea	Conakry	Conakry	9.5092000	-13.7122000	1667864	2026-01-25 22:40:04.497497+00
471	CN	China	Fujian	Ximeicun	24.9612000	118.3849000	1663542	2026-01-25 22:40:04.497497+00
472	PH	Philippines	Caloocan	Caloocan City	14.6500000	120.9700000	1661584	2026-01-25 22:40:04.497497+00
473	MX	Mexico	México	Ecatepec	19.6097000	-99.0600000	1655015	2026-01-25 22:40:04.497497+00
474	CN	China	Jiangsu	Yushan	31.3220000	120.9850000	1652159	2026-01-25 22:40:04.497497+00
475	CN	China	Liaoning	Fuxin	42.0220000	121.6700000	1647280	2026-01-25 22:40:04.497497+00
476	RU	Russia	Novosibirskaya Oblast’	Novosibirsk	55.0500000	82.9500000	1633851	2026-01-25 22:40:04.497497+00
477	IN	India	Chhattīsgarh	Bilāspur	22.0900000	82.1500000	1625502	2026-01-25 22:40:04.497497+00
478	ID	Indonesia	Jawa Tengah	Semarang	-6.9900000	110.4225000	1621384	2026-01-25 22:40:04.497497+00
479	CN	China	Jiangxi	Jingdezhen	29.2917000	117.1986000	1618979	2026-01-25 22:40:04.497497+00
480	IN	India	Punjab	Ludhiāna	30.9100000	75.8500000	1618879	2026-01-25 22:40:04.497497+00
481	CN	China	Liaoning	Liaoyang	41.2790000	123.1760000	1604580	2026-01-25 22:40:04.497497+00
482	CN	China	Jiangsu	Jiangyin	31.8390000	120.2950000	1595138	2026-01-25 22:40:04.497497+00
483	ES	Spain	Valencia	Valencia	39.4700000	-0.3764000	1595000	2026-01-25 22:40:04.497497+00
484	CN	China	Shanxi	Shuozhou	39.3317000	112.4329000	1593444	2026-01-25 22:40:04.497497+00
485	MX	Mexico	Guanajuato	León de los Aldama	21.1167000	-101.6833000	1579803	2026-01-25 22:40:04.497497+00
486	US	United States	Ohio	Columbus	39.9862000	-82.9855000	1578153	2026-01-25 22:40:04.497497+00
487	MX	Mexico	Puebla	Puebla	19.0333000	-98.1833000	1576259	2026-01-25 22:40:04.497497+00
488	VN	Vietnam	Đồng Nai	Biên Hòa	10.9500000	106.8167000	1575000	2026-01-25 22:40:04.497497+00
489	CN	China	Shandong	Chengtangcun	35.0833000	117.1500000	1574648	2026-01-25 22:40:04.497497+00
490	CI	Côte d’Ivoire	Abidjan	Yopougon	5.3748000	-4.0867000	1571065	2026-01-25 22:40:04.497497+00
491	CN	China	Henan	Hebi	35.7480000	114.2970000	1565973	2026-01-25 22:40:04.497497+00
492	IR	Iran	Fārs	Shīrāz	29.6100000	52.5425000	1565572	2026-01-25 22:40:04.497497+00
493	TJ	Tajikistan	Dushanbe	Dushanbe	38.5367000	68.7800000	1564700	2026-01-25 22:40:04.497497+00
494	IN	India	Tamil Nādu	Madurai	9.9252000	78.1198000	1561129	2026-01-25 22:40:04.497497+00
495	CN	China	Zhejiang	Huzhou	30.8925000	120.0875000	1558826	2026-01-25 22:40:04.497497+00
496	ZW	Zimbabwe	Harare	Harare	-17.8292000	31.0522000	1558823	2026-01-25 22:40:04.497497+00
497	IR	Iran	Āz̄arbāyjān-e Sharqī	Tabrīz	38.0817000	46.2992000	1558693	2026-01-25 22:40:04.497497+00
498	IN	India	Jhārkhand	Jamshedpur	22.7925000	86.1842000	1558000	2026-01-25 22:40:04.497497+00
499	CN	China	Jilin	Baicheng	45.6200000	122.8380000	1551378	2026-01-25 22:40:04.497497+00
500	CR	Costa Rica	San José	San José	9.9325000	-84.0800000	1543000	2026-01-25 22:40:04.497497+00
501	CN	China	Jiangsu	Shaoyang	32.9120000	119.8526000	1542600	2026-01-25 22:40:04.497497+00
502	SV	El Salvador	San Salvador	San Salvador	13.6989000	-89.1914000	1538525	2026-01-25 22:40:04.497497+00
503	ID	Indonesia	Sumatera Selatan	Palembang	-2.9861000	104.7556000	1535952	2026-01-25 22:40:04.497497+00
504	JP	Japan	Kanagawa	Kawasaki	35.5167000	139.7000000	1531646	2026-01-25 22:40:04.497497+00
505	JP	Japan	Hyōgo	Kōbe	34.6900000	135.1956000	1521707	2026-01-25 22:40:04.497497+00
506	CN	China	Zhejiang	Jiaxing	30.7470000	120.7560000	1518654	2026-01-25 22:40:04.497497+00
507	CN	China	Hunan	Zhangjiajie	29.1170000	110.4790000	1517027	2026-01-25 22:40:04.497497+00
508	CN	China	Gansu	Baiyin	36.5451000	104.1389000	1512110	2026-01-25 22:40:04.497497+00
509	CN	China	Guangxi	Guiping	23.4000000	110.0833000	1511011	2026-01-25 22:40:04.497497+00
510	CN	China	Jiangsu	Changshu	31.6560000	120.7530000	1510100	2026-01-25 22:40:04.497497+00
511	CN	China	Heilongjiang	Jixi	45.2950000	130.9690000	1502060	2026-01-25 22:40:04.497497+00
512	CN	China	Zhejiang	Xushan	30.1667000	121.2333000	1502000	2026-01-25 22:40:04.497497+00
513	TG	Togo	Maritime	Lomé	6.1308000	1.2153000	1500000	2026-01-25 22:40:04.497497+00
514	NE	Niger	Niamey	Niamey	13.5150000	2.1175000	1496260	2026-01-25 22:40:04.497497+00
515	KR	Korea, South	Gwangju	Gwangju	35.1653000	126.8486000	1490092	2026-01-25 22:40:04.497497+00
516	BR	Brazil	Pernambuco	Recife	-8.0539000	-34.8808000	1488920	2026-01-25 22:40:04.497497+00
517	IN	India	Mahārāshtra	Nāsik	19.9975000	73.7898000	1486053	2026-01-25 22:40:04.497497+00
518	AE	United Arab Emirates	Abū Z̧aby	Abu Dhabi	24.4667000	54.3667000	1483000	2026-01-25 22:40:04.497497+00
519	NG	Nigeria	Anambra	Onitsha	6.1667000	6.7833000	1483000	2026-01-25 22:40:04.497497+00
520	NL	Netherlands	Noord-Holland	Amsterdam	52.3728000	4.8936000	1477213	2026-01-25 22:40:04.497497+00
521	IN	India	Andhra Pradesh	Vijayavāda	16.5193000	80.6305000	1476931	2026-01-25 22:40:04.497497+00
522	MX	Mexico	Jalisco	Zapopan	20.7167000	-103.4000000	1476491	2026-01-25 22:40:04.497497+00
523	KR	Korea, South	Daejeon	Daejeon	36.3500000	127.3850000	1475221	2026-01-25 22:40:04.497497+00
524	US	United States	New York	Bronx	40.8501000	-73.8662000	1472654	2026-01-25 22:40:04.497497+00
525	NZ	New Zealand	Auckland	Auckland	-36.8492000	174.7653000	1470100	2026-01-25 22:40:04.497497+00
526	RU	Russia	Sverdlovskaya Oblast’	Yekaterinburg	56.8356000	60.6128000	1468833	2026-01-25 22:40:04.497497+00
527	CN	China	Gansu	Wuwei	37.9290000	102.6380000	1464955	2026-01-25 22:40:04.497497+00
528	CN	China	Zhejiang	Jinhua	29.0790000	119.6470000	1463990	2026-01-25 22:40:04.497497+00
529	JP	Japan	Kyōto	Kyōto	35.0117000	135.7683000	1463723	2026-01-25 22:40:04.497497+00
530	CN	China	Jiangsu	Pizhou	34.3980000	117.8900000	1458038	2026-01-25 22:40:04.497497+00
531	CN	China	Jiangsu	Yangshe	31.8767000	120.5560000	1447600	2026-01-25 22:40:04.497497+00
532	SN	Senegal	Dakar	Dakar	14.6726000	-17.4320000	1438725	2026-01-25 22:40:04.497497+00
533	US	United States	North Carolina	Charlotte	35.2083000	-80.8303000	1436613	2026-01-25 22:40:04.497497+00
534	CN	China	Sichuan	Yucheng	30.0100000	103.0415000	1434603	2026-01-25 22:40:04.497497+00
535	TR	Turkey	Kayseri	Kayseri	38.7225000	35.4875000	1434357	2026-01-25 22:40:04.497497+00
536	US	United States	Virginia	Virginia Beach	36.7335000	-76.0435000	1431821	2026-01-25 22:40:04.497497+00
537	CN	China	Zhejiang	Rui’an	27.7833000	120.6250000	1424667	2026-01-25 22:40:04.497497+00
538	OM	Oman	Masqaţ	Muscat	23.6139000	58.5922000	1421409	2026-01-25 22:40:04.497497+00
539	UA	Ukraine	Kharkivska Oblast	Kharkiv	49.9925000	36.2311000	1421125	2026-01-25 22:40:04.497497+00
540	CG	Congo (Brazzaville)	Pointe-Noire	Pointe-Noire	-4.7975000	11.8503000	1420612	2026-01-25 22:40:04.497497+00
541	SA	Saudi Arabia	Al Madīnah al Munawwarah	Medina	24.4700000	39.6100000	1411599	2026-01-25 22:40:04.497497+00
542	ID	Indonesia	Jawa Barat	Sangereng	-6.2889000	106.7181000	1404785	2026-01-25 22:40:04.497497+00
543	IN	India	Haryāna	Farīdābād	28.4211000	77.3078000	1404653	2026-01-25 22:40:04.497497+00
544	BG	Bulgaria	Sofia-Grad	Sofia	42.6979000	23.3217000	1404116	2026-01-25 22:40:04.497497+00
545	MN	Mongolia	Ulaanbaatar	Ulaanbaatar	47.9214000	106.9055000	1396288	2026-01-25 22:40:04.497497+00
546	AU	Australia	South Australia	Adelaide	-34.9275000	138.6000000	1387290	2026-01-25 22:40:04.497497+00
547	CZ	Czechia	Praha	Prague	50.0875000	14.4214000	1384732	2026-01-25 22:40:04.497497+00
548	CN	China	Zhejiang	Wenling	28.3667000	121.3667000	1366794	2026-01-25 22:40:04.497497+00
549	DK	Denmark	Hovedstaden	Copenhagen	55.6805000	12.5615000	1366301	2026-01-25 22:40:04.497497+00
550	IN	India	Delhi	Najafgarh	28.6125000	76.9847000	1365152	2026-01-25 22:40:04.497497+00
551	CN	China	Guangdong	Lianjiang	21.7333000	110.2833000	1363470	2026-01-25 22:40:04.497497+00
552	FI	Finland	Uusimaa	Helsinki	60.1708000	24.9375000	1360075	2026-01-25 22:40:04.497497+00
553	TR	Turkey	Samsun	Samsun	41.2903000	36.3336000	1356079	2026-01-25 22:40:04.497497+00
554	IT	Italy	Lombardy	Milan	45.4669000	9.1900000	1354196	2026-01-25 22:40:04.497497+00
555	TR	Turkey	Antalya	Antalya	36.8874000	30.7075000	1344000	2026-01-25 22:40:04.497497+00
556	DO	Dominican Republic	Cibao Norte	Santiago	19.4572000	-70.6889000	1343423	2026-01-25 22:40:04.497497+00
557	CN	China	Anhui	Chizhou	30.6654000	117.4916000	1342764	2026-01-25 22:40:04.497497+00
558	ID	Indonesia	Sulawesi Selatan	Makassar	-5.1331000	119.4136000	1338663	2026-01-25 22:40:04.497497+00
559	BR	Brazil	Rio Grande do Sul	Porto Alegre	-30.0328000	-51.2300000	1332845	2026-01-25 22:40:04.497497+00
560	CN	China	Anhui	Huangshan	29.7149000	118.3376000	1330565	2026-01-25 22:40:04.497497+00
561	CN	China	Guangdong	Gaozhou	21.9244000	110.8422000	1328657	2026-01-25 22:40:04.497497+00
562	CO	Colombia	Atlántico	Barranquilla	10.9833000	-74.8019000	1326588	2026-01-25 22:40:04.497497+00
563	IQ	Iraq	Al Başrah	Al Başrah	30.5150000	47.8100000	1326564	2026-01-25 22:40:04.497497+00
564	CN	China	Liaoning	Benxi	41.3039000	123.7649000	1326018	2026-01-25 22:40:04.497497+00
565	JP	Japan	Saitama	Saitama	35.8614000	139.6456000	1325843	2026-01-25 22:40:04.497497+00
566	IR	Iran	Khūzestān	Ahvāz	31.3047000	48.6783000	1325000	2026-01-25 22:40:04.497497+00
567	BR	Brazil	São Paulo	Guarulhos	-23.4667000	-46.5333000	1324781	2026-01-25 22:40:04.497497+00
568	CN	China	Guangdong	Leizhou	20.9143000	110.0967000	1321091	2026-01-25 22:40:04.497497+00
569	MX	Mexico	Chihuahua	Juárez	31.7450000	-106.4850000	1321004	2026-01-25 22:40:04.497497+00
570	MM	Burma	Mandalay	Mandalay	21.9831000	96.0844000	1319452	2026-01-25 22:40:04.497497+00
571	CN	China	Shanxi	Yangquan	37.8571000	113.5804000	1318505	2026-01-25 22:40:04.497497+00
572	CN	China	Fujian	Fuqing	25.7167000	119.3833000	1316000	2026-01-25 22:40:04.497497+00
573	CN	China	Shandong	Xintai	35.9090000	117.7680000	1315942	2026-01-25 22:40:04.497497+00
574	CN	China	Anhui	Wusong	30.9450000	117.8110000	1311726	2026-01-25 22:40:04.497497+00
575	CN	China	Anhui	Tongling	30.9456000	117.8114000	1311726	2026-01-25 22:40:04.497497+00
576	CA	Canada	Alberta	Calgary	51.0500000	-114.0667000	1306784	2026-01-25 22:40:04.497497+00
577	IN	India	Uttar Pradesh	Meerut	28.9800000	77.7100000	1305429	2026-01-25 22:40:04.497497+00
578	US	United States	Florida	Jacksonville	30.3322000	-81.6749000	1303156	2026-01-25 22:40:04.497497+00
579	CN	China	Jilin	Kuaidamao	41.7283000	125.9397000	1302778	2026-01-25 22:40:04.497497+00
580	CN	China	Guangdong	Huazhou	21.6640000	110.6396000	1291668	2026-01-25 22:40:04.497497+00
581	US	United States	Wisconsin	Milwaukee	43.0642000	-87.9675000	1290221	2026-01-25 22:40:04.497497+00
582	CN	China	Ningxia	Wuzhong	37.9978000	106.1986000	1284000	2026-01-25 22:40:04.497497+00
583	BR	Brazil	Pará	Belém	-1.4558000	-48.5039000	1280614	2026-01-25 22:40:04.497497+00
584	AO	Angola	Luanda	Cacuaco	-8.8053000	13.2444000	1279488	2026-01-25 22:40:04.497497+00
585	AR	Argentina	Santa Fe	Rosario	-32.9575000	-60.6394000	1276000	2026-01-25 22:40:04.497497+00
586	MA	Morocco	Tanger-Tétouan-Al Hoceïma	Tangier	35.7767000	-5.8039000	1275428	2026-01-25 22:40:04.497497+00
587	MG	Madagascar	Antananarivo	Antananarivo	-18.9100000	47.5250000	1275207	2026-01-25 22:40:04.497497+00
588	PH	Philippines	Cagayan	Canagatan	18.0000000	121.8000000	1273219	2026-01-25 22:40:04.497497+00
589	ZA	South Africa	Gauteng	Soweto	-26.2678000	27.8585000	1271628	2026-01-25 22:40:04.497497+00
590	US	United States	Rhode Island	Providence	41.8230000	-71.4187000	1270529	2026-01-25 22:40:04.497497+00
591	CN	China	Hubei	Xiantao	30.3280000	113.4430000	1268715	2026-01-25 22:40:04.497497+00
592	IN	India	Madhya Pradesh	Jabalpur	23.1667000	79.9333000	1267564	2026-01-25 22:40:04.497497+00
593	CN	China	Jiangsu	Huaiyin	33.5819000	119.0280000	1264000	2026-01-25 22:40:04.497497+00
594	CN	China	Hunan	Yutan	28.2780000	112.5520000	1263332	2026-01-25 22:40:04.497497+00
595	RU	Russia	Tatarstan	Kazan	55.7964000	49.1089000	1259173	2026-01-25 22:40:04.497497+00
596	ID	Indonesia	Kepulauan Riau	Bagam	1.1300000	104.0531000	1256610	2026-01-25 22:40:04.497497+00
597	CN	China	Yunnan	Dayan	26.8552000	100.2259000	1253878	2026-01-25 22:40:04.497497+00
598	HN	Honduras	Francisco Morazán	Comayagüela	14.0980000	-87.2100000	1250000	2026-01-25 22:40:04.497497+00
599	BE	Belgium	Brussels-Capital Region	Brussels	50.8467000	4.3525000	1249597	2026-01-25 22:40:04.497497+00
600	CN	China	Shandong	Laiwu	36.1833000	117.6667000	1248636	2026-01-25 22:40:04.497497+00
601	CN	China	Henan	Huazhou	32.6880000	112.0870000	1247807	2026-01-25 22:40:04.497497+00
602	AE	United Arab Emirates	Ash Shāriqah	Sharjah	25.3575000	55.3908000	1247749	2026-01-25 22:40:04.497497+00
603	IN	India	Mahārāshtra	Kalyān	19.2400000	73.1300000	1246381	2026-01-25 22:40:04.497497+00
604	CN	China	Jiangsu	Rucheng	32.2460000	120.5910000	1241700	2026-01-25 22:40:04.497497+00
605	VE	Venezuela	Lara	Barquisimeto	10.0636000	-69.3347000	1240714	2026-01-25 22:40:04.497497+00
606	CN	China	Henan	Yongcheng	33.9299000	116.4500000	1240382	2026-01-25 22:40:04.497497+00
607	ID	Indonesia	Jawa Barat	Sumedang	-6.8400000	107.9208000	1240000	2026-01-25 22:40:04.497497+00
608	VN	Vietnam	Cần Thơ	Cần Thơ	10.0333000	105.7833000	1237300	2026-01-25 22:40:04.497497+00
609	KR	Korea, South	Gyeonggi	Suwon	37.2667000	127.0167000	1234300	2026-01-25 22:40:04.497497+00
610	CN	China	Zhejiang	Yiwu	29.3069000	120.0753000	1234015	2026-01-25 22:40:04.497497+00
611	IN	India	Mahārāshtra	Vasai-Virar	19.4700000	72.8000000	1221233	2026-01-25 22:40:04.497497+00
612	BR	Brazil	São Paulo	Campinas	-22.9009000	-47.0573000	1213792	2026-01-25 22:40:04.497497+00
613	CN	China	Sichuan	Dadukou	26.5824000	101.7184000	1212203	2026-01-25 22:40:04.497497+00
614	CN	China	Guangxi	Lingcheng	22.7080000	110.3540000	1211637	2026-01-25 22:40:04.497497+00
615	CN	China	Heilongjiang	Shuangyashan	46.6762000	131.1416000	1208803	2026-01-25 22:40:04.497497+00
616	RU	Russia	Nizhegorodskaya Oblast’	Nizhniy Novgorod	56.3269000	44.0075000	1204985	2026-01-25 22:40:04.497497+00
617	IN	India	Haryāna	Pānīpat	29.3875000	76.9700000	1202811	2026-01-25 22:40:04.497497+00
618	IR	Iran	Qom	Qom	34.6400000	50.8764000	1201158	2026-01-25 22:40:04.497497+00
619	KE	Kenya	Mombasa	Mombasa	-4.0500000	39.6667000	1200000	2026-01-25 22:40:04.497497+00
620	SO	Somalia	Woqooyi Galbeed	Hargeysa	9.5600000	44.0650000	1200000	2026-01-25 22:40:04.497497+00
621	SO	Somalia	Bay	Baidoa	3.1167000	43.6500000	1200000	2026-01-25 22:40:04.497497+00
622	IN	India	Uttar Pradesh	Vārānasi	25.3189000	83.0128000	1198491	2026-01-25 22:40:04.497497+00
623	JP	Japan	Hiroshima	Hiroshima	34.3914000	132.4519000	1198021	2026-01-25 22:40:04.497497+00
624	TH	Thailand	Chiang Mai	Chiang Mai	18.7953000	98.9986000	1198000	2026-01-25 22:40:04.497497+00
625	RS	Serbia	Beograd	Belgrade	44.8178000	20.4569000	1197714	2026-01-25 22:40:04.497497+00
626	NG	Nigeria	Borno	Maiduguri	11.8372000	13.1542000	1197497	2026-01-25 22:40:04.497497+00
627	IN	India	Kerala	Kalleli	9.2807000	76.8697000	1197412	2026-01-25 22:40:04.497497+00
628	ID	Indonesia	Kepulauan Riau	Batam Centre	1.1272000	104.0556000	1196396	2026-01-25 22:40:04.497497+00
629	CN	China	Shandong	Pingdu	36.7769000	119.9884000	1191348	2026-01-25 22:40:04.497497+00
630	CN	China	Yunnan	Rongcheng	26.2180000	104.1030000	1189813	2026-01-25 22:40:04.497497+00
631	CD	Congo (Kinshasa)	Équateur	Mbandaka	0.0478000	18.2558000	1187837	2026-01-25 22:40:04.497497+00
632	CN	China	Jiangxi	Xinyu	27.8186000	114.9167000	1186700	2026-01-25 22:40:04.497497+00
633	QA	Qatar	Ad Dawḩah	Doha	25.2867000	51.5333000	1186023	2026-01-25 22:40:04.497497+00
634	KZ	Kazakhstan	Shymkent	Shymkent	42.3167000	69.5958000	1184113	2026-01-25 22:40:04.497497+00
635	LY	Libya	Ţarābulus	Tripoli	32.8872000	13.1914000	1183000	2026-01-25 22:40:04.497497+00
636	IN	India	Jammu and Kashmīr	Srīnagar	34.0900000	74.7900000	1180570	2026-01-25 22:40:04.497497+00
637	US	United States	Tennessee	Nashville	36.1715000	-86.7842000	1178679	2026-01-25 22:40:04.497497+00
638	RU	Russia	Chelyabinskaya Oblast’	Chelyabinsk	55.1547000	61.3758000	1177058	2026-01-25 22:40:04.497497+00
639	IN	India	Mahārāshtra	Aurangābād	19.8800000	75.3200000	1175116	2026-01-25 22:40:04.497497+00
640	ID	Indonesia	Jawa Tengah	Cilacap	-7.7167000	109.0170000	1174964	2026-01-25 22:40:04.497497+00
641	CN	China	Henan	Xinhualu	34.3964000	113.7402000	1172237	2026-01-25 22:40:04.497497+00
642	US	United States	Utah	Salt Lake City	40.7776000	-111.9311000	1169033	2026-01-25 22:40:04.497497+00
643	CN	China	Hunan	Guankou	28.1637000	113.6433000	1168056	2026-01-25 22:40:04.497497+00
644	ID	Indonesia	Lampung	Bandar Lampung	-5.4500000	105.2667000	1166761	2026-01-25 22:40:04.497497+00
645	IN	India	Jhārkhand	Dhanbād	23.7998000	86.4305000	1162472	2026-01-25 22:40:04.497497+00
646	MM	Burma	Nay Pyi Taw	Nay Pyi Taw	19.7475000	96.1150000	1160242	2026-01-25 22:40:04.497497+00
647	NG	Nigeria	Abia	Aba	5.1167000	7.3667000	1160000	2026-01-25 22:40:04.497497+00
648	CN	China	Hubei	Jingling	30.6640000	113.1670000	1158640	2026-01-25 22:40:04.497497+00
649	CN	China	Zhejiang	Zhuji	29.7167000	120.2333000	1157938	2026-01-25 22:40:04.497497+00
650	HN	Honduras	Francisco Morazán	Tegucigalpa	14.1057000	-87.2040000	1157509	2026-01-25 22:40:04.497497+00
651	RW	Rwanda	Kigali	Kigali	-1.9536000	30.0606000	1156663	2026-01-25 22:40:04.497497+00
652	RU	Russia	Samarskaya Oblast’	Samara	53.2028000	50.1408000	1156659	2026-01-25 22:40:04.497497+00
653	CN	China	Jiangxi	Yingtan	28.2721000	117.0395000	1154223	2026-01-25 22:40:04.497497+00
654	CA	Canada	Alberta	Edmonton	53.5344000	-113.4903000	1151635	2026-01-25 22:40:04.497497+00
655	US	United States	North Carolina	Raleigh	35.8324000	-78.6429000	1150010	2026-01-25 22:40:04.497497+00
656	KG	Kyrgyzstan	Bishkek	Bishkek	42.8667000	74.5667000	1145044	2026-01-25 22:40:04.497497+00
657	BI	Burundi	Bujumbura Mairie	Bujumbura	-3.3833000	29.3667000	1143202	2026-01-25 22:40:04.497497+00
658	CN	China	Ningxia	Guyuan	36.0100000	106.2570000	1142142	2026-01-25 22:40:04.497497+00
659	CN	China	Hunan	Leiyang	26.4223000	112.8598000	1140675	2026-01-25 22:40:04.497497+00
660	RU	Russia	Krasnodarskiy Kray	Krasnodar	45.0333000	38.9667000	1138654	2026-01-25 22:40:04.497497+00
661	RU	Russia	Rostovskaya Oblast’	Rostov	47.2225000	39.7100000	1135968	2026-01-25 22:40:04.497497+00
662	MZ	Mozambique	Maputo	Maputo	-25.9153000	32.5764000	1133200	2026-01-25 22:40:04.497497+00
663	CD	Congo (Kinshasa)	Sud-Kivu	Bukavu	-2.5061000	28.8608000	1133000	2026-01-25 22:40:04.497497+00
664	IN	India	Punjab	Amritsar	31.6400000	74.8600000	1132383	2026-01-25 22:40:04.497497+00
665	NG	Nigeria	Ogun	Shagamu	6.8333000	3.6500000	1132270	2026-01-25 22:40:04.497497+00
666	IN	India	Uttar Pradesh	Alīgarh	27.8800000	78.0800000	1131160	2026-01-25 22:40:04.497497+00
667	CN	China	Gansu	Zhangye	38.9248000	100.4499000	1131016	2026-01-25 22:40:04.497497+00
668	RU	Russia	Bashkortostan	Ufa	54.7261000	55.9475000	1128787	2026-01-25 22:40:04.497497+00
669	DO	Dominican Republic	Ozama	Santo Domingo	18.4764000	-69.8933000	1128678	2026-01-25 22:40:04.497497+00
670	KR	Korea, South	Ulsan	Ulsan	35.5500000	129.3167000	1127553	2026-01-25 22:40:04.497497+00
671	CN	China	Hubei	Rongcheng	29.8402000	112.9048000	1120822	2026-01-25 22:40:04.497497+00
672	GE	Georgia	Tbilisi	Tbilisi	41.7225000	44.7925000	1118035	2026-01-25 22:40:04.497497+00
673	IN	India	Assam	Guwāhāti	26.1722000	91.7458000	1116267	2026-01-25 22:40:04.497497+00
674	MA	Morocco	Fès-Meknès	Fès	34.0433000	-5.0033000	1112072	2026-01-25 22:40:04.497497+00
675	CN	China	Henan	Yingchuan	34.1420000	113.4890000	1109782	2026-01-25 22:40:04.497497+00
676	VN	Vietnam	Ninh Bình	Ninh Bình	20.2500000	105.8333000	1106913	2026-01-25 22:40:04.497497+00
677	AM	Armenia	Yerevan	Yerevan	40.1814000	44.5144000	1106300	2026-01-25 22:40:04.497497+00
678	TZ	Tanzania	Mwanza	Mwanza	-2.5167000	32.9000000	1104521	2026-01-25 22:40:04.497497+00
679	RU	Russia	Omskaya Oblast’	Omsk	54.9833000	73.3667000	1104485	2026-01-25 22:40:04.497497+00
680	MX	Mexico	Baja California	Mexicali	32.6633000	-115.4678000	1102342	2026-01-25 22:40:04.497497+00
681	ES	Spain	Andalusia	Sevilla	37.3900000	-5.9900000	1100000	2026-01-25 22:40:04.497497+00
682	NG	Nigeria	Ondo	Ikare	7.5167000	5.7500000	1099931	2026-01-25 22:40:04.497497+00
683	CN	China	Hebei	Dingzhou	38.5160000	114.9900000	1095986	2026-01-25 22:40:04.497497+00
684	GH	Ghana	Northern	Tamale	9.4075000	-0.8533000	1095808	2026-01-25 22:40:04.497497+00
685	CN	China	Zhejiang	Yuyao	30.0500000	121.1500000	1095000	2026-01-25 22:40:04.497497+00
686	BR	Brazil	Goiás	Goiânia	-16.6806000	-49.2564000	1093007	2026-01-25 22:40:04.497497+00
687	RU	Russia	Krasnoyarskiy Kray	Krasnoyarsk	56.0089000	92.8719000	1092851	2026-01-25 22:40:04.497497+00
688	DE	Germany	North Rhine-Westphalia	Cologne	50.9364000	6.9528000	1087353	2026-01-25 22:40:04.497497+00
689	TZ	Tanzania	Dar es Salaam	Ubungo	-6.7889000	39.2056000	1086912	2026-01-25 22:40:04.497497+00
690	CN	China	Jiangsu	Yicheng	31.3600000	119.8150000	1082929	2026-01-25 22:40:04.497497+00
691	US	United States	Virginia	Richmond	37.5295000	-77.4756000	1081248	2026-01-25 22:40:04.497497+00
692	CD	Congo (Kinshasa)	Tshopo	Kisangani	0.5167000	25.2000000	1081000	2026-01-25 22:40:04.497497+00
693	CN	China	Hubei	Ezhou	30.3914000	114.8949000	1079353	2026-01-25 22:40:04.497497+00
694	KZ	Kazakhstan	Nur-Sultan	Astana	51.1472000	71.4222000	1078362	2026-01-25 22:40:04.497497+00
695	CN	China	Shandong	Zhufeng	36.0000000	119.4167000	1078178	2026-01-25 22:40:04.497497+00
696	MX	Mexico	México	Nezahualcóyotl	19.4081000	-99.0186000	1077208	2026-01-25 22:40:04.497497+00
697	MR	Mauritania	Nouakchott Ouest	Nouakchott	18.0858000	-15.9785000	1077169	2026-01-25 22:40:04.497497+00
698	IN	India	West Bengal	Hāora	22.5800000	88.3294000	1077075	2026-01-25 22:40:04.497497+00
699	KR	Korea, South	Gyeonggi	Tongjin	37.2333000	127.2000000	1076369	2026-01-25 22:40:04.497497+00
700	IN	India	Jhārkhand	Rānchi	23.3600000	85.3300000	1073440	2026-01-25 22:40:04.497497+00
701	MX	Mexico	México	Ciudad Nezahualcóyotl	19.4006000	-99.0148000	1072676	2026-01-25 22:40:04.497497+00
702	IN	India	Madhya Pradesh	Gwalior	26.2125000	78.1775000	1069276	2026-01-25 22:40:04.497497+00
703	CA	Canada	Ontario	Ottawa	45.4247000	-75.6950000	1068821	2026-01-25 22:40:04.497497+00
704	CN	China	Liaoning	Haicheng	40.8824000	122.6852000	1067905	2026-01-25 22:40:04.497497+00
705	CN	China	Jiangxi	Jianguang	28.1958000	115.7833000	1065641	2026-01-25 22:40:04.497497+00
706	KR	Korea, South	Gyeonggi	Goyang	37.6500000	126.8000000	1061929	2026-01-25 22:40:04.497497+00
707	JP	Japan	Miyagi	Sendai	38.2682000	140.8694000	1061177	2026-01-25 22:40:04.497497+00
708	CN	China	Gansu	Xibeijie	39.7334000	98.4943000	1055706	2026-01-25 22:40:04.497497+00
709	IN	India	\N	Chandīgarh	30.7500000	76.7800000	1055450	2026-01-25 22:40:04.497497+00
710	RU	Russia	Voronezhskaya Oblast’	Voronezh	51.6717000	39.2106000	1051995	2026-01-25 22:40:04.497497+00
711	NI	Nicaragua	Managua	Managua	12.1364000	-86.2514000	1051236	2026-01-25 22:40:04.497497+00
712	CN	China	Ningxia	Zhongwei	37.5002000	105.1968000	1046000	2026-01-25 22:40:04.497497+00
713	CN	China	Sichuan	Jiancheng	30.3800000	104.5300000	1045900	2026-01-25 22:40:04.497497+00
714	TR	Turkey	Mersin	Mersin	36.8000000	34.6333000	1040507	2026-01-25 22:40:04.497497+00
715	CN	China	Shandong	Shouguang	36.8570000	118.7910000	1039205	2026-01-25 22:40:04.497497+00
716	CN	China	Hunan	Liangshi	27.2600000	111.7442000	1038416	2026-01-25 22:40:04.497497+00
717	BR	Brazil	Maranhão	São Luís	-2.5300000	-44.3028000	1037775	2026-01-25 22:40:04.497497+00
718	IN	India	Rājasthān	Jodhpur	26.2800000	73.0200000	1033918	2026-01-25 22:40:04.497497+00
719	US	United States	Tennessee	Memphis	35.1087000	-89.9663000	1033394	2026-01-25 22:40:04.497497+00
720	MZ	Mozambique	Maputo	Matola	-25.9667000	32.4667000	1032197	2026-01-25 22:40:04.497497+00
721	NG	Nigeria	Oyo	Ogbomoso	8.1333000	4.2500000	1032000	2026-01-25 22:40:04.497497+00
722	CN	China	Hainan	Sanya	18.2533000	109.5036000	1031396	2026-01-25 22:40:04.497497+00
723	BD	Bangladesh	Rangpur	Rangapukur	25.5206000	89.2147000	1031388	2026-01-25 22:40:04.497497+00
724	TM	Turkmenistan	Aşgabat	Ashgabat	37.9375000	58.3800000	1030063	2026-01-25 22:40:04.497497+00
725	NG	Nigeria	Enugu	Enugu	6.5000000	7.5000000	1029400	2026-01-25 22:40:04.497497+00
726	CN	China	Zhejiang	Linhai	28.8500000	121.1167000	1028813	2026-01-25 22:40:04.497497+00
727	RU	Russia	Permskiy Kray	Perm	58.0000000	56.3167000	1026908	2026-01-25 22:40:04.497497+00
728	EG	Egypt	Al Qalyūbīyah	Shubrā al Khaymah	30.1286000	31.2422000	1025569	2026-01-25 22:40:04.497497+00
729	LR	Liberia	Montserrado	Monrovia	6.3133000	-10.8014000	1021762	2026-01-25 22:40:04.497497+00
730	PK	Pakistan	Islamabad	Islamabad	33.6931000	73.0639000	1014825	2026-01-25 22:40:04.497497+00
731	CN	China	Guangdong	Xinyi	22.3549000	110.9468000	1013900	2026-01-25 22:40:04.497497+00
732	VN	Vietnam	Hồ Chí Minh	Thủ Đức	10.8266000	106.7609000	1013795	2026-01-25 22:40:04.497497+00
733	AF	Afghanistan	Jowzjān	Āqchah	36.9114000	66.1858000	1012000	2026-01-25 22:40:04.497497+00
734	UA	Ukraine	Odeska Oblast	Odesa	46.4920000	30.7081000	1010537	2026-01-25 22:40:04.497497+00
735	IN	India	Chhattīsgarh	Raipur	21.2444000	81.6306000	1010087	2026-01-25 22:40:04.497497+00
736	UZ	Uzbekistan	Namangan	Namangan	41.0011000	71.6683000	1010000	2026-01-25 22:40:04.497497+00
737	KR	Korea, South	Gyeongnam	Changwon	35.2708000	128.6631000	1009998	2026-01-25 22:40:04.497497+00
738	PE	Peru	Arequipa	Arequipa	-16.3989000	-71.5369000	1008290	2026-01-25 22:40:04.497497+00
739	CD	Congo (Kinshasa)	Kasaï	Tshikapa	-6.4167000	20.8000000	1006387	2026-01-25 22:40:04.497497+00
740	RU	Russia	Volgogradskaya Oblast’	Volgograd	48.7086000	44.5147000	1004763	2026-01-25 22:40:04.497497+00
741	MX	Mexico	Michoacán	Morelia	19.7683000	-101.1894000	1002461	2026-01-25 22:40:04.497497+00
742	IN	India	Rājasthān	Kota	25.1800000	75.8300000	1001694	2026-01-25 22:40:04.497497+00
743	PK	Pakistan	Balochistan	Quetta	30.1833000	67.0000000	1001205	2026-01-25 22:40:04.497497+00
744	US	United States	Oklahoma	Oklahoma City	35.4676000	-97.5136000	1000207	2026-01-25 22:40:04.497497+00
745	GH	Ghana	Bono	Domaa-Ahenkro	7.2739000	-2.8735000	1000000	2026-01-25 22:40:04.497497+00
746	IN	India	Uttar Pradesh	Bareilly	28.3667000	79.4306000	1000000	2026-01-25 22:40:04.497497+00
747	CN	China	Jilin	Liaoyuan	42.8880000	125.1447000	996903	2026-01-25 22:40:04.497497+00
748	SE	Sweden	Stockholm	Stockholm	59.3275000	18.0547000	995574	2026-01-25 22:40:04.497497+00
749	FR	France	Nouvelle-Aquitaine	Bordeaux	44.8400000	-0.5800000	994920	2026-01-25 22:40:04.497497+00
750	CN	China	Jiangsu	Taixing	32.1590000	120.0290000	990200	2026-01-25 22:40:04.497497+00
751	MW	Malawi	Lilongwe	Lilongwe	-13.9669000	33.7873000	989318	2026-01-25 22:40:04.497497+00
752	HT	Haiti	Ouest	Port-au-Prince	18.5425000	-72.3386000	987310	2026-01-25 22:40:04.497497+00
753	TR	Turkey	İstanbul	Esenyurt	41.0342000	28.6800000	983571	2026-01-25 22:40:04.497497+00
754	ID	Indonesia	Riau	Pekanbaru	0.5092000	101.4453000	983356	2026-01-25 22:40:04.497497+00
755	ID	Indonesia	Jawa Barat	Bogor	-6.5966000	106.7972000	982469	2026-01-25 22:40:04.497497+00
756	VE	Venezuela	Bolívar	Ciudad Guayana	8.3667000	-62.6500000	978202	2026-01-25 22:40:04.497497+00
757	JP	Japan	Chiba	Chiba	35.6073000	140.1064000	975014	2026-01-25 22:40:04.497497+00
758	IQ	Iraq	Karkūk	Kirkuk	35.4667000	44.4000000	975000	2026-01-25 22:40:04.497497+00
759	CN	China	Henan	Shuizhai	33.4658000	114.8753000	973197	2026-01-25 22:40:04.497497+00
760	CN	China	Guizhou	Qianxi	27.0087000	106.0323000	970700	2026-01-25 22:40:04.497497+00
761	US	United States	Connecticut	Hartford	41.7661000	-72.6834000	969171	2026-01-25 22:40:04.497497+00
762	UA	Ukraine	Dnipropetrovska Oblast	Dnipro	48.4675000	35.0400000	968502	2026-01-25 22:40:04.497497+00
763	CN	China	Jilin	Baishan	41.9440000	126.4147000	968373	2026-01-25 22:40:04.497497+00
764	BD	Bangladesh	Dhaka	Nārāyanganj	23.6167000	90.5000000	967951	2026-01-25 22:40:04.497497+00
765	ZA	South Africa	Eastern Cape	Gqeberha	-33.9581000	25.6000000	967677	2026-01-25 22:40:04.497497+00
766	CN	China	Jiangsu	Huilong	31.8700000	121.7030000	967313	2026-01-25 22:40:04.497497+00
767	ES	Spain	Andalusia	Málaga	36.7194000	-4.4200000	967250	2026-01-25 22:40:04.497497+00
768	MA	Morocco	Marrakech-Safi	Marrakech	31.6300000	-8.0089000	966987	2026-01-25 22:40:04.497497+00
769	US	United States	Kentucky	Louisville	38.1663000	-85.6485000	965005	2026-01-25 22:40:04.497497+00
770	PH	Philippines	Cebu	Cebu City	10.3200000	123.7500000	964169	2026-01-25 22:40:04.497497+00
771	ER	Eritrea	Ma’ĭkel	Asmara	15.3358000	38.9411000	963000	2026-01-25 22:40:04.497497+00
772	IN	India	Tamil Nādu	Coimbatore	11.0008000	76.9633000	959823	2026-01-25 22:40:04.497497+00
773	BR	Brazil	Alagoas	Maceió	-9.6658000	-35.7350000	957916	2026-01-25 22:40:04.497497+00
774	CN	China	Hainan	Nada	19.5209000	109.5808000	954259	2026-01-25 22:40:04.497497+00
775	CN	China	Guangxi	Fangchenggang	21.6867000	108.3547000	953300	2026-01-25 22:40:04.497497+00
776	IN	India	Mahārāshtra	Solāpur	17.6800000	75.9200000	951558	2026-01-25 22:40:04.497497+00
777	SL	Sierra Leone	Western Area	Freetown	8.4833000	-13.2331000	951000	2026-01-25 22:40:04.497497+00
778	CN	China	Henan	Kaiyuan	36.0193000	113.8600000	950939	2026-01-25 22:40:04.497497+00
779	US	United States	New York	Buffalo	42.9018000	-78.8487000	949547	2026-01-25 22:40:04.497497+00
780	DO	Dominican Republic	Ozama	Santo Domingo Este	18.4855000	-69.8734000	948855	2026-01-25 22:40:04.497497+00
781	LA	Laos	Viangchan	Vientiane	17.9800000	102.6300000	948487	2026-01-25 22:40:04.497497+00
782	IR	Iran	Kermānshāh	Kermānshāh	34.3369000	47.0911000	946651	2026-01-25 22:40:04.497497+00
783	CD	Congo (Kinshasa)	Kinshasa	Kibanseke Première	-4.4419000	15.3950000	946372	2026-01-25 22:40:04.497497+00
784	MY	Malaysia	Pulau Pinang	Seberang Jaya	5.3909000	100.4104000	946092	2026-01-25 22:40:04.497497+00
785	MA	Morocco	Rabat-Salé-Kénitra	Sale	34.0333000	-6.8000000	945101	2026-01-25 22:40:04.497497+00
786	IN	India	Karnātaka	Hubli	15.3502000	75.1376000	943788	2026-01-25 22:40:04.497497+00
787	BO	Bolivia	La Paz	El Alto	-16.5047000	-68.1633000	943000	2026-01-25 22:40:04.497497+00
788	TR	Turkey	Ankara	Çankaya	39.9244000	32.8856000	942553	2026-01-25 22:40:04.497497+00
789	KR	Korea, South	Gyeonggi	Hwasu-dong	37.1997000	126.8314000	941489	2026-01-25 22:40:04.497497+00
790	CN	China	Guangdong	Yingcheng	24.2100000	113.4010000	941325	2026-01-25 22:40:04.497497+00
791	US	United States	Texas	Fort Worth	32.7817000	-97.3474000	941311	2026-01-25 22:40:04.497497+00
792	JP	Japan	Tōkyō	Setagaya	35.6466000	139.6532000	940071	2026-01-25 22:40:04.497497+00
793	TR	Turkey	Ankara	Keçiören	40.0000000	32.8667000	939279	2026-01-25 22:40:04.497497+00
794	CN	China	Guangdong	Luocheng	22.7689000	111.5697000	936931	2026-01-25 22:40:04.497497+00
795	IL	Israel	Jerusalem	Jerusalem	31.7789000	35.2256000	936425	2026-01-25 22:40:04.497497+00
796	SD	Sudan	Khartoum	Khartoum North	15.6333000	32.6333000	936349	2026-01-25 22:40:04.497497+00
797	CN	China	Henan	Meishan	34.1670000	112.8440000	936000	2026-01-25 22:40:04.497497+00
798	NG	Nigeria	Lagos	Mushin	6.5333000	3.3500000	935400	2026-01-25 22:40:04.497497+00
799	PE	Peru	La Libertad	Trujillo	-8.1120000	-79.0288000	935147	2026-01-25 22:40:04.497497+00
800	JP	Japan	Fukuoka	Kitakyūshū	33.8833000	130.8833000	935084	2026-01-25 22:40:04.497497+00
801	MX	Mexico	Aguascalientes	Aguascalientes	21.8760000	-102.2960000	934424	2026-01-25 22:40:04.497497+00
802	BD	Bangladesh	Khulna	Khulna	22.8167000	89.5500000	928891	2026-01-25 22:40:04.497497+00
803	MX	Mexico	Chihuahua	Chihuahua	28.6369000	-106.0769000	925762	2026-01-25 22:40:04.497497+00
804	US	United States	Connecticut	Bridgeport	41.1918000	-73.1954000	921660	2026-01-25 22:40:04.497497+00
805	CN	China	Jiangsu	Xin’an	34.2860000	118.3550000	920628	2026-01-25 22:40:04.497497+00
806	IN	India	Karnātaka	Mysore	12.3086000	76.6531000	920550	2026-01-25 22:40:04.497497+00
807	CN	China	Xinjiang	Kashgar	39.4681000	75.9938000	920000	2026-01-25 22:40:04.497497+00
808	KR	Korea, South	Gyeonggi	Sŏngnam	37.4333000	127.1500000	918771	2026-01-25 22:40:04.497497+00
809	US	United States	Louisiana	New Orleans	30.0687000	-89.9288000	918752	2026-01-25 22:40:04.497497+00
810	IN	India	Tamil Nādu	Trichinopoly	10.7903000	78.7047000	916857	2026-01-25 22:40:04.497497+00
811	CO	Colombia	Bolívar	Cartagena	10.4000000	-75.5000000	914552	2026-01-25 22:40:04.497497+00
812	CN	China	Shandong	Qingzhou	36.6853000	118.4796000	914047	2026-01-25 22:40:04.497497+00
813	IT	Italy	Campania	Naples	40.8358000	14.2486000	913462	2026-01-25 22:40:04.497497+00
814	AR	Argentina	Santiago del Estero	Santiago del Estero	-27.7833000	-64.2667000	911506	2026-01-25 22:40:04.497497+00
815	MX	Mexico	México	Naucalpan de Juárez	19.4753000	-99.2378000	910407	2026-01-25 22:40:04.497497+00
816	PH	Philippines	Masbate	Masbate	12.2700000	123.5800000	908920	2026-01-25 22:40:04.497497+00
817	NG	Nigeria	Imo	Owerri	5.4850000	7.0350000	908109	2026-01-25 22:40:04.497497+00
818	CN	China	Guangdong	Taishan	22.2520000	112.7940000	907744	2026-01-25 22:40:04.497497+00
819	CN	China	Shandong	Jiaozhou	36.2647000	120.0334000	907500	2026-01-25 22:40:04.497497+00
820	CN	China	Guangdong	Wuchuan	21.4410000	110.7790000	907354	2026-01-25 22:40:04.497497+00
821	CN	China	Liaoning	Wafangdian	39.6271000	121.9796000	905082	2026-01-25 22:40:04.497497+00
822	AR	Argentina	Buenos Aires	La Plata	-34.9211000	-57.9544000	904789	2026-01-25 22:40:04.497497+00
823	BF	Burkina Faso	Hauts-Bassins	Bobo-Dioulasso	11.1833000	-4.2833000	903887	2026-01-25 22:40:04.497497+00
824	SA	Saudi Arabia	Ash Sharqīyah	Ad Dammām	26.4333000	50.1000000	903312	2026-01-25 22:40:04.497497+00
825	CN	China	Hubei	Hanchuan	30.6667000	113.8333000	903296	2026-01-25 22:40:04.497497+00
826	CN	China	Zhejiang	Quzhou	28.9702000	118.8593000	902767	2026-01-25 22:40:04.497497+00
827	UA	Ukraine	Donetska Oblast	Donetsk	48.0028000	37.8053000	901645	2026-01-25 22:40:04.497497+00
828	EG	Egypt	Al Minūfīyah	Ashmūn	30.2974000	30.9764000	901191	2026-01-25 22:40:04.497497+00
829	CD	Congo (Kinshasa)	Ituri	Bunia	1.5667000	30.2500000	900666	2026-01-25 22:40:04.497497+00
830	CN	China	Heilongjiang	Wuchang	44.9240000	127.1580000	897705	2026-01-25 22:40:04.497497+00
831	BR	Brazil	Rio de Janeiro	São Gonçalo	-22.8269000	-43.0539000	896744	2026-01-25 22:40:04.497497+00
832	CN	China	Guangxi	Hengzhou	22.6799000	109.2614000	896099	2026-01-25 22:40:04.497497+00
833	CN	China	Shandong	Feicheng	36.1861000	116.7719000	894115	2026-01-25 22:40:04.497497+00
834	CO	Colombia	Santander	Bucaramanga	7.1333000	-73.0000000	893040	2026-01-25 22:40:04.497497+00
835	AO	Angola	Luanda	Cazenga	-8.8214000	13.2911000	892401	2026-01-25 22:40:04.497497+00
836	MX	Mexico	Yucatán	Mérida	20.9667000	-89.6167000	892363	2026-01-25 22:40:04.497497+00
837	CN	China	Heilongjiang	Hegang	47.3501000	130.2980000	891271	2026-01-25 22:40:04.497497+00
838	TR	Turkey	Bursa	Osmangazi	40.1983000	29.0600000	891250	2026-01-25 22:40:04.497497+00
839	IN	India	Uttar Pradesh	Morādābād	28.8319000	78.7764000	889810	2026-01-25 22:40:04.497497+00
840	CF	Central African Republic	Bangui	Bangui	4.3733000	18.5628000	889231	2026-01-25 22:40:04.497497+00
841	NG	Nigeria	Ogun	Abeokuta	7.1608000	3.3483000	888924	2026-01-25 22:40:04.497497+00
842	MX	Mexico	Quintana Roo	Cancún	21.1606000	-86.8475000	888797	2026-01-25 22:40:04.497497+00
843	CN	China	Hubei	Zaoyang	32.1290000	112.7720000	888794	2026-01-25 22:40:04.497497+00
844	CN	China	Jiangsu	Dongtai	32.7950000	120.5190000	888410	2026-01-25 22:40:04.497497+00
845	PH	Philippines	Rizal	Antipolo	14.5842000	121.1763000	887399	2026-01-25 22:40:04.497497+00
846	PH	Philippines	Taguig	Taguig City	14.5200000	121.0500000	886722	2026-01-25 22:40:04.497497+00
847	SA	Saudi Arabia	Tabūk	Tabūk	28.3972000	36.5789000	886036	2026-01-25 22:40:04.497497+00
848	CN	China	Hunan	Xishan	27.6461000	113.4970000	885987	2026-01-25 22:40:04.497497+00
849	CN	China	Zhejiang	Zhoushan	29.9856000	122.2074000	882932	2026-01-25 22:40:04.497497+00
850	PA	Panama	Panamá	Panama City	8.9711000	-79.5347000	880691	2026-01-25 22:40:04.497497+00
851	US	United States	Arizona	Tucson	32.1541000	-110.8787000	879871	2026-01-25 22:40:04.497497+00
852	CN	China	Heilongjiang	Yichun	47.7280000	128.8410000	878881	2026-01-25 22:40:04.497497+00
853	IQ	Iraq	As Sulaymānīyah	As Sulaymānīyah	35.5500000	45.4333000	878146	2026-01-25 22:40:04.497497+00
854	MY	Malaysia	Selangor	Klang	3.0223000	101.5481000	878000	2026-01-25 22:40:04.497497+00
855	IN	India	Tamil Nādu	Tiruppūr	11.1085000	77.3411000	877778	2026-01-25 22:40:04.497497+00
856	FR	France	Provence-Alpes-Côte d’Azur	Marseille	43.2964000	5.3700000	877215	2026-01-25 22:40:04.497497+00
857	IN	India	Haryāna	Gurgaon	28.4560000	77.0290000	876824	2026-01-25 22:40:04.497497+00
858	CN	China	Guangdong	Yangchun	22.1704000	111.7916000	875896	2026-01-25 22:40:04.497497+00
859	IQ	Iraq	Al Anbār	Ar Ramādī	33.4258000	43.2992000	874543	2026-01-25 22:40:04.497497+00
860	CN	China	Jiangsu	Hai’an	32.5350000	120.5630000	874334	2026-01-25 22:40:04.497497+00
861	IN	India	Punjab	Jalandhar	31.3260000	75.5762000	873725	2026-01-25 22:40:04.497497+00
862	CN	China	Hubei	Daye	30.0961000	114.9804000	871214	2026-01-25 22:40:04.497497+00
863	CN	China	Hubei	Zhongxiang	31.1680000	112.5880000	868897	2026-01-25 22:40:04.497497+00
864	CN	China	Shandong	Gaomi	36.3833000	119.7500000	868715	2026-01-25 22:40:04.497497+00
865	BR	Brazil	Piauí	Teresina	-5.0903000	-42.8167000	868075	2026-01-25 22:40:04.497497+00
866	CN	China	Tibet	Lhasa	29.6534000	91.1719000	867891	2026-01-25 22:40:04.497497+00
867	MY	Malaysia	Perak	Ipoh	4.6000000	101.0650000	866772	2026-01-25 22:40:04.497497+00
868	MX	Mexico	Coahuila	Saltillo	25.4231000	-100.9919000	864431	2026-01-25 22:40:04.497497+00
869	YE	Yemen	‘Adan	Aden	12.8000000	45.0333000	863000	2026-01-25 22:40:04.497497+00
870	US	United States	Texas	El Paso	31.8476000	-106.4300000	862494	2026-01-25 22:40:04.497497+00
871	CN	China	Jilin	Gongzhuling	43.5053000	124.8224000	862313	2026-01-25 22:40:04.497497+00
872	CN	China	Hunan	Lianyuan	27.6920000	111.6640000	862099	2026-01-25 22:40:04.497497+00
873	NG	Nigeria	Lagos	Ikeja	6.6000000	3.3500000	861300	2026-01-25 22:40:04.497497+00
874	RU	Russia	Tyumenskaya Oblast’	Tyumen	57.1500000	65.5333000	861100	2026-01-25 22:40:04.497497+00
875	BO	Bolivia	Cochabamba	Cochabamba	-17.3883000	-66.1597000	856198	2026-01-25 22:40:04.497497+00
876	GB	United Kingdom	Portsmouth	Portsmouth	50.8058000	-1.0872000	855679	2026-01-25 22:40:04.497497+00
877	GB	United Kingdom	Southampton	Southampton	50.9025000	-1.4042000	855569	2026-01-25 22:40:04.497497+00
878	MX	Mexico	Sonora	Hermosillo	29.0989000	-110.9542000	855563	2026-01-25 22:40:04.497497+00
879	KR	Korea, South	Chungbuk	Cheongju	36.6333000	127.4833000	852018	2026-01-25 22:40:04.497497+00
880	CN	China	Xinjiang	Shache	38.4261000	77.2500000	851374	2026-01-25 22:40:04.497497+00
881	VN	Vietnam	Thanh Hóa	Thanh Hóa	19.8075000	105.7764000	850000	2026-01-25 22:40:04.497497+00
882	CN	China	Hubei	Macheng	31.1730000	115.0080000	849090	2026-01-25 22:40:04.497497+00
883	NG	Nigeria	Ondo	Akure	7.2500000	5.1950000	847903	2026-01-25 22:40:04.497497+00
884	NG	Nigeria	Kwara	Ilorin	8.5000000	4.5500000	847582	2026-01-25 22:40:04.497497+00
885	IQ	Iraq	Arbīl	Erbil	36.1911000	44.0094000	846000	2026-01-25 22:40:04.497497+00
886	NP	Nepal	\N	Kathmandu	27.7100000	85.3200000	845767	2026-01-25 22:40:04.497497+00
887	IT	Italy	Piedmont	Turin	45.0792000	7.6761000	841600	2026-01-25 22:40:04.497497+00
888	CN	China	Shandong	Anqiu	36.4780000	119.2190000	840553	2026-01-25 22:40:04.497497+00
889	CN	China	Shanxi	Yuci	37.6823000	112.7281000	840000	2026-01-25 22:40:04.497497+00
890	CN	China	Jilin	Dehui	44.5350000	125.7030000	839786	2026-01-25 22:40:04.497497+00
891	ZA	South Africa	KwaZulu-Natal	Pietermaritzburg	-29.6167000	30.3833000	839327	2026-01-25 22:40:04.497497+00
892	ZA	South Africa	KwaZulu-Natal	Durban	-29.8833000	31.0500000	838634	2026-01-25 22:40:04.497497+00
893	RU	Russia	Saratovskaya Oblast’	Saratov	51.5300000	46.0350000	838042	2026-01-25 22:40:04.497497+00
894	IN	India	Odisha	Bhubaneshwar	20.2700000	85.8400000	837737	2026-01-25 22:40:04.497497+00
895	CN	China	Jilin	Yushu	44.8260000	126.5500000	836098	2026-01-25 22:40:04.497497+00
896	BR	Brazil	Paraíba	João Pessoa	-7.1200000	-34.8800000	833932	2026-01-25 22:40:04.497497+00
897	ID	Indonesia	Kalimantan Timur	Samarinda	-0.5000000	117.1378000	831460	2026-01-25 22:40:04.497497+00
898	US	United States	Nebraska	Omaha	41.2627000	-96.0529000	826161	2026-01-25 22:40:04.497497+00
899	CN	China	Henan	Qingping	34.5390000	113.3910000	826031	2026-01-25 22:40:04.497497+00
900	CN	China	Hunan	Rongjiawan	29.1500000	113.1024000	826000	2026-01-25 22:40:04.497497+00
901	CN	China	Shandong	Weichanglu	37.1792000	119.9333000	824708	2026-01-25 22:40:04.497497+00
902	JP	Japan	Ōsaka	Sakai	34.5733000	135.4831000	824408	2026-01-25 22:40:04.497497+00
903	TR	Turkey	Eskişehir	Eskişehir	39.7767000	30.5206000	820568	2026-01-25 22:40:04.497497+00
904	CN	China	Hebei	Renqiu	38.6860000	116.0840000	816401	2026-01-25 22:40:04.497497+00
905	CN	China	Zhejiang	Wutong	30.6333000	120.5333000	815848	2026-01-25 22:40:04.497497+00
906	VE	Venezuela	Anzoátegui	Barcelona	10.1403000	-64.6833000	815141	2026-01-25 22:40:04.497497+00
907	CN	China	Hebei	Wu’an	36.6970000	114.2040000	811631	2026-01-25 22:40:04.497497+00
908	BR	Brazil	São Paulo	São Bernardo do Campo	-23.6939000	-46.5650000	810729	2026-01-25 22:40:04.497497+00
909	US	United States	Texas	McAllen	26.2252000	-98.2467000	810034	2026-01-25 22:40:04.497497+00
910	IN	India	Delhi	Narela	28.8500000	77.1000000	809913	2026-01-25 22:40:04.497497+00
911	IN	India	Mahārāshtra	Bhayandar	19.2900000	72.8500000	809378	2026-01-25 22:40:04.497497+00
912	MX	Mexico	Sinaloa	Culiacán	24.8069000	-107.3939000	808416	2026-01-25 22:40:04.497497+00
913	TD	Chad	N’Djamena	N’Djamena	12.1053000	15.0447000	807000	2026-01-25 22:40:04.497497+00
914	CN	China	Zhejiang	Xiashi	30.5333000	120.6833000	806966	2026-01-25 22:40:04.497497+00
915	CO	Colombia	Norte de Santander	Cúcuta	7.8942000	-72.5039000	806378	2026-01-25 22:40:04.497497+00
916	CN	China	Jiangsu	Danyang	32.0000000	119.5860000	806300	2026-01-25 22:40:04.497497+00
917	CN	China	Zhejiang	Dongyang	29.2667000	120.2167000	804398	2026-01-25 22:40:04.497497+00
918	PL	Poland	Małopolskie	Kraków	50.0614000	19.9372000	804237	2026-01-25 22:40:04.497497+00
919	DZ	Algeria	Oran	Oran	35.6969000	-0.6331000	803329	2026-01-25 22:40:04.497497+00
920	PH	Philippines	Pasig	Pasig City	14.5605000	121.0765000	803159	2026-01-25 22:40:04.497497+00
921	GR	Greece	Kentrikí Makedonía	Thessaloníki	40.6403000	22.9356000	802572	2026-01-25 22:40:04.497497+00
922	MW	Malawi	Blantyre	Blantyre	-15.7861000	35.0058000	800264	2026-01-25 22:40:04.497497+00
923	CO	Colombia	Huila	Palermo	2.8917000	-75.4375000	800000	2026-01-25 22:40:04.497497+00
924	CN	China	Tibet	Qamdo	31.1430000	97.1700000	798067	2026-01-25 22:40:04.497497+00
925	IN	India	Andhra Pradesh	Karīmnagar	18.4386000	79.1288000	797447	2026-01-25 22:40:04.497497+00
926	GA	Gabon	Estuaire	Libreville	0.3901000	9.4544000	797003	2026-01-25 22:40:04.497497+00
927	CN	China	Hebei	Hejian	38.4466000	116.0995000	795198	2026-01-25 22:40:04.497497+00
928	TR	Turkey	Adana	Seyhan	36.9831000	35.3328000	795012	2026-01-25 22:40:04.497497+00
929	CN	China	Shandong	Laiyang	36.9758000	120.7136000	794986	2026-01-25 22:40:04.497497+00
930	MX	Mexico	Querétaro	Querétaro	20.5875000	-100.3928000	794789	2026-01-25 22:40:04.497497+00
931	CN	China	Hunan	Wuxi	26.5800000	111.8410000	791939	2026-01-25 22:40:04.497497+00
932	CN	China	Hunan	Yiyang	26.4221000	112.3999000	790676	2026-01-25 22:40:04.497497+00
933	JP	Japan	Niigata	Niigata	37.9161000	139.0364000	790646	2026-01-25 22:40:04.497497+00
934	VN	Vietnam	Nghệ An	Vinh	18.6667000	105.6667000	790000	2026-01-25 22:40:04.497497+00
935	CN	China	Henan	Puxi	35.2125000	114.7350000	789300	2026-01-25 22:40:04.497497+00
936	US	United States	New York	Hempstead	40.6629000	-73.6089000	789177	2026-01-25 22:40:04.497497+00
937	JP	Japan	Shizuoka	Hamamatsu	34.7108000	137.7275000	788211	2026-01-25 22:40:04.497497+00
938	CN	China	Henan	Zijinglu	34.7667000	112.9667000	785242	2026-01-25 22:40:04.497497+00
939	PK	Pakistan	Khyber Pakhtunkhwa	Kumila	35.2500000	73.5000000	784711	2026-01-25 22:40:04.497497+00
940	CN	China	Guizhou	Xingyi	25.0920000	104.8955000	783120	2026-01-25 22:40:04.497497+00
941	CN	China	Guangdong	Xingcheng	24.1347000	115.7300000	779411	2026-01-25 22:40:04.497497+00
942	US	United States	Alabama	Birmingham	33.5279000	-86.7971000	778756	2026-01-25 22:40:04.497497+00
943	CN	China	Xinjiang	Ailan Mubage	43.9080000	81.2777000	778047	2026-01-25 22:40:04.497497+00
944	AO	Angola	Huíla	Lubango	-14.9167000	13.5000000	776249	2026-01-25 22:40:04.497497+00
945	DE	Germany	Hesse	Frankfurt	50.1106000	8.6822000	775790	2026-01-25 22:40:04.497497+00
946	SY	Syria	Ḩimş	Homs	34.7319000	36.7181000	775404	2026-01-25 22:40:04.497497+00
947	ES	Spain	Basque Country	Bilbao	43.2569000	-2.9236000	775000	2026-01-25 22:40:04.497497+00
948	MX	Mexico	San Luis Potosí	San Luis Potosí	22.1511000	-100.9761000	772828	2026-01-25 22:40:04.497497+00
949	KR	Korea, South	Gyeonggi	Bucheon	37.5000000	126.7833000	772450	2026-01-25 22:40:04.497497+00
950	CN	China	Zhejiang	Fuyang	30.0553000	119.9500000	771000	2026-01-25 22:40:04.497497+00
951	CN	China	Xinjiang	Korla	41.7259000	86.1746000	770000	2026-01-25 22:40:04.497497+00
952	TJ	Tajikistan	Sughd	Khŭjand	40.2833000	69.6333000	770000	2026-01-25 22:40:04.497497+00
953	KP	Korea, North	Hamnam	Hamhŭng	39.9167000	127.5333000	768551	2026-01-25 22:40:04.497497+00
954	TR	Turkey	Erzurum	Erzurum	39.9086000	41.2769000	767848	2026-01-25 22:40:04.497497+00
955	US	United States	New Mexico	Albuquerque	35.1054000	-106.6465000	767499	2026-01-25 22:40:04.497497+00
956	HR	Croatia	Zagreb, Grad	Zagreb	45.8131000	15.9772000	767131	2026-01-25 22:40:04.497497+00
957	AE	United Arab Emirates	Abū Z̧aby	Al ‘Ayn	24.2075000	55.7447000	766936	2026-01-25 22:40:04.497497+00
958	TZ	Tanzania	Dodoma	Dodoma	-6.1731000	35.7419000	765179	2026-01-25 22:40:04.497497+00
959	SN	Senegal	Dakar	Pikine	14.7440000	-17.4021000	764597	2026-01-25 22:40:04.497497+00
960	IN	India	Punjab	Patiāla	30.3400000	76.3800000	763280	2026-01-25 22:40:04.497497+00
961	PK	Pakistan	Punjab	Bahawalpur	29.3956000	71.6836000	762111	2026-01-25 22:40:04.497497+00
962	CN	China	Shandong	Qingnian	36.8494000	115.7061000	760781	2026-01-25 22:40:04.497497+00
963	CN	China	Hebei	Sanhe	40.0167000	117.0833000	760107	2026-01-25 22:40:04.497497+00
964	NG	Nigeria	Kaduna	Kaduna	10.5167000	7.4333000	760084	2026-01-25 22:40:04.497497+00
965	CA	Canada	Manitoba	Winnipeg	49.8844000	-97.1464000	758515	2026-01-25 22:40:04.497497+00
966	SO	Somalia	Gedo	Baardheere	2.3447000	42.2764000	755500	2026-01-25 22:40:04.497497+00
967	IN	India	Uttar Pradesh	Shīshgarh	28.7200000	79.3200000	753815	2026-01-25 22:40:04.497497+00
968	CN	China	Jiangxi	Leping	28.9780000	117.1520000	753787	2026-01-25 22:40:04.497497+00
969	LK	Sri Lanka	Western	Colombo	6.9167000	79.8333000	752993	2026-01-25 22:40:04.497497+00
970	JP	Japan	Tōkyō	Nerima	35.7356000	139.6517000	752608	2026-01-25 22:40:04.497497+00
971	BR	Brazil	Rio Grande do Norte	Natal	-5.7950000	-35.2089000	751300	2026-01-25 22:40:04.497497+00
972	CN	China	Hubei	Lichuan	30.2910000	108.9364000	750670	2026-01-25 22:40:04.497497+00
973	TR	Turkey	İstanbul	Pendik	40.8747000	29.2350000	750435	2026-01-25 22:40:04.497497+00
974	PL	Poland	Pomorskie	Gdańsk	54.3475000	18.6453000	749786	2026-01-25 22:40:04.497497+00
975	CN	China	Jiangsu	Licheng	31.4306000	119.4788000	749522	2026-01-25 22:40:04.497497+00
976	BR	Brazil	São Paulo	Santo André	-23.6533000	-46.5280000	748919	2026-01-25 22:40:04.497497+00
977	UZ	Uzbekistan	Andijon	Andijon	40.7833000	72.3333000	747800	2026-01-25 22:40:04.497497+00
978	SO	Somalia	Mudug	Gaalkacyo	6.7697000	47.4308000	745000	2026-01-25 22:40:04.497497+00
979	JP	Japan	Tōkyō	Ōta-ku	35.5614000	139.7161000	744849	2026-01-25 22:40:04.497497+00
980	IN	India	Kerala	Thiruvananthapuram	8.5241000	76.9366000	743691	2026-01-25 22:40:04.497497+00
981	MZ	Mozambique	Nampula	Nampula	-15.1167000	39.2667000	743000	2026-01-25 22:40:04.497497+00
982	CN	China	Liaoning	Zhuanghe	39.6810000	122.9670000	742496	2026-01-25 22:40:04.497497+00
983	MM	Burma	Mandalay	Kyaukse	21.6131000	96.1303000	741071	2026-01-25 22:40:04.497497+00
984	US	United States	Oklahoma	Tulsa	36.1283000	-95.9042000	740620	2026-01-25 22:40:04.497497+00
985	CN	China	Henan	Chengguan	35.4623000	113.8054000	740435	2026-01-25 22:40:04.497497+00
986	TR	Turkey	İstanbul	Bağcılar	41.0344000	28.8564000	740069	2026-01-25 22:40:04.497497+00
987	CI	Côte d’Ivoire	Vallée du Bandama	Bouaké	7.6833000	-5.0331000	740000	2026-01-25 22:40:04.497497+00
988	AO	Angola	Cabinda	Cabinda	-5.5600000	12.1900000	739182	2026-01-25 22:40:04.497497+00
989	JP	Japan	Kumamoto	Kumamoto	32.8031000	130.7078000	738385	2026-01-25 22:40:04.497497+00
990	IR	Iran	Kermān	Kermān	30.2625000	57.0575000	738374	2026-01-25 22:40:04.497497+00
991	CN	China	Henan	Lingbao Chengguanzhen	34.5176000	110.8942000	736300	2026-01-25 22:40:04.497497+00
992	IR	Iran	Āz̄arbāyjān-e Gharbī	Orūmīyeh	37.5439000	45.0647000	736224	2026-01-25 22:40:04.497497+00
993	CA	Canada	Quebec	Quebec City	46.8139000	-71.2081000	733156	2026-01-25 22:40:04.497497+00
994	CN	China	Sichuan	Taihe	30.8710000	105.3880000	732380	2026-01-25 22:40:04.497497+00
995	KR	Korea, South	Gyeonggi	Yanggok	37.6333000	127.2167000	732376	2026-01-25 22:40:04.497497+00
996	CN	China	Sichuan	Zhongba	31.7710000	104.7550000	731343	2026-01-25 22:40:04.497497+00
997	NG	Nigeria	Osun	Osogbo	7.7667000	4.5667000	731000	2026-01-25 22:40:04.497497+00
998	CN	China	Ningxia	Sizhan	38.9846000	106.3828000	730400	2026-01-25 22:40:04.497497+00
999	CN	China	Henan	Suohe	34.7833000	113.3500000	730135	2026-01-25 22:40:04.497497+00
1000	CN	China	Hunan	Xiangxiang	27.7186000	112.5502000	730103	2026-01-25 22:40:04.497497+00
1001	CA	Canada	Ontario	Hamilton	43.2567000	-79.8692000	729560	2026-01-25 22:40:05.006669+00
1002	CN	China	Henan	Songyang	34.4553000	113.0253000	729332	2026-01-25 22:40:05.006669+00
1003	PH	Philippines	Cagayan de Oro	Cagayan de Oro	8.4800000	124.6500000	728402	2026-01-25 22:40:05.006669+00
1004	CN	China	Hebei	Qian’an	39.9990000	118.7010000	728160	2026-01-25 22:40:05.006669+00
1005	CN	China	Henan	Shuangqiao	35.0670000	112.6020000	727265	2026-01-25 22:40:05.006669+00
1006	CN	China	Anhui	Chaohucun	31.6244000	117.8902000	727162	2026-01-25 22:40:05.006669+00
1007	BH	Bahrain	Al ‘Āşimah	Manama	26.2233000	50.5875000	727000	2026-01-25 22:40:05.006669+00
1008	CN	China	Shandong	Zouping	36.8630000	117.7430000	726722	2026-01-25 22:40:05.006669+00
1009	US	United States	South Carolina	Charleston	32.8168000	-79.9687000	726389	2026-01-25 22:40:05.006669+00
1010	CD	Congo (Kinshasa)	Sud-Kivu	Uvira	-3.4000000	29.1500000	726000	2026-01-25 22:40:05.006669+00
1011	IN	India	West Bengal	Durgāpur	23.5500000	87.3200000	726000	2026-01-25 22:40:05.006669+00
1012	IQ	Iraq	An Najaf	An Najaf	32.0290000	44.3396000	724700	2026-01-25 22:40:05.006669+00
1013	US	United States	California	Fresno	36.7830000	-119.7939000	724547	2026-01-25 22:40:05.006669+00
1014	CN	China	Guangxi	Cencheng	22.9167000	111.0000000	724364	2026-01-25 22:40:05.006669+00
1015	TR	Turkey	İstanbul	Umraniye	41.0311000	29.1081000	723760	2026-01-25 22:40:05.006669+00
1016	BR	Brazil	São Paulo	Sorocaba	-23.5019000	-47.4578000	723574	2026-01-25 22:40:05.006669+00
1017	CN	China	Zhejiang	Guli	28.9000000	120.0333000	723490	2026-01-25 22:40:05.006669+00
1018	JP	Japan	Kanagawa	Sagamihara	35.5667000	139.3667000	722973	2026-01-25 22:40:05.006669+00
1019	CN	China	Shandong	Laixi	36.8667000	120.5333000	720103	2026-01-25 22:40:05.006669+00
1020	JP	Japan	Okayama	Okayama	34.6500000	133.9167000	720043	2026-01-25 22:40:05.006669+00
1021	CL	Chile	Biobío	Concepción	-36.8282000	-73.0514000	719944	2026-01-25 22:40:05.006669+00
1022	HN	Honduras	Cortés	San Pedro Sula	15.5062000	-88.0249000	719064	2026-01-25 22:40:05.006669+00
1023	CA	Canada	Ontario	Mississauga	43.6000000	-79.6500000	717961	2026-01-25 22:40:05.006669+00
1024	CN	China	Guangdong	Changsha	22.3773000	112.6982000	717700	2026-01-25 22:40:05.006669+00
1025	UA	Ukraine	Lvivska Oblast	Lviv	49.8425000	24.0322000	717273	2026-01-25 22:40:05.006669+00
1026	CN	China	Xinjiang	Shihezi	44.3054000	86.0804000	717000	2026-01-25 22:40:05.006669+00
1027	PH	Philippines	Valenzuela	Valenzuela	14.7000000	120.9800000	714978	2026-01-25 22:40:05.006669+00
1028	AO	Angola	Huambo	Huambo	-12.7767000	15.7347000	713134	2026-01-25 22:40:05.006669+00
1029	CN	China	Sichuan	Xichang	27.8944000	102.2644000	712434	2026-01-25 22:40:05.006669+00
1030	CN	China	Hubei	Guangshui	31.6170000	113.8260000	710900	2026-01-25 22:40:05.006669+00
1031	UA	Ukraine	Zaporizka Oblast	Zaporizhzhia	47.8500000	35.1175000	710052	2026-01-25 22:40:05.006669+00
1032	IN	India	Mahārāshtra	Bhiwandi	19.2967000	73.0631000	709665	2026-01-25 22:40:05.006669+00
1033	CN	China	Jiangsu	Gaoyou	32.8450000	119.5080000	709572	2026-01-25 22:40:05.006669+00
1034	CN	China	Jiangsu	Chengxiang	31.5640000	121.1740000	709500	2026-01-25 22:40:05.006669+00
1035	IN	India	Rājasthān	Bhīlwāra	25.3500000	74.6300000	709483	2026-01-25 22:40:05.006669+00
1036	NO	Norway	Oslo	Oslo	59.9133000	10.7389000	709037	2026-01-25 22:40:05.006669+00
1037	MY	Malaysia	Pulau Pinang	George Town	5.4136000	100.3294000	708127	2026-01-25 22:40:05.006669+00
1038	GB	United Kingdom	Bristol, City of	Bristol	51.4536000	-2.5975000	707412	2026-01-25 22:40:05.006669+00
1039	CN	China	Hebei	Zunhua	40.1890000	117.9660000	707047	2026-01-25 22:40:05.006669+00
1040	IN	India	Uttar Pradesh	Sahāranpur	29.9639000	77.5458000	705478	2026-01-25 22:40:05.006669+00
1041	TR	Turkey	Ankara	Yenimahalle	39.9719000	32.8119000	704652	2026-01-25 22:40:05.006669+00
1042	IN	India	Andhra Pradesh	Warangal	17.9689000	79.5941000	704570	2026-01-25 22:40:05.006669+00
1043	KP	Korea, North	Namp’o	Nampo	38.7356000	125.4089000	703317	2026-01-25 22:40:05.006669+00
1044	PH	Philippines	Cavite	Dasmariñas	14.3300000	120.9400000	703141	2026-01-25 22:40:05.006669+00
1045	IN	India	West Bengal	Shiliguri	26.7100000	88.4300000	701489	2026-01-25 22:40:05.006669+00
1046	SO	Somalia	Bari	Boosaaso	11.2800000	49.1800000	700906	2026-01-25 22:40:05.006669+00
1047	PK	Pakistan	Khyber Pakhtunkhwa	Parachinar	33.9000000	70.1000000	700000	2026-01-25 22:40:05.006669+00
1048	SY	Syria	Al Lādhiqīyah	Latakia	35.5400000	35.7800000	700000	2026-01-25 22:40:05.006669+00
1049	CN	China	Shaanxi	Tongchuan	34.8970000	108.9450000	698322	2026-01-25 22:40:05.006669+00
1050	CN	China	Hubei	Xindi	29.8270000	113.4760000	698188	2026-01-25 22:40:05.006669+00
1051	JP	Japan	Chiba	Edogawa	35.7000000	139.8833000	697932	2026-01-25 22:40:05.006669+00
1052	PH	Philippines	General Santos	General Santos	6.1200000	125.1700000	697315	2026-01-25 22:40:05.006669+00
1053	SY	Syria	Ḩamāh	Ḩamāh	35.1503000	36.7300000	696863	2026-01-25 22:40:05.006669+00
1054	US	United States	New York	Rochester	43.1680000	-77.6162000	694707	2026-01-25 22:40:05.006669+00
1055	NG	Nigeria	Bauchi	Bauchi	10.5000000	10.0000000	693700	2026-01-25 22:40:05.006669+00
1056	IN	India	Tamil Nādu	Salem	11.6500000	78.1500000	693236	2026-01-25 22:40:05.006669+00
1057	EG	Egypt	Al Fayyūm	Sinnūris	29.4072000	30.8667000	692701	2026-01-25 22:40:05.006669+00
1058	CI	Côte d’Ivoire	Abidjan	Cocody	5.3351000	-4.0039000	692583	2026-01-25 22:40:05.006669+00
1059	NG	Nigeria	Kogi	Lokoja	7.8019000	6.7442000	692050	2026-01-25 22:40:05.006669+00
1060	MX	Mexico	Nuevo León	Guadalupe	25.6775000	-100.2597000	691931	2026-01-25 22:40:05.006669+00
1061	TR	Turkey	Konya	Selçuklu	37.8814000	32.4922000	690667	2026-01-25 22:40:05.006669+00
1062	IQ	Iraq	Karbalā’	Karbalā’	32.6167000	44.0333000	690100	2026-01-25 22:40:05.006669+00
1063	IR	Iran	Khūzestān	Borvāyeh-ye Al Bū ‘Azīz	31.6283000	48.6147000	690000	2026-01-25 22:40:05.006669+00
1064	PH	Philippines	Parañaque	City of Parañaque	14.5008000	120.9915000	689992	2026-01-25 22:40:05.006669+00
1065	CN	China	Heilongjiang	Taihecun	45.7710000	131.0030000	689611	2026-01-25 22:40:05.006669+00
1066	TR	Turkey	Ankara	Mamak	39.9422000	32.9231000	687535	2026-01-25 22:40:05.006669+00
1067	CN	China	Henan	Jianshe	34.2137000	113.7629000	687130	2026-01-25 22:40:05.006669+00
1068	ES	Spain	Aragon	Zaragoza	41.6500000	-0.8833000	686986	2026-01-25 22:40:05.006669+00
1069	CN	China	Fujian	Shishi	24.7167000	118.7000000	685930	2026-01-25 22:40:05.006669+00
1070	JP	Japan	Shizuoka	Shizuoka	34.9756000	138.3828000	685589	2026-01-25 22:40:05.006669+00
1071	NG	Nigeria	Lagos	Agege	6.6219000	3.3258000	683600	2026-01-25 22:40:05.006669+00
1072	AR	Argentina	Buenos Aires	Mar del Plata	-38.0000000	-57.5500000	682605	2026-01-25 22:40:05.006669+00
1073	JP	Japan	Tōkyō	Adachi	35.7833000	139.8000000	682326	2026-01-25 22:40:05.006669+00
1074	ID	Indonesia	Kalimantan Barat	Pontianak	-0.0206000	109.3414000	680880	2026-01-25 22:40:05.006669+00
1075	IR	Iran	Gīlān	Rasht	37.2744000	49.5889000	679995	2026-01-25 22:40:05.006669+00
1076	CN	China	Tibet	Xigazê	29.2500000	88.8833000	679771	2026-01-25 22:40:05.006669+00
1077	BJ	Benin	Littoral	Cotonou	6.3667000	2.4333000	679012	2026-01-25 22:40:05.006669+00
1078	ID	Indonesia	Jawa Barat	Tasikmalaya	-7.3161000	108.1975000	678027	2026-01-25 22:40:05.006669+00
1079	IN	India	Kerala	Kochi	9.9312000	76.2673000	677381	2026-01-25 22:40:05.006669+00
1080	CO	Colombia	Atlántico	Soledad	10.9167000	-74.7500000	676014	2026-01-25 22:40:05.006669+00
1081	CN	China	Zhejiang	Shanhu	29.6000000	120.8167000	675226	2026-01-25 22:40:05.006669+00
1082	SE	Sweden	Västra Götaland	Gothenburg	57.7075000	11.9675000	674529	2026-01-25 22:40:05.006669+00
1083	MX	Mexico	Guerrero	Acapulco de Juárez	16.8636000	-99.8825000	673478	2026-01-25 22:40:05.006669+00
1084	IN	India	Uttar Pradesh	Gorakhpur	26.7637000	83.4039000	673446	2026-01-25 22:40:05.006669+00
1085	IR	Iran	Hamadān	Bahār	34.9078000	48.4394000	673405	2026-01-25 22:40:05.006669+00
1086	PL	Poland	Dolnośląskie	Wrocław	51.1100000	17.0325000	672929	2026-01-25 22:40:05.006669+00
1087	ES	Spain	Murcia	Murcia	37.9861000	-1.1303000	672773	2026-01-25 22:40:05.006669+00
1088	CN	China	Zhejiang	Pinghu	30.7000000	121.0167000	671326	2026-01-25 22:40:05.006669+00
1089	CN	China	Sichuan	Guankou	30.9880000	103.6470000	671200	2026-01-25 22:40:05.006669+00
1090	PL	Poland	Łódzkie	Łódź	51.7769000	19.4547000	670642	2026-01-25 22:40:05.006669+00
1091	CN	China	Shandong	Yatou	37.1653000	122.4867000	670251	2026-01-25 22:40:05.006669+00
1092	ID	Indonesia	Bali	Denpasar	-8.6717000	115.2339000	670210	2026-01-25 22:40:05.006669+00
1093	IN	India	Andhra Pradesh	Guntūr	16.3008000	80.4428000	670073	2026-01-25 22:40:05.006669+00
1094	RU	Russia	Samarskaya Oblast’	Tolyatti	53.5089000	49.4222000	667956	2026-01-25 22:40:05.006669+00
1095	US	United States	Ohio	Dayton	39.7805000	-84.2003000	667936	2026-01-25 22:40:05.006669+00
1096	KP	Korea, North	Hambuk	Ch’ŏngjin	41.7833000	129.7667000	667929	2026-01-25 22:40:05.006669+00
1097	CN	China	Heilongjiang	Zhaodong	46.0510000	125.9620000	666532	2026-01-25 22:40:05.006669+00
1098	CN	China	Henan	Puyang Chengguanzhen	35.7004000	114.9800000	666322	2026-01-25 22:40:05.006669+00
1099	ZW	Zimbabwe	Bulawayo	Bulawayo	-20.1700000	28.5800000	665952	2026-01-25 22:40:05.006669+00
1100	BR	Brazil	Sergipe	Aracaju	-10.9111000	-37.0717000	664908	2026-01-25 22:40:05.006669+00
1101	PH	Philippines	Cavite	Bacoor	14.4624000	120.9645000	664625	2026-01-25 22:40:05.006669+00
1102	NL	Netherlands	Zuid-Holland	Rotterdam	51.9200000	4.4800000	664311	2026-01-25 22:40:05.006669+00
1103	MX	Mexico	Jalisco	Tlaquepaque	20.6167000	-103.3167000	664193	2026-01-25 22:40:05.006669+00
1104	CO	Colombia	Meta	Villavicencio	4.1500000	-73.6333000	664148	2026-01-25 22:40:05.006669+00
1105	BR	Brazil	Mato Grosso do Sul	Campo Grande	-20.4686000	-54.6222000	663621	2026-01-25 22:40:05.006669+00
1106	CN	China	Jiangsu	Jingcheng	32.0090000	120.2630000	663408	2026-01-25 22:40:05.006669+00
1107	RU	Russia	Dagestan	Makhachkala	42.9825000	47.5050000	662660	2026-01-25 22:40:05.006669+00
1108	ID	Indonesia	Kalimantan Selatan	Banjarmasin	-3.3200000	114.5925000	662230	2026-01-25 22:40:05.006669+00
1109	ZM	Zambia	Copperbelt	Kitwe	-12.8167000	28.2000000	661901	2026-01-25 22:40:05.006669+00
1110	VE	Venezuela	La Guaira	Catia La Mar	10.6000000	-67.0333000	661897	2026-01-25 22:40:05.006669+00
1111	NG	Nigeria	Anambra	Nneyi-Umuleri	6.3333000	6.8333000	660821	2026-01-25 22:40:05.006669+00
1112	SA	Saudi Arabia	Ash Sharqīyah	Al Hufūf	25.3608000	49.5997000	660788	2026-01-25 22:40:05.006669+00
1113	CN	China	Yunnan	Dali	25.6811000	100.3003000	660300	2026-01-25 22:40:05.006669+00
1114	NG	Nigeria	Taraba	Jalingo	8.9000000	11.3667000	660213	2026-01-25 22:40:05.006669+00
1115	PK	Pakistan	Punjab	Sargodha	32.0836000	72.6711000	659862	2026-01-25 22:40:05.006669+00
1116	IN	India	Assam	Karaikandi	24.8309000	92.6143000	659260	2026-01-25 22:40:05.006669+00
1117	KR	Korea, South	Chungnam	Ch’ŏnan	36.8100000	127.1475000	656583	2026-01-25 22:40:05.006669+00
1118	CA	Canada	Ontario	Brampton	43.6833000	-79.7667000	656480	2026-01-25 22:40:05.006669+00
1119	US	United States	Florida	Cape Coral	26.6443000	-81.9957000	656464	2026-01-25 22:40:05.006669+00
1120	IN	India	Uttarākhand	Haldwāni	29.2200000	79.5200000	656000	2026-01-25 22:40:05.006669+00
1121	BJ	Benin	Atlantique	Abomey-Calavi	6.4486000	2.3556000	655965	2026-01-25 22:40:05.006669+00
1122	TR	Turkey	Bursa	Yıldırım	40.1100000	29.0821000	655856	2026-01-25 22:40:05.006669+00
1123	IN	India	Mahārāshtra	Dhūlia	20.8997000	74.7697000	655603	2026-01-25 22:40:05.006669+00
1124	CN	China	Guizhou	Zhongshu	27.7919000	106.4013000	655300	2026-01-25 22:40:05.006669+00
1125	MX	Mexico	Durango	Durango	24.0250000	-104.6675000	654876	2026-01-25 22:40:05.006669+00
1126	CN	China	Hubei	Songzi	30.1740000	111.7570000	654762	2026-01-25 22:40:05.006669+00
1127	PH	Philippines	Manila	Tondo	14.6170000	120.9670000	654220	2026-01-25 22:40:05.006669+00
1128	EG	Egypt	Asyūţ	Dayrūţ	27.5564000	30.8106000	653847	2026-01-25 22:40:05.006669+00
1129	MX	Mexico	México	Tlalnepantla	19.5367000	-99.1947000	653410	2026-01-25 22:40:05.006669+00
1130	CN	China	Yunnan	Xiping	25.6005000	103.8166000	652604	2026-01-25 22:40:05.006669+00
1131	BR	Brazil	São Paulo	Osasco	-23.5328000	-46.7919000	652593	2026-01-25 22:40:05.006669+00
1132	VN	Vietnam	Thừa Thiên-Huế	Huế	16.4619000	107.5955000	652572	2026-01-25 22:40:05.006669+00
1133	PH	Philippines	Bulacan	San Jose del Monte	14.8139000	121.0453000	651813	2026-01-25 22:40:05.006669+00
1134	TR	Turkey	Denizli	Denizli	37.7833000	29.0964000	651200	2026-01-25 22:40:05.006669+00
1135	VE	Venezuela	Monagas	Maturín	9.7500000	-63.1830000	647459	2026-01-25 22:40:05.006669+00
1136	JP	Japan	Chiba	Honchō	35.6946000	139.9826000	644668	2026-01-25 22:40:05.006669+00
1137	CN	China	Hubei	Wuxue	29.8440000	115.5610000	644247	2026-01-25 22:40:05.006669+00
1138	IN	India	Gujarāt	Bhāvnagar	21.7600000	72.1500000	643382	2026-01-25 22:40:05.006669+00
1139	CN	China	Yunnan	Jinghong	22.0090000	100.7970000	642737	2026-01-25 22:40:05.006669+00
1140	CN	China	Hunan	Wugang	26.7266000	110.6319000	640181	2026-01-25 22:40:05.006669+00
1141	HK	Hong Kong	\N	Sha Tin	22.3802000	114.1898000	640000	2026-01-25 22:40:05.006669+00
1142	US	United States	Utah	Provo	40.2457000	-111.6457000	639820	2026-01-25 22:40:05.006669+00
1143	MD	Moldova	Chişinău	Chisinau	47.0228000	28.8353000	639000	2026-01-25 22:40:05.006669+00
1144	MY	Malaysia	Selangor	Petaling Jaya	3.0833000	101.6500000	638516	2026-01-25 22:40:05.006669+00
1145	US	United States	Colorado	Colorado Springs	38.8674000	-104.7605000	638421	2026-01-25 22:40:05.006669+00
1146	EE	Estonia	Tallinn	Tallinn	59.4372000	24.7453000	638076	2026-01-25 22:40:05.006669+00
1147	IN	India	Uttar Pradesh	Noida	28.5700000	77.3200000	637272	2026-01-25 22:40:05.006669+00
1148	ES	Spain	Canary Islands	Las Palmas	28.1258000	-15.4353000	635000	2026-01-25 22:40:05.006669+00
1149	US	United States	California	Mission Viejo	33.6096000	-117.6551000	634674	2026-01-25 22:40:05.006669+00
1150	IN	India	West Bengal	Bhāngar	22.5800000	88.4200000	634107	2026-01-25 22:40:05.006669+00
1151	US	United States	Pennsylvania	Allentown	40.5961000	-75.4756000	632175	2026-01-25 22:40:05.006669+00
1152	LY	Libya	Banghāzī	Benghazi	32.1167000	20.0667000	631555	2026-01-25 22:40:05.006669+00
1153	CN	China	Yunnan	Chuxiong	25.0330000	101.5459000	631530	2026-01-25 22:40:05.006669+00
1154	DE	Germany	North Rhine-Westphalia	Düsseldorf	51.2256000	6.7767000	631217	2026-01-25 22:40:05.006669+00
1155	IT	Italy	Sicilia	Palermo	38.1157000	13.3613000	630167	2026-01-25 22:40:05.006669+00
1156	US	United States	Louisiana	Baton Rouge	30.4420000	-91.1311000	630063	2026-01-25 22:40:05.006669+00
1157	PH	Philippines	Makati	Makati City	14.5567000	121.0214000	629616	2026-01-25 22:40:05.006669+00
1158	ZM	Zambia	Copperbelt	Ndola	-12.9689000	28.6325000	627503	2026-01-25 22:40:05.006669+00
1159	EG	Egypt	Al Qalyūbīyah	Ţūkh	30.3549000	31.2011000	627290	2026-01-25 22:40:05.006669+00
1160	GB	United Kingdom	Glasgow City	Glasgow	55.8611000	-4.2500000	626410	2026-01-25 22:40:05.006669+00
1161	UA	Ukraine	Rivnenska Oblast	Bazal’tove	50.6765000	26.1600000	625543	2026-01-25 22:40:05.006669+00
1162	SA	Saudi Arabia	Ash Sharqīyah	Al Qaţīf	26.5196000	50.0115000	625092	2026-01-25 22:40:05.006669+00
1163	IN	India	Chhattīsgarh	Bhilai	21.2100000	81.3800000	624700	2026-01-25 22:40:05.006669+00
1164	IN	India	Karnātaka	Mangalore	12.8717000	74.8425000	623841	2026-01-25 22:40:05.006669+00
1165	CN	China	Yunnan	Kaihua	23.3870000	104.2330000	623772	2026-01-25 22:40:05.006669+00
1166	RU	Russia	Irkutskaya Oblast’	Irkutsk	52.2892000	104.2800000	623736	2026-01-25 22:40:05.006669+00
1167	US	United States	Utah	Ogden	41.2279000	-111.9682000	623688	2026-01-25 22:40:05.006669+00
1168	CN	China	Hainan	Meilan	19.9990000	110.4030000	623667	2026-01-25 22:40:05.006669+00
1169	KR	Korea, South	Gyeonggi	Ansan	37.3167000	126.8333000	623256	2026-01-25 22:40:05.006669+00
1170	RU	Russia	Altayskiy Kray	Barnaul	53.3486000	83.7764000	623057	2026-01-25 22:40:05.006669+00
1171	CN	China	Hebei	Bazhou	39.1333000	116.3833000	622975	2026-01-25 22:40:05.006669+00
1172	CN	China	Xinjiang	Turpan	42.9512000	89.1895000	622903	2026-01-25 22:40:05.006669+00
1173	NG	Nigeria	Plateau	Jos	9.9167000	8.8903000	622802	2026-01-25 22:40:05.006669+00
1174	CN	China	Sichuan	Langzhong	31.5580000	106.0050000	622667	2026-01-25 22:40:05.006669+00
1175	CN	China	Shandong	Qufu	35.5819000	116.9862000	621971	2026-01-25 22:40:05.006669+00
1176	EG	Egypt	Ad Daqahlīyah	Al Manşūrah	31.0500000	31.3833000	621953	2026-01-25 22:40:05.006669+00
1177	CN	China	Yunnan	Tengyue	25.0167000	98.4833000	620000	2026-01-25 22:40:05.006669+00
1178	DE	Germany	Saxony	Leipzig	51.3400000	12.3750000	619879	2026-01-25 22:40:05.006669+00
1179	EG	Egypt	Al Qāhirah	Ḩalwān	29.8493000	31.3327000	619293	2026-01-25 22:40:05.006669+00
1180	VN	Vietnam	Hồ Chí Minh	Tân An	10.9050000	106.6994000	618984	2026-01-25 22:40:05.006669+00
1181	CI	Côte d’Ivoire	Abidjan	Port-Bouët	5.2568000	-3.9630000	618795	2026-01-25 22:40:05.006669+00
1182	RU	Russia	Udmurtiya	Izhevsk	56.8333000	53.1833000	618776	2026-01-25 22:40:05.006669+00
1183	US	United States	Tennessee	Knoxville	35.9692000	-83.9496000	618226	2026-01-25 22:40:05.006669+00
1184	CN	China	Jiangsu	Jurong	31.9460000	119.1640000	617706	2026-01-25 22:40:05.006669+00
1185	TZ	Tanzania	Arusha	Arusha	-3.3667000	36.6833000	617631	2026-01-25 22:40:05.006669+00
1186	IN	India	Bihār	Bihtā	25.5619000	84.8700000	617427	2026-01-25 22:40:05.006669+00
1187	CN	China	Zhejiang	Yuhuan	28.1277000	121.2288000	616346	2026-01-25 22:40:05.006669+00
1188	RU	Russia	Khabarovskiy Kray	Khabarovsk	48.4833000	135.0833000	615570	2026-01-25 22:40:05.006669+00
1189	TR	Turkey	Ankara	Etimesgut	39.9458000	32.6694000	614891	2026-01-25 22:40:05.006669+00
1190	CN	China	Beijing	Changping	40.2248000	116.1944000	614821	2026-01-25 22:40:05.006669+00
1191	MX	Mexico	México	Chimalhuacán	19.4131000	-98.9839000	614453	2026-01-25 22:40:05.006669+00
1192	AF	Afghanistan	Kandahār	Kandahār	31.6200000	65.7158000	614254	2026-01-25 22:40:05.006669+00
1193	MA	Morocco	Oriental	Oujda-Angad	34.6867000	-1.9114000	614000	2026-01-25 22:40:05.006669+00
1194	CN	China	Jiangxi	Ruiming	25.8860000	116.0270000	613894	2026-01-25 22:40:05.006669+00
1195	ID	Indonesia	Banten	Serang	-6.1200000	106.1503000	613356	2026-01-25 22:40:05.006669+00
1196	RU	Russia	Ul’yanovskaya Oblast’	Ulyanovsk	54.3167000	48.3667000	613334	2026-01-25 22:40:05.006669+00
1197	CN	China	Hebei	Shenzhou	38.0020000	115.5600000	613000	2026-01-25 22:40:05.006669+00
1198	ID	Indonesia	Jambi	Jambi	-1.5900000	103.6100000	612162	2026-01-25 22:40:05.006669+00
1199	IN	India	Uttar Pradesh	Hasanpur	28.7200000	78.2800000	611533	2026-01-25 22:40:05.006669+00
1200	US	United States	Michigan	Grand Rapids	42.9619000	-85.6562000	611480	2026-01-25 22:40:05.006669+00
1201	TR	Turkey	Antalya	Yukarıkaraman	36.9167000	30.6833000	608675	2026-01-25 22:40:05.006669+00
1202	MY	Malaysia	Pahang	Kuantan	3.8300000	103.3200000	607778	2026-01-25 22:40:05.006669+00
1203	AU	Australia	Queensland	Gold Coast	-28.0167000	153.4000000	607665	2026-01-25 22:40:05.006669+00
1204	JP	Japan	Saitama	Kawaguchi	35.8077000	139.7241000	607373	2026-01-25 22:40:05.006669+00
1205	CN	China	Liaoning	Dashiqiao	40.6167000	122.5167000	607098	2026-01-25 22:40:05.006669+00
1206	PH	Philippines	Las Piñas	Las Piñas City	14.4500000	120.9800000	606293	2026-01-25 22:40:05.006669+00
1207	IN	India	Odisha	Cuttack	20.5236000	85.7881000	606007	2026-01-25 22:40:05.006669+00
1208	AR	Argentina	Tucumán	San Miguel de Tucumán	-26.8167000	-65.2167000	605767	2026-01-25 22:40:05.006669+00
1209	QA	Qatar	Ar Rayyān	Ar Rayyān	25.2500000	51.4000000	605712	2026-01-25 22:40:05.006669+00
1210	LV	Latvia	Rīga	Riga	56.9475000	24.1069000	605273	2026-01-25 22:40:05.006669+00
1211	US	United States	South Carolina	Columbia	34.0378000	-80.9036000	605083	2026-01-25 22:40:05.006669+00
1212	IN	India	Uttar Pradesh	Salīmpur	26.3000000	83.9167000	604483	2026-01-25 22:40:05.006669+00
1213	AO	Angola	Malanje	Malanje	-9.5333000	16.3500000	604215	2026-01-25 22:40:05.006669+00
1214	UA	Ukraine	Dnipropetrovska Oblast	Kryvyi Rih	47.9100000	33.3900000	603904	2026-01-25 22:40:05.006669+00
1215	DJ	Djibouti	Djibouti	Djibouti	11.5944000	43.1481000	603900	2026-01-25 22:40:05.006669+00
1216	CN	China	Hebei	Zhuozhou	39.4850000	115.9740000	603535	2026-01-25 22:40:05.006669+00
1217	CN	China	Anhui	Tianchang	32.6811000	119.0137000	602840	2026-01-25 22:40:05.006669+00
1218	US	United States	New York	Albany	42.6664000	-73.7987000	602242	2026-01-25 22:40:05.006669+00
1219	PH	Philippines	Bacolod	Bacolod	10.6765000	122.9509000	600783	2026-01-25 22:40:05.006669+00
1220	CM	Cameroon	Nord	Garoua	9.3000000	13.4000000	600000	2026-01-25 22:40:05.006669+00
1221	CM	Cameroon	North-West	Bamenda	5.9614000	10.1517000	600000	2026-01-25 22:40:05.006669+00
1222	CM	Cameroon	Ouest	Bafoussam	5.4667000	10.4167000	600000	2026-01-25 22:40:05.006669+00
1223	IL	Israel	Haifa	Haifa	32.8192000	34.9992000	600000	2026-01-25 22:40:05.006669+00
1224	IN	India	Odisha	Raurkela	22.2492000	84.8828000	600000	2026-01-25 22:40:05.006669+00
1225	TN	Tunisia	Tunis	Tunis	36.8064000	10.1817000	599368	2026-01-25 22:40:05.006669+00
1226	IN	India	Karnātaka	Tumkūr	13.3400000	77.1000000	599078	2026-01-25 22:40:05.006669+00
1227	ID	Indonesia	Kalimantan Timur	Balikpapan	-1.2768000	116.8277000	598043	2026-01-25 22:40:05.006669+00
1228	NG	Nigeria	Lagos	Somolu	6.5408000	3.3872000	597400	2026-01-25 22:40:05.006669+00
1229	TR	Turkey	Şanlıurfa	Şanlıurfa	37.1583000	38.7917000	596637	2026-01-25 22:40:05.006669+00
1230	DE	Germany	North Rhine-Westphalia	Dortmund	51.5139000	7.4653000	595471	2026-01-25 22:40:05.006669+00
1231	YE	Yemen	Ḩaḑramawt	Al Mukallā	14.5333000	49.1333000	594951	2026-01-25 22:40:05.006669+00
1232	CN	China	Hebei	Xinji	37.9430000	115.2180000	594628	2026-01-25 22:40:05.006669+00
1233	TR	Turkey	Kayseri	Melikgazi	38.7167000	35.5000000	594344	2026-01-25 22:40:05.006669+00
1234	JP	Japan	Kagoshima	Kagoshima	31.5969000	130.5572000	593754	2026-01-25 22:40:05.006669+00
1235	CN	China	Anhui	Wenchang	31.0358000	116.9367000	593629	2026-01-25 22:40:05.006669+00
1236	CN	China	Guangdong	Sihui	23.3265000	112.7338000	593400	2026-01-25 22:40:05.006669+00
1237	MX	Mexico	Guanajuato	Irapuato	20.6667000	-101.3500000	592953	2026-01-25 22:40:05.006669+00
1238	IE	Ireland	Dublin	Dublin	53.3497000	-6.2603000	592713	2026-01-25 22:40:05.006669+00
1239	EG	Egypt	Al Gharbīyah	Al Maḩallah al Kubrá	30.9667000	31.1667000	592573	2026-01-25 22:40:05.006669+00
1240	PK	Pakistan	Punjab	Sialkot City	32.4925000	74.5311000	591668	2026-01-25 22:40:05.006669+00
1241	RU	Russia	Primorskiy Kray	Vladivostok	43.1150000	131.8853000	591628	2026-01-25 22:40:05.006669+00
1242	CN	China	Sichuan	Luocheng	30.9900000	104.2500000	591115	2026-01-25 22:40:05.006669+00
1243	CO	Colombia	Risaralda	Pereira	4.8143000	-75.6946000	590554	2026-01-25 22:40:05.006669+00
1244	XG	Gaza Strip	\N	Gaza	31.5069000	34.4560000	590481	2026-01-25 22:40:05.006669+00
1245	MX	Mexico	Tamaulipas	Reynosa	26.0922000	-98.2778000	589466	2026-01-25 22:40:05.006669+00
1246	IR	Iran	Sīstān va Balūchestān	Zāhedān	29.5025000	60.8558000	587730	2026-01-25 22:40:05.006669+00
1247	DE	Germany	North Rhine-Westphalia	Essen	51.4508000	7.0131000	586608	2026-01-25 22:40:05.006669+00
1248	ID	Indonesia	Jawa Barat	Cimahi	-6.8712000	107.5548000	586580	2026-01-25 22:40:05.006669+00
1249	CN	China	Yunnan	Wenlan	23.3961000	103.3649000	585976	2026-01-25 22:40:05.006669+00
1250	JP	Japan	Tōkyō	Itabashi	35.7667000	139.6833000	584483	2026-01-25 22:40:05.006669+00
1251	MY	Malaysia	Selangor	Shah Alam	3.0667000	101.5500000	584340	2026-01-25 22:40:05.006669+00
1252	JP	Japan	Tōkyō	Suginami-ku	35.6994000	139.6364000	583609	2026-01-25 22:40:05.006669+00
1253	BR	Brazil	Pernambuco	Jaboatão dos Guararapes	-8.1128000	-35.0150000	581556	2026-01-25 22:40:05.006669+00
1254	LT	Lithuania	Vilniaus Miestas	Vilnius	54.6872000	25.2800000	581475	2026-01-25 22:40:05.006669+00
1255	JM	Jamaica	Kingston	Kingston	17.9714000	-76.7931000	580000	2026-01-25 22:40:05.006669+00
1256	JO	Jordan	Al Mafraq	Al Mafraq	32.3399000	36.2052000	580000	2026-01-25 22:40:05.006669+00
1257	SA	Saudi Arabia	Makkah al Mukarramah	Aţ Ţā’if	21.2667000	40.4167000	579970	2026-01-25 22:40:05.006669+00
1258	SD	Sudan	Red Sea	Port Sudan	19.6158000	37.2164000	579942	2026-01-25 22:40:05.006669+00
1259	VN	Vietnam	Khánh Hòa	Nha Trang	12.2450000	109.1917000	579000	2026-01-25 22:40:05.006669+00
1260	MX	Mexico	Chiapas	Tuxtla	16.7528000	-93.1167000	578830	2026-01-25 22:40:05.006669+00
1261	US	United States	California	Bakersfield	35.3529000	-119.0359000	578542	2026-01-25 22:40:05.006669+00
1262	IN	India	Uttarākhand	Dehra Dūn	30.3450000	78.0290000	578420	2026-01-25 22:40:05.006669+00
1263	DE	Germany	Bremen	Bremen	53.0758000	8.8072000	577026	2026-01-25 22:40:05.006669+00
1264	CN	China	Fujian	Fu’an	27.1000000	119.6333000	577000	2026-01-25 22:40:05.006669+00
1265	BD	Bangladesh	Mymensingh	Mymensingh	24.7504000	90.3800000	576927	2026-01-25 22:40:05.006669+00
1266	JP	Japan	Tōkyō	Hachiōji	35.6664000	139.3160000	575721	2026-01-25 22:40:05.006669+00
1267	PH	Philippines	Iloilo	Iloilo	10.7200000	122.5700000	574000	2026-01-25 22:40:05.006669+00
1268	CL	Chile	Región Metropolitana	Puente Alto	-33.6167000	-70.5667000	573935	2026-01-25 22:40:05.006669+00
1269	CN	China	Hebei	Botou	38.0833000	116.5833000	573842	2026-01-25 22:40:05.006669+00
1270	MA	Morocco	Rabat-Salé-Kénitra	Rabat	34.0209000	-6.8416000	572717	2026-01-25 22:40:05.006669+00
1271	TR	Turkey	Ankara	Sincan	39.9594000	32.5767000	572609	2026-01-25 22:40:05.006669+00
1272	CD	Congo (Kinshasa)	Lomami	Kabinda	-6.1300000	24.4800000	572000	2026-01-25 22:40:05.006669+00
1273	IN	India	Kerala	Kottayam	9.5916000	76.5222000	571856	2026-01-25 22:40:05.006669+00
1274	TR	Turkey	Kahramanmaraş	Kahramanmaraş	37.5833000	36.9333000	571266	2026-01-25 22:40:05.006669+00
1275	EG	Egypt	Al Qalyūbīyah	Shibīn al Qanāţir	30.3127000	31.3202000	570868	2026-01-25 22:40:05.006669+00
1276	MX	Mexico	Jalisco	Tonalá	20.6167000	-103.2333000	569913	2026-01-25 22:40:05.006669+00
1277	EG	Egypt	Al Buḩayrah	Abū Ḩummuş	31.0931000	30.3142000	569157	2026-01-25 22:40:05.006669+00
1278	JO	Jordan	Irbid	Irbid	32.5500000	35.8500000	569068	2026-01-25 22:40:05.006669+00
1279	CN	China	Sichuan	Jin’e	29.3394000	105.2875000	568900	2026-01-25 22:40:05.006669+00
1280	MO	Macau	\N	Macau	22.2006000	113.5461000	568700	2026-01-25 22:40:05.006669+00
1281	CN	China	Liaoning	Xinxing	39.8667000	124.1500000	568566	2026-01-25 22:40:05.006669+00
1282	CA	Canada	British Columbia	Surrey	49.1900000	-122.8489000	568322	2026-01-25 22:40:05.006669+00
1283	RU	Russia	Yaroslavskaya Oblast’	Yaroslavl	57.6167000	39.8500000	567443	2026-01-25 22:40:05.006669+00
1284	CN	China	Hunan	Qionghu	28.9450000	112.5980000	567159	2026-01-25 22:40:05.006669+00
1285	DE	Germany	Saxony	Dresden	51.0500000	13.7400000	566222	2026-01-25 22:40:05.006669+00
1286	CN	China	Liaoning	Xinmin	41.9970000	122.8230000	565634	2026-01-25 22:40:05.006669+00
1287	US	United States	Connecticut	New Haven	41.3113000	-72.9246000	565056	2026-01-25 22:40:05.006669+00
1288	BE	Belgium	Flanders	Antwerp	51.2178000	4.4003000	565039	2026-01-25 22:40:05.006669+00
1289	CN	China	Shandong	Kuiju	36.8667000	119.4000000	564501	2026-01-25 22:40:05.006669+00
1290	IN	India	West Bengal	Āsansol	23.6800000	86.9900000	563917	2026-01-25 22:40:05.006669+00
1291	IN	India	Jhārkhand	Bokaro Steel City	23.6700000	86.1500000	563417	2026-01-25 22:40:05.006669+00
1292	CN	China	Anhui	Jieshou	33.2570000	115.3746000	561956	2026-01-25 22:40:05.006669+00
1293	CO	Colombia	Antioquia	Bello	6.3333000	-75.5667000	561955	2026-01-25 22:40:05.006669+00
1294	IN	India	Mahārāshtra	Kolhāpur	16.6917000	74.2333000	561489	2026-01-25 22:40:05.006669+00
1295	CN	China	Hainan	Wencheng	19.6170000	110.7551000	560894	2026-01-25 22:40:05.006669+00
1296	CN	China	Hunan	Miluo Chengguanzhen	28.7610000	113.1600000	560725	2026-01-25 22:40:05.006669+00
1297	CN	China	Zhejiang	Lanxi	29.2080000	119.4580000	560514	2026-01-25 22:40:05.006669+00
1298	CN	China	Jiangsu	Zhenzhou	32.2723000	119.1848000	560258	2026-01-25 22:40:05.006669+00
1299	US	United States	Iowa	Des Moines	41.5725000	-93.6105000	560170	2026-01-25 22:40:05.006669+00
1300	IN	India	Chhattīsgarh	Nava Raipur	21.1610000	81.7870000	560000	2026-01-25 22:40:05.006669+00
1301	CN	China	Liaoning	Gaizhou	40.4000000	122.3500000	559271	2026-01-25 22:40:05.006669+00
1302	CN	China	Shandong	Leling	37.7300000	117.2320000	559166	2026-01-25 22:40:05.006669+00
1303	IT	Italy	Liguria	Genoa	44.4072000	8.9340000	558745	2026-01-25 22:40:05.006669+00
1304	MX	Mexico	Baja California	Ensenada	31.8578000	-116.6058000	557430	2026-01-25 22:40:05.006669+00
1305	AF	Afghanistan	Herāt	Herāt	34.3419000	62.2031000	556205	2026-01-25 22:40:05.006669+00
1306	NG	Nigeria	Akwa Ibom	Uyo	5.0333000	7.9275000	554906	2026-01-25 22:40:05.006669+00
1307	IR	Iran	Hamadān	Hamadān	34.8064000	48.5161000	554406	2026-01-25 22:40:05.006669+00
1308	PE	Peru	Lambayeque	Chiclayo	-6.7630000	-79.8366000	552508	2026-01-25 22:40:05.006669+00
1309	ID	Indonesia	Jawa Tengah	Surakarta	-7.5667000	110.8167000	552118	2026-01-25 22:40:05.006669+00
1310	IN	India	Rājasthān	Ajmer	26.4499000	74.6399000	551101	2026-01-25 22:40:05.006669+00
1311	DE	Germany	Lower Saxony	Braunschweig	52.2667000	10.5167000	551000	2026-01-25 22:40:05.006669+00
1312	IN	India	Mahārāshtra	Nānded	19.1500000	77.3000000	550439	2026-01-25 22:40:05.006669+00
1313	CN	China	Inner Mongolia	Wuhai	39.6550000	106.7940000	550000	2026-01-25 22:40:05.006669+00
1314	ES	Spain	Balearic Islands	Palma	39.5667000	2.6500000	550000	2026-01-25 22:40:05.006669+00
1315	ZA	South Africa	North West	Rustenburg	-25.6667000	27.2428000	549575	2026-01-25 22:40:05.006669+00
1316	IN	India	Mahārāshtra	Amrāvati	20.9258000	77.7647000	549370	2026-01-25 22:40:05.006669+00
1317	PT	Portugal	Lisboa	Lisbon	38.7122000	-9.1340000	548703	2026-01-25 22:40:05.006669+00
1318	CN	China	Jilin	Yanji	42.9000000	129.5000000	548700	2026-01-25 22:40:05.006669+00
1319	NL	Netherlands	Zuid-Holland	The Hague	52.0800000	4.3100000	548320	2026-01-25 22:40:05.006669+00
1320	DE	Germany	Lower Saxony	Hannover	52.3667000	9.7167000	548186	2026-01-25 22:40:05.006669+00
1321	UA	Ukraine	Sevastopol, Misto	Sevastopol	44.6050000	33.5225000	547820	2026-01-25 22:40:05.006669+00
1322	US	United States	Florida	Palm Bay	27.9631000	-80.6593000	547659	2026-01-25 22:40:05.006669+00
1323	GB	United Kingdom	Manchester	Manchester	53.4790000	-2.2452000	547627	2026-01-25 22:40:05.006669+00
1324	IN	India	Andhra Pradesh	Nellore	14.4431000	79.9861000	547621	2026-01-25 22:40:05.006669+00
1325	PL	Poland	Wielkopolskie	Poznań	52.4083000	16.9336000	546859	2026-01-25 22:40:05.006669+00
1326	CO	Colombia	Tolima	Ibagué	4.4333000	-75.2333000	546003	2026-01-25 22:40:05.006669+00
1327	CN	China	Hainan	Wancheng	18.8000000	110.4000000	545992	2026-01-25 22:40:05.006669+00
1328	RU	Russia	Tomskaya Oblast’	Tomsk	56.5000000	84.9667000	545391	2026-01-25 22:40:05.006669+00
1329	MY	Malaysia	Kedah	Sungai Petani	5.6497000	100.4793000	544851	2026-01-25 22:40:05.006669+00
1330	CN	China	Hubei	Xinshi	31.1333000	113.1167000	544843	2026-01-25 22:40:05.006669+00
1331	RU	Russia	Kemerovskaya Oblast’	Kemerovo	55.3667000	86.0667000	544600	2026-01-25 22:40:05.006669+00
1332	RU	Russia	Tatarstan	Naberezhnyye Chelny	55.6833000	52.3167000	544383	2026-01-25 22:40:05.006669+00
1333	CO	Colombia	Cesar	Valledupar	10.4833000	-73.2500000	544134	2026-01-25 22:40:05.006669+00
1334	PH	Philippines	Muntinlupa	Muntinlupa City	14.3800000	121.0500000	543445	2026-01-25 22:40:05.006669+00
1335	ET	Ethiopia	Sumalē	K’ebrī Beyah	9.0833000	43.0833000	543272	2026-01-25 22:40:05.006669+00
1336	CN	China	Shandong	Luofeng	37.3590000	120.3960000	543127	2026-01-25 22:40:05.006669+00
1337	CN	China	Xinjiang	Ghulja	43.9000000	81.3500000	542507	2026-01-25 22:40:05.006669+00
1338	MX	Mexico	México	Ixtapaluca	19.3186000	-98.8822000	542211	2026-01-25 22:40:05.006669+00
1339	CN	China	Fujian	Fuding	27.2000000	120.2000000	542000	2026-01-25 22:40:05.006669+00
1340	MX	Mexico	Tamaulipas	Heroica Matamoros	25.8797000	-97.5042000	541979	2026-01-25 22:40:05.006669+00
1341	TZ	Tanzania	Mbeya	Mbeya	-8.9000000	33.4500000	541603	2026-01-25 22:40:05.006669+00
1342	IQ	Iraq	Dhī Qār	An Nāşirīyah	31.0439000	46.2575000	541600	2026-01-25 22:40:05.006669+00
1343	IQ	Iraq	Bābil	Al Ḩillah	32.4833000	44.4333000	541034	2026-01-25 22:40:05.006669+00
1344	CN	China	Liaoning	Lingyuan	41.2500000	119.4000000	540832	2026-01-25 22:40:05.006669+00
1345	BR	Brazil	Minas Gerais	Juiz de Fora	-21.7642000	-43.3503000	540756	2026-01-25 22:40:05.006669+00
1346	CN	China	Jiangxi	Guixi	28.2925000	117.2454000	540572	2026-01-25 22:40:05.006669+00
1347	PH	Philippines	Laguna	City of Calamba	14.2200000	121.1700000	539671	2026-01-25 22:40:05.006669+00
1348	BR	Brazil	São Paulo	São José dos Campos	-23.1789000	-45.8869000	539313	2026-01-25 22:40:05.006669+00
1349	US	United States	Ohio	Akron	41.0798000	-81.5219000	538659	2026-01-25 22:40:05.006669+00
1350	SD	Sudan	West Darfur	El Geneina	13.4500000	22.4400000	538390	2026-01-25 22:40:05.006669+00
1351	BR	Brazil	Minas Gerais	Contagem	-19.9319000	-44.0539000	538017	2026-01-25 22:40:05.006669+00
1352	ES	Spain	Canary Islands	Santa Cruz	28.4667000	-16.2500000	538000	2026-01-25 22:40:05.006669+00
1353	MA	Morocco	Souss-Massa	Agadir	30.4214000	-9.5831000	538000	2026-01-25 22:40:05.006669+00
1354	RU	Russia	Orenburgskaya Oblast’	Orenburg	51.7833000	55.1000000	536862	2026-01-25 22:40:05.006669+00
1355	TR	Turkey	Bursa	Nilüfer	40.2833000	28.9500000	536365	2026-01-25 22:40:05.006669+00
1356	GB	United Kingdom	Leeds	Leeds	53.7975000	-1.5436000	536280	2026-01-25 22:40:05.006669+00
1357	SD	Sudan	Kassala	Kassala	15.4500000	36.4000000	536009	2026-01-25 22:40:05.006669+00
1358	CN	China	Xinjiang	Aksu	41.1850000	80.2904000	535657	2026-01-25 22:40:05.006669+00
1359	AR	Argentina	Salta	Salta	-24.7833000	-65.4167000	535303	2026-01-25 22:40:05.006669+00
1360	IN	India	Assam	Dispur	26.1397000	91.7925000	534872	2026-01-25 22:40:05.006669+00
1361	IN	India	Karnātaka	Gulbarga	17.3290000	76.8250000	533587	2026-01-25 22:40:05.006669+00
1362	UG	Uganda	Wakiso	Nansana	0.3639000	32.5286000	532800	2026-01-25 22:40:05.006669+00
1363	KR	Korea, South	Gyeongnam	Kimhae	35.2342000	128.8811000	531966	2026-01-25 22:40:05.006669+00
1364	RU	Russia	Kemerovskaya Oblast’	Novokuznetsk	53.7667000	87.1333000	531186	2026-01-25 22:40:05.006669+00
1365	MZ	Mozambique	Sofala	Beira	-19.8333000	34.8500000	530604	2026-01-25 22:40:05.006669+00
1366	RU	Russia	Moskovskaya Oblast’	Balashikha	55.8167000	37.9667000	530311	2026-01-25 22:40:05.006669+00
1367	IR	Iran	Yazd	Yazd	31.8822000	54.3397000	529673	2026-01-25 22:40:05.006669+00
1368	IR	Iran	Ardabīl	Ardabīl	38.2517000	48.2975000	529374	2026-01-25 22:40:05.006669+00
1369	SN	Senegal	Diourbel	Touba	14.8667000	-15.8833000	529176	2026-01-25 22:40:05.006669+00
1370	IN	India	Rājasthān	Bīkaner	28.0167000	73.3119000	529007	2026-01-25 22:40:05.006669+00
1371	CN	China	Hebei	Gaobeidian	39.3270000	115.8740000	528903	2026-01-25 22:40:05.006669+00
1372	GT	Guatemala	Guatemala	Mixco	14.6331000	-90.6064000	527828	2026-01-25 22:40:05.006669+00
1373	JP	Japan	Hyōgo	Himeji	34.8167000	134.6833000	527596	2026-01-25 22:40:05.006669+00
1374	IR	Iran	Hormozgān	Bandar ‘Abbās	27.1961000	56.2878000	526648	2026-01-25 22:40:05.006669+00
1375	DE	Germany	Bavaria	Nuremberg	49.4539000	11.0775000	526091	2026-01-25 22:40:05.006669+00
1376	US	United States	California	Concord	37.9722000	-122.0016000	525233	2026-01-25 22:40:05.006669+00
1377	TR	Turkey	Van	Van	38.4942000	43.3800000	525016	2026-01-25 22:40:05.006669+00
1378	EG	Egypt	Būr Sa‘īd	Port Said	31.2625000	32.3061000	524433	2026-01-25 22:40:05.006669+00
1379	JP	Japan	Tōkyō	Kōtō-ku	35.6667000	139.8167000	523419	2026-01-25 22:40:05.006669+00
1380	MX	Mexico	Nuevo León	Ciudad Apodaca	25.7817000	-100.1886000	523370	2026-01-25 22:40:05.006669+00
1381	CA	Canada	Ontario	Kitchener	43.4186000	-80.4728000	522888	2026-01-25 22:40:05.006669+00
1382	IN	India	Tripura	Agartala	23.8314000	91.2869000	522613	2026-01-25 22:40:05.006669+00
1383	CO	Colombia	Cundinamarca	Soacha	4.5872000	-74.2214000	522442	2026-01-25 22:40:05.006669+00
1384	TR	Turkey	İzmir	Buca	38.3500000	27.1667000	522404	2026-01-25 22:40:05.006669+00
1385	CL	Chile	Región Metropolitana	Maipú	-33.5167000	-70.7667000	521627	2026-01-25 22:40:05.006669+00
1386	IR	Iran	Markazī	Arāk	34.0914000	49.6933000	520944	2026-01-25 22:40:05.006669+00
1387	FR	France	Auvergne-Rhône-Alpes	Lyon	45.7600000	4.8400000	520774	2026-01-25 22:40:05.006669+00
1388	MX	Mexico	México	Tultitlán de Mariano Escobedo	19.6450000	-99.1694000	520557	2026-01-25 22:40:05.006669+00
1389	RU	Russia	Ryazanskaya Oblast’	Ryazan	54.6300000	39.7425000	520509	2026-01-25 22:40:05.006669+00
1390	MA	Morocco	Fès-Meknès	Meknès	33.8950000	-5.5547000	520428	2026-01-25 22:40:05.006669+00
1391	CN	China	Hebei	Luanzhou	39.7410000	118.7040000	520102	2026-01-25 22:40:05.006669+00
1392	EG	Egypt	Al Fayyūm	Al Fayyūm	29.3000000	30.8333000	519047	2026-01-25 22:40:05.006669+00
1393	JP	Japan	Tochigi	Utsunomiya	36.5550000	139.8825000	518197	2026-01-25 22:40:05.006669+00
1394	GB	United Kingdom	Sheffield	Sheffield	53.3808000	-1.4703000	518090	2026-01-25 22:40:05.006669+00
1395	IN	India	Mahārāshtra	Chānda	19.9500000	79.2970000	518000	2026-01-25 22:40:05.006669+00
1396	EG	Egypt	As Suways	Suez	29.9667000	32.5333000	516959	2026-01-25 22:40:05.006669+00
1397	CN	China	Guangdong	Heshan	22.7667000	112.9500000	516500	2026-01-25 22:40:05.006669+00
1398	IN	India	Uttar Pradesh	Loni	28.7500000	77.2800000	516082	2026-01-25 22:40:05.006669+00
1399	CN	China	Hainan	Jiaji	19.2431000	110.4642000	515700	2026-01-25 22:40:05.006669+00
1400	KZ	Kazakhstan	Qaraghandy	Qaraghandy	49.8028000	73.1056000	515632	2026-01-25 22:40:05.006669+00
1401	CO	Colombia	Magdalena	Santa Marta	11.2419000	-74.2053000	515556	2026-01-25 22:40:05.006669+00
1402	IN	India	Madhya Pradesh	Ujjain	23.1700000	75.7900000	515215	2026-01-25 22:40:05.006669+00
1403	EG	Egypt	Qinā	Abū Ţisht	26.1204000	32.0954000	514535	2026-01-25 22:40:05.006669+00
1404	UZ	Uzbekistan	Samarqand	Samarkand	39.6547000	66.9758000	513572	2026-01-25 22:40:05.006669+00
1405	GB	United Kingdom	Liverpool	Liverpool	53.4072000	-2.9917000	513441	2026-01-25 22:40:05.006669+00
1406	BR	Brazil	Amapá	Macapá	0.0330000	-51.0500000	512902	2026-01-25 22:40:05.006669+00
1407	AO	Angola	Benguela	Benguela	-12.5500000	13.4167000	512886	2026-01-25 22:40:05.006669+00
1408	AO	Angola	Bié	Cuito	-12.3833000	16.9333000	512706	2026-01-25 22:40:05.006669+00
1409	EG	Egypt	Banī Suwayf	Al Fashn	28.8231000	30.8990000	512242	2026-01-25 22:40:05.006669+00
1410	FR	France	Occitanie	Toulouse	43.6045000	1.4440000	511684	2026-01-25 22:40:05.006669+00
1411	IQ	Iraq	Maysān	Al ‘Amārah	31.8333000	47.1500000	511500	2026-01-25 22:40:05.006669+00
1412	HT	Haiti	Ouest	Carrefour	18.5333000	-72.4000000	511345	2026-01-25 22:40:05.006669+00
1413	BR	Brazil	Rio de Janeiro	Campos	-21.7523000	-41.3304000	511168	2026-01-25 22:40:05.006669+00
1414	SO	Somalia	Galguduud	Cadaado	6.1393000	46.6241000	510654	2026-01-25 22:40:05.006669+00
1415	CN	China	Jilin	Meihekou	42.5407000	125.7107000	509336	2026-01-25 22:40:05.006669+00
1416	MA	Morocco	Rabat-Salé-Kénitra	Kenitra	34.2500000	-6.5833000	507736	2026-01-25 22:40:05.006669+00
1417	ZA	South Africa	KwaZulu-Natal	Newcastle	-27.7464000	29.9328000	507710	2026-01-25 22:40:05.006669+00
1418	US	United States	Arizona	Mesa	33.4015000	-111.7178000	507478	2026-01-25 22:40:05.006669+00
1419	IN	India	Uttar Pradesh	Jhānsi	25.4486000	78.5696000	507000	2026-01-25 22:40:05.006669+00
1420	JP	Japan	Ehime	Matsuyama	33.8333000	132.7667000	506743	2026-01-25 22:40:05.006669+00
1421	IN	India	Mahārāshtra	Ulhāsnagar	19.2200000	73.1500000	506098	2026-01-25 22:40:05.006669+00
1422	BR	Brazil	São Paulo	Ribeirão Prêto	-21.1776000	-47.8101000	504923	2026-01-25 22:40:05.006669+00
1423	KR	Korea, South	Gyeongbuk	Pohang	36.0322000	129.3650000	503780	2026-01-25 22:40:05.006669+00
1424	DE	Germany	North Rhine-Westphalia	Duisburg	51.4347000	6.7625000	503707	2026-01-25 22:40:05.006669+00
1425	IN	India	Jammu and Kashmīr	Jammu	32.7300000	74.8700000	502197	2026-01-25 22:40:05.006669+00
1426	NG	Nigeria	Osun	Ile-Ife	7.4833000	4.5592000	501952	2026-01-25 22:40:05.006669+00
1427	US	United States	Kansas	Wichita	37.6895000	-97.3443000	501760	2026-01-25 22:40:05.006669+00
1428	MX	Mexico	Sinaloa	Mazatlán	23.2167000	-106.4167000	501441	2026-01-25 22:40:05.006669+00
1429	BR	Brazil	Minas Gerais	Uberlândia	-18.9189000	-48.2769000	501214	2026-01-25 22:40:05.006669+00
1430	BY	Belarus	Homyel’skaya Voblasts’	Homyel’	52.4453000	30.9842000	501102	2026-01-25 22:40:05.006669+00
1431	AF	Afghanistan	Farāh	Farāh	32.3436000	62.1194000	500000	2026-01-25 22:40:05.006669+00
1432	AO	Angola	Luanda	Belas	-8.9983000	13.2650000	500000	2026-01-25 22:40:05.006669+00
1433	AO	Angola	Luanda	Talatona	-8.9167000	13.1833000	500000	2026-01-25 22:40:05.006669+00
1434	CN	China	Heilongjiang	Nenjiang	49.1100000	125.1300000	500000	2026-01-25 22:40:05.006669+00
1435	IN	India	Tamil Nādu	Tuticorin	8.8056000	78.1450000	500000	2026-01-25 22:40:05.006669+00
1436	NG	Nigeria	Delta	Asaba	6.1833000	6.7333000	500000	2026-01-25 22:40:05.006669+00
1437	SD	Sudan	North Darfur	El Fasher	13.6300000	25.3500000	500000	2026-01-25 22:40:05.006669+00
1438	PK	Pakistan	Sindh	Sukkur	27.7061000	68.8483000	499900	2026-01-25 22:40:05.006669+00
1439	ET	Ethiopia	Sumalē	K’ebrī Dehar	6.7333000	44.2667000	499500	2026-01-25 22:40:05.006669+00
1440	US	United States	Pennsylvania	Harrisburg	40.2752000	-76.8843000	499494	2026-01-25 22:40:05.006669+00
1441	CN	China	Anhui	Taozhou	30.8956000	119.4110000	499132	2026-01-25 22:40:05.006669+00
1442	CN	China	Hubei	Anlu	31.2667000	113.6667000	498356	2026-01-25 22:40:05.006669+00
1443	PH	Philippines	Lapu-Lapu	Lapu-Lapu City	10.3127000	123.9488000	497604	2026-01-25 22:40:05.006669+00
1444	JP	Japan	Chiba	Matsudo	35.7876000	139.9032000	497514	2026-01-25 22:40:05.006669+00
1445	MY	Malaysia	Johor	Johor Bahru	1.4820000	103.7281000	497097	2026-01-25 22:40:05.006669+00
1446	IN	India	Bihār	Purnea	25.7780000	87.4760000	496830	2026-01-25 22:40:05.006669+00
1447	PH	Philippines	Cavite	Imus	14.4297000	120.9367000	496794	2026-01-25 22:40:05.006669+00
1448	BR	Brazil	Rio de Janeiro	Niterói	-22.8833000	-43.1036000	496696	2026-01-25 22:40:05.006669+00
1449	RU	Russia	Lipetskaya Oblast’	Lipetsk	52.6167000	39.6000000	496403	2026-01-25 22:40:05.006669+00
1450	RU	Russia	Chuvashiya	Cheboksary	56.1500000	47.2333000	496350	2026-01-25 22:40:05.006669+00
1451	US	United States	New York	Staten Island	40.5834000	-74.1496000	495747	2026-01-25 22:40:05.006669+00
1452	CD	Congo (Kinshasa)	Haut-Katanga	Likasi	-10.9833000	26.7333000	495000	2026-01-25 22:40:05.006669+00
1453	CN	China	Shaanxi	Xiangyang	34.2995000	108.4905000	494887	2026-01-25 22:40:05.006669+00
1454	CN	China	Zhejiang	Jiangshan	28.7361000	118.6250000	494412	2026-01-25 22:40:05.006669+00
1455	CN	China	Guizhou	Duyun	26.2594000	107.5186000	493574	2026-01-25 22:40:05.006669+00
1456	PK	Pakistan	Punjab	Pindi Bhattian	31.8958000	73.2761000	493222	2026-01-25 22:40:05.006669+00
1457	SD	Sudan	South Darfur	Nyala	12.0500000	24.8833000	492984	2026-01-25 22:40:05.006669+00
1458	JP	Japan	Chiba	Ichikawa	35.7219000	139.9311000	492749	2026-01-25 22:40:05.006669+00
1459	GT	Guatemala	Guatemala	Villa Nueva	14.5269000	-90.5875000	492480	2026-01-25 22:40:05.006669+00
1460	CN	China	Xinjiang	Kumul	42.8193000	93.5151000	492096	2026-01-25 22:40:05.006669+00
1461	US	United States	Ohio	Toledo	41.6638000	-83.5827000	492076	2026-01-25 22:40:05.006669+00
1462	GW	Guinea-Bissau	Bissau	Bissau	11.8500000	-15.5667000	492004	2026-01-25 22:40:05.006669+00
1463	GH	Ghana	Greater Accra	Accra	5.5461000	-0.2067000	491817	2026-01-25 22:40:05.006669+00
1464	MY	Malaysia	Kelantan	Kota Bharu	6.1200000	102.2300000	491237	2026-01-25 22:40:05.006669+00
1465	JP	Japan	Ōsaka	Higashi-ōsaka	34.6794000	135.6008000	490819	2026-01-25 22:40:05.006669+00
1466	PK	Pakistan	Sindh	Larkana	27.5583000	68.2111000	490508	2026-01-25 22:40:05.006669+00
1467	CN	China	Liaoning	Xingcheng	40.6167000	120.7333000	490300	2026-01-25 22:40:05.006669+00
1468	AE	United Arab Emirates	‘Ajmān	‘Ajmān	25.4136000	55.4456000	490035	2026-01-25 22:40:05.006669+00
1469	MX	Mexico	México	Ciudad López Mateos	19.5500000	-99.2833000	489937	2026-01-25 22:40:05.006669+00
1470	RU	Russia	Kaliningradskaya Oblast’	Kaliningrad	54.7003000	20.4531000	489584	2026-01-25 22:40:05.006669+00
1471	CN	China	Zhejiang	Yueqing	28.1200000	120.9600000	488980	2026-01-25 22:40:05.006669+00
1472	RU	Russia	Penzenskaya Oblast’	Penza	53.2000000	45.0000000	488299	2026-01-25 22:40:05.006669+00
1473	IN	India	Karnātaka	Belgaum	15.8500000	74.5000000	488157	2026-01-25 22:40:05.006669+00
1474	GB	United Kingdom	Edinburgh, City of	Edinburgh	55.9500000	-3.1833000	488050	2026-01-25 22:40:05.006669+00
1475	CN	China	Shandong	Yucheng	36.9340000	116.6380000	488014	2026-01-25 22:40:05.006669+00
1476	US	United States	New York	Brookhaven	40.8320000	-72.9517000	487817	2026-01-25 22:40:05.006669+00
1477	US	United States	Massachusetts	Worcester	42.2705000	-71.8079000	487014	2026-01-25 22:40:05.006669+00
1478	JP	Japan	Hyōgo	Nishinomiya-hama	34.7376000	135.3416000	487010	2026-01-25 22:40:05.006669+00
1479	CN	China	Xinjiang	Karamay	45.5799000	84.8892000	487000	2026-01-25 22:40:05.006669+00
1480	JP	Japan	Ōsaka	Kawachichō	34.6794000	135.6008000	486464	2026-01-25 22:40:05.006669+00
1481	CN	China	Jiangxi	Zhangshu	28.0546000	115.5462000	485649	2026-01-25 22:40:05.006669+00
1482	CN	China	Anhui	Mingguang	32.7833000	117.9667000	485627	2026-01-25 22:40:05.006669+00
1483	TR	Turkey	Malatya	Malatya	38.3486000	38.3194000	485484	2026-01-25 22:40:05.006669+00
1484	SO	Somalia	Nugaal	Garoowe	8.4000000	48.4833000	485000	2026-01-25 22:40:05.006669+00
1485	IN	India	Tamil Nādu	Vellore	12.9165000	79.1325000	484690	2026-01-25 22:40:05.006669+00
1486	CN	China	Hebei	Huanghua	38.3720000	117.3300000	484313	2026-01-25 22:40:05.006669+00
1487	CN	China	Guangdong	Encheng	22.1833000	112.3000000	483907	2026-01-25 22:40:05.006669+00
1488	CN	China	Yunnan	Lianran	24.9190000	102.4780000	483753	2026-01-25 22:40:05.006669+00
1489	TR	Turkey	İstanbul	Kartal	40.8872000	29.1900000	483418	2026-01-25 22:40:05.006669+00
1490	BR	Brazil	Mato Grosso	Cuiabá	-15.5958000	-56.0969000	483346	2026-01-25 22:40:05.006669+00
1491	EG	Egypt	Sūhāj	Akhmīm	26.5667000	31.7500000	482666	2026-01-25 22:40:05.006669+00
1492	JO	Jordan	Az Zarqā’	Az Zarqā’	32.0833000	36.1000000	481300	2026-01-25 22:40:05.006669+00
1493	IN	India	Mahārāshtra	Mālegaon	20.5500000	74.5500000	481228	2026-01-25 22:40:05.006669+00
1494	BR	Brazil	Bahia	Feira de Santana	-12.2669000	-38.9669000	480949	2026-01-25 22:40:05.006669+00
1495	CN	China	Heilongjiang	Hailun	47.4667000	126.9667000	480216	2026-01-25 22:40:05.006669+00
1496	MT	Malta	Valletta	Valletta	35.8983000	14.5125000	480134	2026-01-25 22:40:05.006669+00
1497	CD	Congo (Kinshasa)	Lualaba	Kolwezi	-10.7167000	25.4667000	480000	2026-01-25 22:40:05.006669+00
1498	IN	India	Gujarāt	Jāmnagar	22.4700000	70.0700000	479920	2026-01-25 22:40:05.006669+00
1499	BD	Bangladesh	Sylhet	Sylhet	24.9000000	91.8667000	479837	2026-01-25 22:40:05.006669+00
1500	BR	Brazil	Pará	Ananindeua	-1.3658000	-48.3719000	478778	2026-01-25 22:40:05.006669+00
1501	SO	Somalia	Woqooyi Galbeed	Berbera	10.4396000	45.0143000	478000	2026-01-25 22:40:05.006669+00
1502	PK	Pakistan	Punjab	Chiniot	31.7194000	72.9842000	477781	2026-01-25 22:40:05.006669+00
1503	PY	Paraguay	Asunción	Asunción	-25.2945000	-57.6435000	477346	2026-01-25 22:40:05.006669+00
1504	CN	China	Henan	Chengjiao	35.3984000	114.0649000	476867	2026-01-25 22:40:05.006669+00
1505	IN	India	Gujarāt	Bārdoli	21.1200000	73.1200000	475963	2026-01-25 22:40:05.006669+00
1506	SK	Slovakia	Bratislava	Bratislava	48.1447000	17.1128000	475503	2026-01-25 22:40:05.006669+00
1507	JP	Japan	Okayama	Kurashiki	34.5850000	133.7722000	474862	2026-01-25 22:40:05.006669+00
1508	JP	Japan	Ōita	Ōita	33.2333000	131.6067000	474804	2026-01-25 22:40:05.006669+00
1509	SA	Saudi Arabia	Ash Sharqīyah	Al Jubayl	27.0046000	49.6460000	474679	2026-01-25 22:40:05.006669+00
1510	GB	United Kingdom	West Sussex	Worthing	50.8147000	-0.3714000	474485	2026-01-25 22:40:05.006669+00
1511	IN	India	Bihār	Gaya	24.7500000	85.0100000	474093	2026-01-25 22:40:05.006669+00
1512	US	United States	Florida	Port St. Lucie	27.2796000	-80.3884000	473733	2026-01-25 22:40:05.006669+00
1513	CN	China	Hubei	Xiulin	29.7209000	112.4254000	473707	2026-01-25 22:40:05.006669+00
1514	PK	Pakistan	Punjab	Shekhupura	31.7111000	73.9878000	473129	2026-01-25 22:40:05.006669+00
1515	PE	Peru	Piura	Piura	-5.2000000	-80.6333000	473025	2026-01-25 22:40:05.006669+00
1516	BR	Brazil	Espírito Santo	Vila Velha	-20.3364000	-40.2936000	472762	2026-01-25 22:40:05.006669+00
1517	JO	Jordan	Az Zarqā’	Ar Ruşayfah	32.0178000	36.0464000	472604	2026-01-25 22:40:05.006669+00
1518	RU	Russia	Kirovskaya Oblast’	Kirov	58.6000000	49.6833000	471754	2026-01-25 22:40:05.006669+00
1519	TZ	Tanzania	Morogoro	Morogoro	-6.8242000	37.6633000	471409	2026-01-25 22:40:05.006669+00
1520	AR	Argentina	San Juan	San Juan	-31.5342000	-68.5261000	471389	2026-01-25 22:40:05.006669+00
1521	UA	Ukraine	Mykolaivska Oblast	Mykolaiv	46.9750000	31.9950000	470011	2026-01-25 22:40:05.006669+00
1522	CN	China	Hubei	Yicheng	31.7210000	112.2570000	469417	2026-01-25 22:40:05.006669+00
1523	CN	China	Liaoning	Fengcheng	40.4500000	124.0667000	469376	2026-01-25 22:40:05.006669+00
1524	AF	Afghanistan	Balkh	Mazār-e Sharīf	36.7000000	67.1167000	469247	2026-01-25 22:40:05.006669+00
1525	CN	China	Shanxi	Xiaoyi	36.0833000	111.5167000	468770	2026-01-25 22:40:05.006669+00
1526	IQ	Iraq	Diyālá	Ba‘qūbah	33.7447000	44.6436000	467900	2026-01-25 22:40:05.006669+00
1527	ZA	South Africa	Gauteng	Katlehong	-26.3333000	28.1500000	467890	2026-01-25 22:40:05.006669+00
1528	IL	Israel	Tel Aviv	Tel Aviv-Yafo	32.0800000	34.7800000	467875	2026-01-25 22:40:05.006669+00
1529	CN	China	Zhejiang	Jiangshandicun	28.7412000	118.6225000	467862	2026-01-25 22:40:05.006669+00
1530	US	United States	Arkansas	Little Rock	34.7256000	-92.3577000	467846	2026-01-25 22:40:05.006669+00
1531	CN	China	Guizhou	Qingzhen	26.5704000	106.4687000	467438	2026-01-25 22:40:05.006669+00
1532	SA	Saudi Arabia	Al Qaşīm	Buraydah	26.3664000	43.9628000	467410	2026-01-25 22:40:05.006669+00
1533	ID	Indonesia	Nusa Tenggara Timur	Kupang	-10.1702000	123.6077000	466632	2026-01-25 22:40:05.006669+00
1534	RU	Russia	Tul’skaya Oblast’	Tula	54.2000000	37.6167000	466609	2026-01-25 22:40:05.006669+00
1535	IN	India	Tamil Nādu	Ambattūr	13.1143000	80.1548000	466205	2026-01-25 22:40:05.006669+00
1536	TH	Thailand	Nakhon Ratchasima	Nakhon Ratchasima	14.9806000	102.1000000	466098	2026-01-25 22:40:05.006669+00
1537	VN	Vietnam	Bình Dương	Tân Uyên	11.0508000	106.7636000	466053	2026-01-25 22:40:05.006669+00
1538	RU	Russia	Astrakhanskaya Oblast’	Astrakhan	46.3500000	48.0350000	465524	2026-01-25 22:40:05.006669+00
1539	CN	China	Zhejiang	Longjiang	27.5819000	120.5489000	464695	2026-01-25 22:40:05.006669+00
1540	GB	United Kingdom	Leicester	Leicester	52.6361000	-1.1331000	464395	2026-01-25 22:40:05.006669+00
1541	CN	China	Shandong	Rushan	36.8700000	121.5050000	464078	2026-01-25 22:40:05.006669+00
1542	CN	China	Heilongjiang	Shangzhi	45.2070000	127.9650000	463358	2026-01-25 22:40:05.006669+00
1543	PH	Philippines	Angeles	Angeles City	15.1472000	120.5847000	462928	2026-01-25 22:40:05.006669+00
1544	CN	China	Xinjiang	Kuqa	41.7156000	82.9322000	462588	2026-01-25 22:40:05.006669+00
1545	JP	Japan	Ishikawa	Kanazawa	36.5611000	136.6564000	462479	2026-01-25 22:40:05.006669+00
1546	ID	Indonesia	Sulawesi Utara	Manado Light	1.4858000	124.8347000	461636	2026-01-25 22:40:05.006669+00
1547	ID	Indonesia	Sulawesi Utara	Manado	1.4931000	124.8413000	461636	2026-01-25 22:40:05.006669+00
1548	CN	China	Liaoning	Kaiyuan	42.5460000	124.0380000	460927	2026-01-25 22:40:05.006669+00
1549	AU	Australia	Victoria	Cranbourne	-38.0996000	145.2834000	460491	2026-01-25 22:40:05.006669+00
1550	IN	India	Mahārāshtra	Jalgaon	21.0040000	75.5680000	460468	2026-01-25 22:40:05.006669+00
1551	US	United States	Wisconsin	Madison	43.0822000	-89.3930000	460255	2026-01-25 22:40:05.006669+00
1552	IN	India	Madhya Pradesh	Chhatarpur	24.5500000	79.3527000	459943	2026-01-25 22:40:05.006669+00
1553	JP	Japan	Hiroshima	Fukuyama	34.4858000	133.3622000	459576	2026-01-25 22:40:05.006669+00
1554	SS	South Sudan	Central Equatoria	Juba	4.8300000	31.5800000	459342	2026-01-25 22:40:05.006669+00
1555	AR	Argentina	Buenos Aires	Lanús	-34.7000000	-58.4000000	459263	2026-01-25 22:40:05.006669+00
1556	US	United States	Washington	Spokane	47.6671000	-117.4330000	458988	2026-01-25 22:40:05.006669+00
1557	YE	Yemen	Ta‘izz	Ta‘izz	13.5789000	44.0219000	458789	2026-01-25 22:40:05.006669+00
1558	US	United States	California	Long Beach	33.7977000	-118.1670000	458491	2026-01-25 22:40:05.006669+00
1559	CD	Congo (Kinshasa)	Kwilu	Kikwit	-5.0386000	18.8181000	458000	2026-01-25 22:40:05.006669+00
1560	KR	Korea, South	Gyeonggi	Pyeongtaek	36.9922000	127.1128000	457873	2026-01-25 22:40:05.006669+00
1561	IN	India	Andhra Pradesh	Kurnool	15.8300000	78.0500000	457633	2026-01-25 22:40:05.006669+00
1562	PH	Philippines	Marikina	Marikina City	14.6500000	121.1000000	456059	2026-01-25 22:40:05.006669+00
1563	TR	Turkey	İstanbul	Kâğıthane	41.0719000	28.9664000	455943	2026-01-25 22:40:05.006669+00
1564	JP	Japan	Hyōgo	Amagasaki	34.7333000	135.4000000	455555	2026-01-25 22:40:05.006669+00
1565	MY	Malaysia	Melaka	Melaka	2.2064000	102.2465000	455300	2026-01-25 22:40:05.006669+00
1566	US	United States	Texas	Denton	33.2175000	-97.1418000	455152	2026-01-25 22:40:05.006669+00
1567	MX	Mexico	Nuevo León	Ciudad General Escobedo	25.7933000	-100.1583000	454967	2026-01-25 22:40:05.006669+00
1568	US	United States	Nevada	Reno	39.5497000	-119.8483000	454814	2026-01-25 22:40:05.006669+00
1569	CO	Colombia	Caldas	Manizales	5.0675000	-75.5100000	454494	2026-01-25 22:40:05.006669+00
1570	TR	Turkey	İzmir	Bornova	38.4697000	27.2211000	454470	2026-01-25 22:40:05.006669+00
1571	VE	Venezuela	Anzoátegui	Puerto La Cruz	10.2000000	-64.6333000	454312	2026-01-25 22:40:05.006669+00
1572	TZ	Tanzania	Shinyanga	Kahama	-3.8375000	32.6000000	453654	2026-01-25 22:40:05.006669+00
1573	TW	Taiwan	Hsinchu	Hsinchu	24.8167000	120.9833000	453536	2026-01-25 22:40:05.006669+00
1574	CN	China	Shanxi	Gaoping	35.7980000	112.9240000	453054	2026-01-25 22:40:05.006669+00
1575	TR	Turkey	Batman	Batman	37.8870000	41.1320000	452157	2026-01-25 22:40:05.006669+00
1576	TR	Turkey	Batman	Demiryol	37.8870000	41.1320000	452157	2026-01-25 22:40:05.006669+00
1577	TR	Turkey	Batman	Erköklü	37.8870000	41.1320000	452157	2026-01-25 22:40:05.006669+00
1578	TR	Turkey	İstanbul	Avcılar	40.9792000	28.7214000	452132	2026-01-25 22:40:05.006669+00
1579	MY	Malaysia	Sabah	Kota Kinabalu	5.9800000	116.1100000	452058	2026-01-25 22:40:05.006669+00
1580	JP	Japan	Tōkyō	Katsushika-ku	35.7333000	139.8500000	451772	2026-01-25 22:40:05.006669+00
1581	IN	India	Rājasthān	Udaipur	24.5800000	73.6800000	451100	2026-01-25 22:40:05.006669+00
1582	BR	Brazil	São Paulo	Mogi das Cruzes	-23.5228000	-46.1931000	450785	2026-01-25 22:40:05.006669+00
1583	RU	Russia	Stavropol’skiy Kray	Stavropol	45.0500000	41.9833000	450680	2026-01-25 22:40:05.006669+00
1584	PH	Philippines	Cavite	General Trias	14.3800000	120.8800000	450583	2026-01-25 22:40:05.006669+00
1585	ET	Ethiopia	Sumalē	Warder	6.9667000	45.3500000	450400	2026-01-25 22:40:05.006669+00
1586	BD	Bangladesh	Rājshāhi	Sirājganj	24.4500000	89.7167000	450000	2026-01-25 22:40:05.006669+00
1587	IN	India	\N	Wāpi	20.3720000	72.9170000	450000	2026-01-25 22:40:05.006669+00
1588	VN	Vietnam	Bắc Giang	Bắc Giang	21.2667000	106.2000000	450000	2026-01-25 22:40:05.006669+00
1589	US	United States	Idaho	Boise	43.6005000	-116.2308000	449428	2026-01-25 22:40:05.006669+00
1590	CH	Switzerland	Zürich	Zürich	47.3744000	8.5411000	448664	2026-01-25 22:40:05.006669+00
1591	DZ	Algeria	Constantine	Constantine	36.3500000	6.6000000	448374	2026-01-25 22:40:05.006669+00
1592	VN	Vietnam	Nam Định	Nam Định	20.4200000	106.1683000	448225	2026-01-25 22:40:05.006669+00
1593	IR	Iran	Tehrān	Eslāmshahr	35.5386000	51.2228000	448129	2026-01-25 22:40:05.006669+00
1594	BD	Bangladesh	Rājshāhi	Rājshāhi	24.3667000	88.6000000	448087	2026-01-25 22:40:05.006669+00
1595	GR	Greece	Attikí	Piraeus	37.9430000	23.6469000	448051	2026-01-25 22:40:05.006669+00
1596	CD	Congo (Kinshasa)	Kongo Central	Matadi	-5.8167000	13.4833000	448000	2026-01-25 22:40:05.006669+00
1597	ZA	South Africa	Limpopo	Zebediela	-24.3100000	29.2700000	448000	2026-01-25 22:40:05.006669+00
1598	PK	Pakistan	Sindh	Shah Latif Town	24.8806000	67.1625000	447993	2026-01-25 22:40:05.006669+00
1599	CN	China	Henan	Tanbei	35.0880000	112.9510000	447487	2026-01-25 22:40:05.006669+00
1600	BR	Brazil	Paraná	Londrina	-23.3100000	-51.1628000	447065	2026-01-25 22:40:05.006669+00
1601	NG	Nigeria	Ekiti	Ado-Ekiti	7.6211000	5.2214000	446749	2026-01-25 22:40:05.006669+00
1602	US	United States	Florida	Bonita Springs	26.3558000	-81.7859000	445500	2026-01-25 22:40:05.006669+00
1603	TR	Turkey	İstanbul	Esenler	41.0339000	28.8903000	445421	2026-01-25 22:40:05.006669+00
1604	RU	Russia	Krasnodarskiy Kray	Sochi	43.5853000	39.7203000	444989	2026-01-25 22:40:05.006669+00
1605	CU	Cuba	Santiago de Cuba	Santiago de Cuba	20.0217000	-75.8294000	444851	2026-01-25 22:40:05.006669+00
1606	PH	Philippines	Rizal	Rodriguez	14.7200000	121.1200000	443954	2026-01-25 22:40:05.006669+00
1607	BD	Bangladesh	Chattogram	Chauddagram	23.2244000	91.3731000	443648	2026-01-25 22:40:05.006669+00
1608	MX	Mexico	Nuevo León	San Nicolás de los Garza	25.7500000	-100.2833000	443273	2026-01-25 22:40:05.006669+00
1609	TW	Taiwan	Taoyuan	Taoyuan District	24.9913000	121.3143000	443273	2026-01-25 22:40:05.006669+00
1610	US	United States	Florida	Kissimmee	28.3041000	-81.4169000	442790	2026-01-25 22:40:05.006669+00
1611	CN	China	Zhejiang	Baisha	29.4896000	119.3370000	442709	2026-01-25 22:40:05.006669+00
1612	CD	Congo (Kinshasa)	Kinshasa	Ndjili	-4.4089000	15.3775000	442138	2026-01-25 22:40:05.006669+00
1613	IN	India	Uttar Pradesh	Mathura	27.4925000	77.6736000	441894	2026-01-25 22:40:05.006669+00
1614	CN	China	Anhui	Meicheng	30.6310000	116.5810000	441224	2026-01-25 22:40:05.006669+00
1615	ID	Indonesia	Nusa Tenggara Barat	Lembok	-8.5650000	116.3510000	441147	2026-01-25 22:40:05.006669+00
1616	CI	Côte d’Ivoire	Savanes	Korhogo	9.4578000	-5.6294000	440926	2026-01-25 22:40:05.006669+00
1617	PH	Philippines	Pasay	Pasay City	14.5439000	120.9950000	440656	2026-01-25 22:40:05.006669+00
1618	CN	China	Liaoning	Beipiao	41.8010000	120.7710000	439998	2026-01-25 22:40:05.006669+00
1619	CN	China	Sichuan	Jiannan	31.3333000	104.2000000	439958	2026-01-25 22:40:05.006669+00
1620	CA	Canada	Nova Scotia	Halifax	44.6475000	-63.5906000	439819	2026-01-25 22:40:05.006669+00
1621	JP	Japan	Kanagawa	Fujisawa	35.3500000	139.4667000	439728	2026-01-25 22:40:05.006669+00
1622	US	United States	Georgia	Augusta	33.3645000	-82.0708000	439361	2026-01-25 22:40:05.006669+00
1623	RU	Russia	Buryatiya	Ulan-Ude	51.8333000	107.6000000	439128	2026-01-25 22:40:05.006669+00
1624	US	United States	Massachusetts	Springfield	42.1155000	-72.5395000	438889	2026-01-25 22:40:05.006669+00
1625	CA	Canada	Quebec	Laval	45.5833000	-73.7500000	438366	2026-01-25 22:40:05.006669+00
1626	US	United States	California	Oakland	37.7904000	-122.2166000	438072	2026-01-25 22:40:05.006669+00
1627	CN	China	Gansu	Jinchang	38.5214000	102.1880000	438026	2026-01-25 22:40:05.006669+00
1628	KP	Korea, North	P’yŏngnam	Sunch’ŏn	39.4167000	125.9333000	437000	2026-01-25 22:40:05.006669+00
1629	CN	China	Heilongjiang	Nehe	48.4833000	124.8833000	436906	2026-01-25 22:40:05.006669+00
1630	RU	Russia	Kurskaya Oblast’	Kursk	51.7167000	36.1833000	436678	2026-01-25 22:40:05.006669+00
1631	IN	India	Mahārāshtra	Sāngli	16.8530000	74.5830000	436639	2026-01-25 22:40:05.006669+00
1632	AO	Angola	Benguela	Lobito	-12.3500000	13.5464000	436467	2026-01-25 22:40:05.006669+00
1633	KR	Korea, South	Jeju	Jeju	33.5130000	126.5230000	435413	2026-01-25 22:40:05.006669+00
1634	CN	China	Shandong	Zhuangyuan	37.3056000	120.8290000	435405	2026-01-25 22:40:05.006669+00
1635	IN	India	Karnātaka	Davangere	14.4666000	75.9242000	435125	2026-01-25 22:40:05.006669+00
1636	CN	China	Fujian	Jian’ou	27.0333000	118.3167000	434451	2026-01-25 22:40:05.006669+00
1637	JP	Japan	Tōkyō	Machida	35.5542000	139.4431000	434414	2026-01-25 22:40:05.006669+00
1638	US	United States	North Carolina	Winston-Salem	36.1029000	-80.2610000	434231	2026-01-25 22:40:05.006669+00
1639	PK	Pakistan	Sindh	Sanghar	26.0442000	68.9536000	434087	2026-01-25 22:40:05.006669+00
1640	CN	China	Hunan	Chang’an	29.4768000	113.4504000	433200	2026-01-25 22:40:05.006669+00
1641	EG	Egypt	Sūhāj	Al Marāghah	26.6998000	31.6046000	432678	2026-01-25 22:40:05.006669+00
1642	ID	Indonesia	Jawa Barat	Bandung	-6.9120000	107.6097000	432557	2026-01-25 22:40:05.006669+00
1643	CN	China	Hebei	Shahe	36.8549000	114.5033000	431746	2026-01-25 22:40:05.006669+00
1644	IN	India	Kerala	Calicut	11.2588000	75.7804000	431560	2026-01-25 22:40:05.006669+00
1645	NA	Namibia	Khomas	Windhoek	-22.5700000	17.0836000	431000	2026-01-25 22:40:05.006669+00
1646	BR	Brazil	Santa Catarina	Joinvile	-26.3039000	-48.8458000	429604	2026-01-25 22:40:05.006669+00
1647	EG	Egypt	Al Ismā‘īlīyah	Ismailia	30.5833000	32.2667000	429465	2026-01-25 22:40:05.006669+00
1648	PE	Peru	Cusco	Cusco	-13.5250000	-71.9722000	428450	2026-01-25 22:40:05.006669+00
1649	MX	Mexico	Veracruz	Veracruz	19.1903000	-96.1533000	428323	2026-01-25 22:40:05.006669+00
1650	NG	Nigeria	Sokoto	Sokoto	13.0833000	5.2500000	427760	2026-01-25 22:40:05.006669+00
1651	JP	Japan	Chiba	Kashiwa	35.8676000	139.9758000	427603	2026-01-25 22:40:05.006669+00
1652	EG	Egypt	Al Minūfīyah	Al Bājūr	30.4305000	31.0368000	427017	2026-01-25 22:40:05.006669+00
1653	CN	China	Xinjiang	Yan’an Beilu	44.0144000	87.2674000	426253	2026-01-25 22:40:05.006669+00
1654	IN	India	Bihār	Mothīhāri	26.6500000	84.9167000	426158	2026-01-25 22:40:05.006669+00
1655	JP	Japan	Aomori	Aomori	40.8228000	140.7469000	425962	2026-01-25 22:40:05.006669+00
1656	MX	Mexico	Nayarit	Tepic	21.5083000	-104.8931000	425942	2026-01-25 22:40:05.006669+00
1657	IN	India	Mahārāshtra	Akola	20.7000000	77.0000000	425817	2026-01-25 22:40:05.006669+00
1658	PH	Philippines	Mandaluyong	Mandaluyong City	14.5800000	121.0300000	425758	2026-01-25 22:40:05.006669+00
1659	PT	Portugal	Porto	Aves	41.3703000	-8.4101000	425411	2026-01-25 22:40:05.006669+00
1660	KR	Korea, South	Gyeonggi	Sihŭng	37.3799000	126.8029000	425184	2026-01-25 22:40:05.006669+00
1661	SO	Somalia	Togdheer	Burco	9.5221000	45.5336000	425000	2026-01-25 22:40:05.006669+00
1662	RU	Russia	Tverskaya Oblast’	Tver	56.8625000	35.9242000	424969	2026-01-25 22:40:05.006669+00
1663	MX	Mexico	Veracruz	Xalapa	19.5400000	-96.9275000	424755	2026-01-25 22:40:05.006669+00
1664	CO	Colombia	Valle del Cauca	Buenaventura	3.8772000	-77.0267000	423927	2026-01-25 22:40:05.006669+00
1665	CA	Canada	Ontario	London	42.9836000	-81.2497000	423369	2026-01-25 22:40:05.006669+00
1666	BR	Brazil	São Paulo	Piracicaba	-22.7252000	-47.6493000	423323	2026-01-25 22:40:05.006669+00
1667	MA	Morocco	Tanger-Tétouan-Al Hoceïma	Tétouan	35.5667000	-5.3667000	422757	2026-01-25 22:40:05.006669+00
1668	ID	Indonesia	Yogyakarta	Yogyakarta	-7.8014000	110.3644000	422732	2026-01-25 22:40:05.006669+00
1669	VE	Venezuela	Bolívar	Ciudad Bolívar	8.1219000	-63.5500000	422578	2026-01-25 22:40:05.006669+00
1670	MK	North Macedonia	Skopje	Skopje	41.9961000	21.4317000	422540	2026-01-25 22:40:05.006669+00
1671	CN	China	Liaoning	Beining	41.6000000	121.8000000	422289	2026-01-25 22:40:05.006669+00
1672	JP	Japan	Aichi	Toyota	35.0824000	137.1563000	422106	2026-01-25 22:40:05.006669+00
1673	CI	Côte d’Ivoire	Sassandra-Marahoué	Daloa	6.8900000	-6.4500000	421871	2026-01-25 22:40:05.006669+00
1674	KR	Korea, South	Gyeonggi	Uijeongbu	37.7486000	127.0389000	421579	2026-01-25 22:40:05.006669+00
1675	MM	Burma	Kayin State	Hpa-An	16.8906000	97.6333000	421525	2026-01-25 22:40:05.006669+00
1676	CN	China	Hubei	Laohekou	32.3590000	111.6840000	420495	2026-01-25 22:40:05.006669+00
1677	PK	Pakistan	Punjab	Rahimyar Khan	28.4200000	70.3000000	420419	2026-01-25 22:40:05.006669+00
1678	NG	Nigeria	Cross River	Ugep	5.8000000	8.0833000	420000	2026-01-25 22:40:05.006669+00
1679	VN	Vietnam	Thái Nguyên	Thái Nguyên	21.6000000	105.8500000	420000	2026-01-25 22:40:05.006669+00
1680	MY	Malaysia	Negeri Sembilan	Seremban	2.7105000	101.9400000	419536	2026-01-25 22:40:05.006669+00
1681	TR	Turkey	Diyarbakır	Kayapınar	37.9500000	40.1667000	419513	2026-01-25 22:40:05.006669+00
1682	BR	Brazil	Paraíba	Campina Grande	-7.2306000	-35.8811000	419379	2026-01-25 22:40:05.006669+00
1683	CN	China	Yunnan	Xicheng	23.3667000	103.1500000	419314	2026-01-25 22:40:05.006669+00
1684	HK	Hong Kong	\N	Kowloon City	22.3282000	114.1916000	418732	2026-01-25 22:40:05.006669+00
1685	BR	Brazil	São Paulo	Santos	-23.9608000	-46.3339000	418608	2026-01-25 22:40:05.006669+00
1686	AL	Albania	Tiranë	Tirana	41.3272000	19.8186000	418495	2026-01-25 22:40:05.006669+00
1687	BD	Bangladesh	Khulna	Kushtia	23.9000000	89.1200000	418312	2026-01-25 22:40:05.006669+00
1688	SD	Sudan	North Kordofan	El Obeid	13.1833000	30.2167000	418280	2026-01-25 22:40:05.006669+00
1689	BR	Brazil	São Paulo	Mauá	-23.6678000	-46.4608000	418261	2026-01-25 22:40:05.006669+00
1690	CN	China	Guizhou	Xingren	25.4350000	105.1862000	417919	2026-01-25 22:40:05.006669+00
1691	JP	Japan	Kagawa	Takamatsu	34.3500000	134.0500000	417814	2026-01-25 22:40:05.006669+00
1692	US	United States	California	Stockton	37.9765000	-121.3109000	416005	2026-01-25 22:40:05.006669+00
1693	LY	Libya	Al Wāḩāt	Ajdābiyā	30.7700000	20.2200000	416000	2026-01-25 22:40:05.006669+00
1694	PE	Peru	Callao	Callao	-12.0522000	-77.1392000	415888	2026-01-25 22:40:05.006669+00
1695	EG	Egypt	Al Jīzah	Awsīm	30.1222000	31.1333000	415735	2026-01-25 22:40:05.006669+00
1696	JP	Japan	Tōkyō	Shinagawa-ku	35.6000000	139.7333000	415729	2026-01-25 22:40:05.006669+00
1697	KR	Korea, South	Gyeonggi	Paju	37.8667000	126.8000000	415345	2026-01-25 22:40:05.006669+00
1698	TR	Turkey	İstanbul	Beylikdüzü	41.0011000	28.6419000	415290	2026-01-25 22:40:05.006669+00
1699	VN	Vietnam	Phú Thọ	Việt Trì	21.3000000	105.4333000	415280	2026-01-25 22:40:05.006669+00
1700	PH	Philippines	Laguna	Santa Rosa	14.3200000	121.1200000	414812	2026-01-25 22:40:05.006669+00
1701	CN	China	Tibet	Nagqu	31.4760000	92.0510000	414554	2026-01-25 22:40:05.006669+00
1702	IN	India	Bihār	Bettiah	26.8014000	84.5028000	414453	2026-01-25 22:40:05.006669+00
1703	PK	Pakistan	Punjab	Jhang City	31.2694000	72.3161000	414131	2026-01-25 22:40:05.006669+00
1704	CN	China	Heilongjiang	Fujin	47.2500000	132.0333000	414090	2026-01-25 22:40:05.006669+00
1705	TR	Turkey	Ankara	Altındağ	39.9636000	32.9033000	413994	2026-01-25 22:40:05.006669+00
1706	CN	China	Shanxi	Yuanping	38.7310000	112.7110000	413922	2026-01-25 22:40:05.006669+00
1707	EG	Egypt	Al Minūfīyah	Talā	30.6798000	30.9436000	413839	2026-01-25 22:40:05.006669+00
1708	EG	Egypt	Ad Daqahlīyah	Ţalkhā	31.0592000	31.3767000	413584	2026-01-25 22:40:05.006669+00
1709	BR	Brazil	Roraima	Boa Vista	2.8200000	-60.6719000	413486	2026-01-25 22:40:05.006669+00
1710	GM	Gambia, The	Banjul	Banjul	13.4581000	-16.5786000	413397	2026-01-25 22:40:05.006669+00
1711	ID	Indonesia	Papua	Jayapura	-2.5330000	140.7170000	413283	2026-01-25 22:40:05.006669+00
1712	JP	Japan	Toyama	Toyama	36.6959000	137.2137000	413028	2026-01-25 22:40:05.006669+00
1713	IR	Iran	Kordestān	Sanandaj	35.3114000	46.9961000	412767	2026-01-25 22:40:05.006669+00
1714	TH	Thailand	Khon Kaen	Khon Kaen	16.4333000	102.8333000	412758	2026-01-25 22:40:05.006669+00
1715	CN	China	Liaoning	Linghai	41.1667000	121.3500000	412513	2026-01-25 22:40:05.006669+00
1716	IN	India	Karnātaka	Shorāpur	16.5200000	76.7600000	412291	2026-01-25 22:40:05.006669+00
1717	CI	Côte d’Ivoire	Abidjan	Koumassi	5.2972000	-3.9675000	412282	2026-01-25 22:40:05.006669+00
1718	US	United States	North Carolina	Durham	35.9792000	-78.9022000	411362	2026-01-25 22:40:05.006669+00
1719	IN	India	Tamil Nādu	Tinnevelly	8.7136000	77.7567000	411298	2026-01-25 22:40:05.006669+00
1720	CO	Colombia	Nariño	Pasto	1.2078000	-77.2772000	410835	2026-01-25 22:40:05.006669+00
1721	US	United States	Tennessee	Chattanooga	35.0660000	-85.2481000	410795	2026-01-25 22:40:05.006669+00
1722	IN	India	Karnātaka	Bellary	15.1000000	76.9167000	410445	2026-01-25 22:40:05.006669+00
1723	IN	India	Bihār	Bhāgalpur	25.2500000	87.0000000	410210	2026-01-25 22:40:05.006669+00
1724	CN	China	Hubei	Danjiangkou	32.5401000	111.5131000	409940	2026-01-25 22:40:05.006669+00
1725	KE	Kenya	Kisumu	Kisumu	-0.1000000	34.7500000	409928	2026-01-25 22:40:05.006669+00
1726	CN	China	Hebei	Zhangjiakou Shi Xuanhua Qu	40.5944000	115.0243000	409745	2026-01-25 22:40:05.006669+00
1727	BR	Brazil	Paraná	Maringá	-23.4250000	-51.9389000	409657	2026-01-25 22:40:05.006669+00
1728	IN	India	Kerala	Manampizha	9.2972000	76.6500000	409271	2026-01-25 22:40:05.006669+00
1729	TR	Turkey	Kayseri	Kocasinan	38.7333000	35.4833000	409005	2026-01-25 22:40:05.006669+00
1730	ID	Indonesia	Nusa Tenggara Barat	Mataram	-8.5833000	116.1167000	408900	2026-01-25 22:40:05.006669+00
1731	RU	Russia	Chelyabinskaya Oblast’	Magnitogorsk	53.3833000	59.0333000	408715	2026-01-25 22:40:05.006669+00
1732	US	United States	South Carolina	Greenville	34.8354000	-82.3646000	408626	2026-01-25 22:40:05.006669+00
1733	CN	China	Hubei	Zhijiang	30.4260000	111.7610000	408487	2026-01-25 22:40:05.006669+00
1734	NG	Nigeria	Kaduna	Zaria	11.0667000	7.7000000	408198	2026-01-25 22:40:05.006669+00
1735	US	United States	Pennsylvania	Lancaster	40.0420000	-76.3012000	408023	2026-01-25 22:40:05.006669+00
1736	CN	China	Shanxi	Fenyang	37.2616000	111.7699000	407647	2026-01-25 22:40:05.006669+00
1737	US	United States	New York	Syracuse	43.0407000	-76.1437000	407625	2026-01-25 22:40:05.006669+00
1738	PH	Philippines	Laguna	Biñan	14.3300000	121.0800000	407437	2026-01-25 22:40:05.006669+00
1739	TR	Turkey	Kocaeli	Gebze	40.8000000	29.4333000	407019	2026-01-25 22:40:05.006669+00
1740	ET	Ethiopia	Oromīya	Shashemenē	7.2000000	38.6000000	407000	2026-01-25 22:40:05.006669+00
1741	CN	China	Sichuan	Fangting	31.1270000	104.1670000	406775	2026-01-25 22:40:05.006669+00
1742	CN	China	Jilin	Shulan	44.4059000	126.9655000	406744	2026-01-25 22:40:05.006669+00
1743	CN	China	Sichuan	Wanyuan	31.9833000	107.9667000	406685	2026-01-25 22:40:05.006669+00
1744	CN	China	Shanxi	Jiexiu	37.0270000	111.9170000	406517	2026-01-25 22:40:05.006669+00
1745	TH	Thailand	Songkhla	Hat Yai	7.0167000	100.4667000	406513	2026-01-25 22:40:05.006669+00
1746	TR	Turkey	Diyarbakır	Bağlar	37.9167000	40.1833000	406471	2026-01-25 22:40:05.006669+00
1747	HK	Hong Kong	\N	Sham Shui Po	22.3307000	114.1622000	405869	2026-01-25 22:40:05.006669+00
1748	AR	Argentina	Santa Fe	Santa Fe	-31.6333000	-60.7000000	405683	2026-01-25 22:40:05.006669+00
1749	IN	India	Delhi	Delhi Cantonment	28.6000000	77.1333000	405633	2026-01-25 22:40:05.006669+00
1750	VE	Venezuela	Sucre	Cumaná	10.4564000	-64.1675000	405626	2026-01-25 22:40:05.006669+00
1751	US	United States	Arkansas	Fayetteville	36.0714000	-94.1661000	405556	2026-01-25 22:40:05.006669+00
1752	BD	Bangladesh	Chattogram	Barura	23.3683000	91.0484000	405118	2026-01-25 22:40:05.006669+00
1753	KR	Korea, South	Gyeongbuk	Kumi	36.1195000	128.3444000	404691	2026-01-25 22:40:05.006669+00
1754	JP	Japan	Nagasaki	Nagasaki	32.7447000	129.8736000	404656	2026-01-25 22:40:05.006669+00
1755	YE	Yemen	Al Ḩudaydah	Al Ḩudaydah	14.8022000	42.9511000	404062	2026-01-25 22:40:05.006669+00
1756	CN	China	Jiangxi	Pencheng	29.6760000	115.6810000	403655	2026-01-25 22:40:05.006669+00
1757	IN	India	West Bengal	Salt Lake City	22.6100000	88.4000000	403316	2026-01-25 22:40:05.006669+00
1758	IR	Iran	Qazvīn	Qazvīn	36.2886000	50.0069000	402748	2026-01-25 22:40:05.006669+00
1759	IN	India	Madhya Pradesh	Etāwa	24.1800000	78.2000000	402678	2026-01-25 22:40:05.006669+00
1760	IN	India	Haryāna	Sonīpat	28.9900000	77.0220000	402000	2026-01-25 22:40:05.006669+00
1761	BR	Brazil	São Paulo	Jundiaí	-23.1864000	-46.8842000	401896	2026-01-25 22:40:05.006669+00
1762	US	United States	Florida	Pensacola	30.4413000	-87.1911000	401535	2026-01-25 22:40:05.006669+00
1763	BD	Bangladesh	Rājshāhi	Bogra	24.8510000	89.3711000	400983	2026-01-25 22:40:05.006669+00
1764	CZ	Czechia	Jihomoravský Kraj	Brno	49.1925000	16.6083000	400566	2026-01-25 22:40:05.006669+00
1765	KZ	Kazakhstan	East Kazakhstan	Öskemen	49.9833000	82.6167000	400142	2026-01-25 22:40:05.006669+00
1766	JP	Japan	Gifu	Gifu	35.4232000	136.7608000	400118	2026-01-25 22:40:05.006669+00
1767	CO	Colombia	Córdoba	Montería	8.7500000	-75.8833000	400000	2026-01-25 22:40:05.006669+00
1768	MM	Burma	Rakhine State	Maungdaw	20.8167000	92.3667000	400000	2026-01-25 22:40:05.006669+00
1769	NG	Nigeria	Oyo	Igboho	8.8333000	3.7500000	400000	2026-01-25 22:40:05.006669+00
1770	TR	Turkey	Adana	Yüreğir	36.9928000	35.3764000	399910	2026-01-25 22:40:05.006669+00
1771	CN	China	Hebei	Pingquan	41.0184000	118.7020000	399378	2026-01-25 22:40:05.006669+00
1772	JP	Japan	Ōsaka	Toyonaka	34.7833000	135.4667000	399263	2026-01-25 22:40:05.006669+00
1773	PK	Pakistan	Punjab	Dera Ghazi Khan	30.0331000	70.6400000	399064	2026-01-25 22:40:05.006669+00
1774	TR	Turkey	Hatay	Hatay	36.2025000	36.1606000	399045	2026-01-25 22:40:05.006669+00
1775	UA	Ukraine	Luhanska Oblast	Luhansk	48.5678000	39.3031000	397677	2026-01-25 22:40:05.006669+00
1776	JP	Japan	Miyazaki	Miyazaki	31.9078000	131.4203000	397476	2026-01-25 22:40:05.006669+00
1777	CN	China	Hubei	Dangyang	30.8210000	111.7890000	397465	2026-01-25 22:40:05.006669+00
1778	IN	India	Kerala	Quilon	8.8932000	76.6141000	397419	2026-01-25 22:40:05.006669+00
1779	IN	India	Kerala	Mulangodi	9.0000000	76.6167000	397419	2026-01-25 22:40:05.006669+00
1780	IN	India	Kerala	Munro Turuttu	9.0000000	76.6167000	397419	2026-01-25 22:40:05.006669+00
1781	VE	Venezuela	Barinas	Barinas	8.6333000	-70.2000000	397279	2026-01-25 22:40:05.006669+00
1782	KR	Korea, South	Gyeonggi	Gwangju	37.3667000	127.2833000	397269	2026-01-25 22:40:05.006669+00
1783	CN	China	Hebei	Nangong	37.3590000	115.4090000	396718	2026-01-25 22:40:05.006669+00
1784	JP	Japan	Ōsaka	Hirakata	34.8167000	135.6500000	396694	2026-01-25 22:40:05.006669+00
1785	MY	Malaysia	Sabah	Sandakan	5.8430000	118.1080000	396290	2026-01-25 22:40:05.006669+00
1786	PL	Poland	Zachodniopomorskie	Szczecin	53.4325000	14.5481000	396168	2026-01-25 22:40:05.006669+00
1787	RU	Russia	Khanty-Mansiyskiy Avtonomnyy Okrug-Yugra	Surgut	61.2500000	73.4333000	395900	2026-01-25 22:40:05.006669+00
1788	CN	China	Shanxi	Yongji	34.8670000	110.4480000	394935	2026-01-25 22:40:05.006669+00
1789	US	United States	Texas	Arlington	32.6998000	-97.1250000	394769	2026-01-25 22:40:05.006669+00
1790	IN	India	Tamil Nādu	Karūr	10.9601000	78.0766000	394719	2026-01-25 22:40:05.006669+00
1791	MG	Madagascar	Mahajanga	Betsiboka	-16.8667000	46.9500000	394561	2026-01-25 22:40:05.006669+00
1792	NG	Nigeria	Ogun	Ijebu-Ode	6.8208000	3.9208000	394246	2026-01-25 22:40:05.006669+00
1793	KW	Kuwait	Al Jahrā’	Al Jahrā’	29.3500000	47.6833000	393432	2026-01-25 22:40:05.006669+00
1794	TZ	Tanzania	Tanga	Tanga	-5.0742000	39.0992000	393429	2026-01-25 22:40:05.006669+00
1795	BR	Brazil	São Paulo	Diadema	-23.6858000	-46.6228000	393237	2026-01-25 22:40:05.006669+00
1796	AO	Angola	Lunda-Sul	Saurimo	-9.6500000	20.4000000	393000	2026-01-25 22:40:05.006669+00
1797	IN	India	Mahārāshtra	Jālna	19.8410000	75.8864000	393000	2026-01-25 22:40:05.006669+00
1798	NG	Nigeria	Adamawa	Yola	9.2300000	12.4600000	392854	2026-01-25 22:40:05.006669+00
1799	CN	China	Zhejiang	Zhugang	28.1358000	121.2264000	392800	2026-01-25 22:40:05.006669+00
1800	CN	China	Shanxi	Hejin	35.5960000	110.7120000	392561	2026-01-25 22:40:05.006669+00
1801	CN	China	Jilin	Dunhua	43.3667000	128.2333000	392486	2026-01-25 22:40:05.006669+00
1802	BD	Bangladesh	Dhaka	Tāngāil	24.2500000	89.9200000	392300	2026-01-25 22:40:05.006669+00
1803	ZA	South Africa	Western Cape	Khayelitsha	-34.0403000	18.6778000	391749	2026-01-25 22:40:05.006669+00
1804	IQ	Iraq	Al Qādisīyah	Ad Dīwānīyah	31.9892000	44.9247000	391600	2026-01-25 22:40:05.006669+00
1805	NG	Nigeria	Anambra	Nnewi	6.0167000	6.9167000	391227	2026-01-25 22:40:05.006669+00
1806	CI	Côte d’Ivoire	Bas-Sassandra	San-Pédro	4.7704000	-6.6400000	390654	2026-01-25 22:40:05.006669+00
1807	PK	Pakistan	Punjab	Gujrat	32.5739000	74.0789000	390533	2026-01-25 22:40:05.006669+00
1808	CN	China	Sichuan	Huili Chengguanzhen	26.6333000	102.2500000	390531	2026-01-25 22:40:05.006669+00
1809	JP	Japan	Kanagawa	Yokosuka	35.0000000	16.0000000	390275	2026-01-25 22:40:05.006669+00
1810	US	United States	Colorado	Aurora	39.7083000	-104.7237000	390201	2026-01-25 22:40:05.006669+00
1811	EG	Egypt	Asyūţ	Asyūţ	27.1869000	31.1714000	389307	2026-01-25 22:40:05.006669+00
1812	NG	Nigeria	Borno	Gwoza	11.0861000	13.6914000	388600	2026-01-25 22:40:05.006669+00
1813	PH	Philippines	Manila	Sampaloc	14.6031000	121.0022000	388305	2026-01-25 22:40:05.006669+00
1814	NG	Nigeria	Oyo	Saki	8.6667000	3.4000000	388225	2026-01-25 22:40:05.006669+00
1815	IT	Italy	Emilia-Romagna	Bologna	44.4939000	11.3428000	387971	2026-01-25 22:40:05.006669+00
1816	KZ	Kazakhstan	Aqtöbe	Aqtöbe	50.2836000	57.2297000	387807	2026-01-25 22:40:05.006669+00
1817	ID	Indonesia	Banten	Cilegon	-6.0027000	106.0112000	387543	2026-01-25 22:40:05.006669+00
1818	TZ	Tanzania	Kigoma	Uvinza	-5.1069000	30.3839000	387442	2026-01-25 22:40:05.006669+00
1819	SA	Saudi Arabia	Ash Sharqīyah	Ḩafr al Bāţin	28.4337000	45.9601000	387096	2026-01-25 22:40:05.006669+00
1820	TR	Turkey	Elazığ	Elazığ	38.6744000	39.2228000	387072	2026-01-25 22:40:05.006669+00
1821	IR	Iran	Zanjān	Zanjān	36.6864000	48.4953000	386851	2026-01-25 22:40:05.006669+00
1822	IN	India	Uttar Pradesh	Bairia	25.7583000	84.1489000	386745	2026-01-25 22:40:05.006669+00
1823	NG	Nigeria	Oyo	Oyo	7.8417000	3.9306000	386723	2026-01-25 22:40:05.006669+00
1824	PH	Philippines	Rizal	Taytay	14.5692000	121.1325000	386451	2026-01-25 22:40:05.006669+00
1825	CD	Congo (Kinshasa)	Kinshasa	Kisenzi	-4.4094000	15.3425000	386151	2026-01-25 22:40:05.006669+00
1826	IN	India	West Bengal	Bhātpāra	22.8700000	88.4100000	386019	2026-01-25 22:40:05.006669+00
1827	PT	Portugal	Lisboa	Sintra	38.7974000	-9.3904000	385606	2026-01-25 22:40:05.006669+00
1828	TR	Turkey	Manisa	Manisa	38.6144000	27.4292000	385452	2026-01-25 22:40:05.006669+00
1829	IN	India	Mahārāshtra	Sirūr	18.8300000	74.3800000	385414	2026-01-25 22:40:05.006669+00
1830	PH	Philippines	Tarlac	Tarlac City	15.4869000	120.5900000	385398	2026-01-25 22:40:05.006669+00
1831	JP	Japan	Aichi	Okazaki	34.9543000	137.1744000	385376	2026-01-25 22:40:05.006669+00
1832	SO	Somalia	Shabeellaha Dhexe	Ceel Baraf	3.2072000	45.7593000	384630	2026-01-25 22:40:05.006669+00
1833	CN	China	Zhejiang	Lingxi	27.5036000	120.3975000	384390	2026-01-25 22:40:05.006669+00
1834	NG	Nigeria	Osun	Ilesa	7.6167000	4.7167000	384334	2026-01-25 22:40:05.006669+00
1835	IN	India	Andhra Pradesh	Kākināda	16.9661000	82.2550000	384182	2026-01-25 22:40:05.006669+00
1836	BD	Bangladesh	Dhaka	Savar	23.8482000	90.2577000	384093	2026-01-25 22:40:05.006669+00
1837	MX	Mexico	Tamaulipas	Nuevo Laredo	27.4861000	-99.5069000	384033	2026-01-25 22:40:05.006669+00
1838	CN	China	Guangdong	Lecheng	25.1333000	113.3333000	383498	2026-01-25 22:40:05.006669+00
1839	OM	Oman	Masqaţ	Bawshar	23.5777000	58.3998000	383257	2026-01-25 22:40:05.006669+00
1840	NZ	New Zealand	Canterbury	Christchurch	-43.5311000	172.6361000	383200	2026-01-25 22:40:05.006669+00
1841	NG	Nigeria	Zamfara	Gusau	12.1500000	6.6667000	383162	2026-01-25 22:40:05.006669+00
1842	CN	China	Shaanxi	Hancheng	35.4667000	110.4333000	383097	2026-01-25 22:40:05.006669+00
1843	CN	China	Tibet	Zêtang	29.2380000	91.7710000	382610	2026-01-25 22:40:05.006669+00
1844	GM	Gambia, The	Kanifing	Serekunda	13.4450000	-16.6750000	382096	2026-01-25 22:40:05.006669+00
1845	GM	Gambia, The	Kanifing	Kanifing	13.4475000	-16.6725000	382096	2026-01-25 22:40:05.006669+00
1846	AU	Australia	Australian Capital Territory	Canberra	-35.2931000	149.1269000	381488	2026-01-25 22:40:05.006669+00
1847	JP	Japan	Ōsaka	Minamisuita	34.7594000	135.5169000	381238	2026-01-25 22:40:05.006669+00
1848	PH	Philippines	Malabon	Malabon	14.6600000	120.9600000	380522	2026-01-25 22:40:05.006669+00
1849	CO	Colombia	Huila	Neiva	2.9345000	-75.2809000	380019	2026-01-25 22:40:05.006669+00
1850	VN	Vietnam	Hà Tĩnh	Hà Tĩnh	18.3333000	105.9000000	380000	2026-01-25 22:40:05.006669+00
1851	PE	Peru	Junín	Huancayo	-12.0667000	-75.2167000	378203	2026-01-25 22:40:05.006669+00
1852	MX	Mexico	Guanajuato	Celaya	20.5222000	-100.8122000	378143	2026-01-25 22:40:05.006669+00
1853	JP	Japan	Aichi	Ichinomiya	35.3039000	136.8031000	378108	2026-01-25 22:40:05.006669+00
1854	PE	Peru	Loreto	Iquitos	-3.7500000	-73.2500000	377609	2026-01-25 22:40:05.006669+00
1855	IN	India	West Bengal	Pānihāti	22.6900000	88.3700000	377347	2026-01-25 22:40:05.006669+00
1856	CN	China	Guangdong	Lianzhou	24.7810000	112.3770000	377220	2026-01-25 22:40:05.006669+00
1857	PH	Philippines	Rizal	Cainta	14.5700000	121.1200000	376933	2026-01-25 22:40:05.006669+00
1858	CN	China	Anhui	Helixi	30.6267000	118.9861000	376857	2026-01-25 22:40:05.006669+00
1859	EG	Egypt	Al Jīzah	Madīnat as Sādis min Uktūbar	29.9361000	30.9269000	376302	2026-01-25 22:40:05.006669+00
1860	GN	Guinea	Mamou	Mamou	10.3833000	-12.0833000	376269	2026-01-25 22:40:05.006669+00
1861	US	United States	Pennsylvania	Scranton	41.4044000	-75.6649000	375462	2026-01-25 22:40:05.006669+00
1862	BR	Brazil	São Paulo	Itaquaquecetuba	-23.4864000	-46.3486000	375011	2026-01-25 22:40:05.006669+00
1863	PK	Pakistan	Punjab	Cantonment	31.5167000	74.3833000	374872	2026-01-25 22:40:05.006669+00
1864	IN	India	Haryāna	Rohtak	28.8909000	76.5796000	374292	2026-01-25 22:40:05.006669+00
1865	IN	India	Punjab	Māler Kotla	30.5167000	75.8833000	374000	2026-01-25 22:40:05.006669+00
1866	PK	Pakistan	Punjab	Bhawana	31.5661000	72.6461000	373841	2026-01-25 22:40:05.006669+00
1867	US	United States	California	Oxnard	34.1964000	-119.1815000	373423	2026-01-25 22:40:05.006669+00
1868	RU	Russia	Bryanskaya Oblast’	Bryansk	53.2425000	34.3667000	373310	2026-01-25 22:40:05.006669+00
1869	PH	Philippines	Batangas	Lipa City	13.9411000	121.1622000	372931	2026-01-25 22:40:05.006669+00
1870	PH	Philippines	Butuan	Butuan	8.9480000	125.5430000	372910	2026-01-25 22:40:05.006669+00
1871	EG	Egypt	Ad Daqahlīyah	Dikirnis	31.0890000	31.5948000	372871	2026-01-25 22:40:05.006669+00
1872	JP	Japan	Gunma	Takasaki	36.3219000	139.0033000	372639	2026-01-25 22:40:05.006669+00
1873	ID	Indonesia	Maluku	Ambon	-3.6967000	128.1783000	372249	2026-01-25 22:40:05.006669+00
1874	US	United States	California	Indio	33.7346000	-116.2346000	371926	2026-01-25 22:40:05.006669+00
1875	PK	Pakistan	Punjab	Malakwal	32.5531000	73.2067000	371869	2026-01-25 22:40:05.006669+00
1876	JP	Japan	Aichi	Toyohashi	34.7692000	137.3915000	371507	2026-01-25 22:40:05.006669+00
1877	ZW	Zimbabwe	Harare	Chitungwiza	-17.9939000	31.0481000	371244	2026-01-25 22:40:05.006669+00
1878	CN	China	Jilin	Panshi	42.9500000	126.0667000	370238	2026-01-25 22:40:05.006669+00
1879	IQ	Iraq	Al Başrah	Az Zubayr	30.3892000	47.7081000	370000	2026-01-25 22:40:05.006669+00
1880	NP	Nepal	\N	Bharatpur	27.6833000	84.4333000	369377	2026-01-25 22:40:05.006669+00
1881	VE	Venezuela	Miranda	Petare	10.4833000	-66.8167000	369000	2026-01-25 22:40:05.006669+00
1882	PK	Pakistan	Khyber Pakhtunkhwa	Mardan	34.2012000	72.0258000	368302	2026-01-25 22:40:05.006669+00
1883	JP	Japan	Nagano	Nagano	36.6486000	138.1947000	367184	2026-01-25 22:40:05.006669+00
1884	BR	Brazil	São Paulo	Bauru	-22.3147000	-49.0606000	366992	2026-01-25 22:40:05.006669+00
1885	CL	Chile	Región Metropolitana	La Florida	-33.5333000	-70.5833000	366916	2026-01-25 22:40:05.006669+00
1886	MX	Mexico	México	Nicolás Romero	19.5833000	-99.3667000	366602	2026-01-25 22:40:05.006669+00
1887	CN	China	Yunnan	Jinshan	25.1475000	101.9764000	366512	2026-01-25 22:40:05.006669+00
1888	DE	Germany	North Rhine-Westphalia	Bochum	51.4819000	7.2158000	366385	2026-01-25 22:40:05.006669+00
1889	PH	Philippines	Baguio	Baguio City	16.4119000	120.5933000	366358	2026-01-25 22:40:05.006669+00
1890	ID	Indonesia	Jawa Barat	Cibinong	-6.4850000	106.8420000	365387	2026-01-25 22:40:05.006669+00
1891	TR	Turkey	Sivas	Sivas	39.7500000	37.0167000	365274	2026-01-25 22:40:05.006669+00
1892	IN	India	Chhattīsgarh	Kolga	22.3500000	82.6800000	365253	2026-01-25 22:40:05.006669+00
1893	IN	India	Chhattīsgarh	Korba	22.3458000	82.6963000	365253	2026-01-25 22:40:05.006669+00
1894	SO	Somalia	Bari	Qardho	9.5004000	49.1660000	365000	2026-01-25 22:40:05.006669+00
1895	BR	Brazil	Acre	Rio Branco	-9.9781000	-67.8117000	364756	2026-01-25 22:40:05.006669+00
1896	MX	Mexico	México	Tecámac	19.7131000	-98.9683000	364579	2026-01-25 22:40:05.006669+00
1897	TR	Turkey	Antalya	Alanya	36.5500000	32.0000000	364180	2026-01-25 22:40:05.006669+00
1898	PH	Philippines	Mandaue	Mandaue City	10.3300000	123.9300000	364116	2026-01-25 22:40:05.006669+00
1899	US	United States	California	Victorville	34.5277000	-117.3536000	363596	2026-01-25 22:40:05.006669+00
1900	TR	Turkey	Kocaeli	Kocaeli	40.7625000	29.9175000	363416	2026-01-25 22:40:05.006669+00
1901	NG	Nigeria	Delta	Warri	5.5167000	5.7500000	363382	2026-01-25 22:40:05.006669+00
1902	CA	Canada	British Columbia	Victoria	48.4283000	-123.3647000	363222	2026-01-25 22:40:05.006669+00
1903	KP	Korea, North	Kangwŏn	Wŏnsan	39.1475000	127.4461000	363127	2026-01-25 22:40:05.006669+00
1904	PH	Philippines	Iligan	Iligan	8.2300000	124.2500000	363115	2026-01-25 22:40:05.006669+00
1905	CN	China	Hebei	Anguo	38.4180000	115.3270000	363091	2026-01-25 22:40:05.006669+00
1906	GB	United Kingdom	Coventry	Coventry	52.4081000	-1.5106000	362690	2026-01-25 22:40:05.006669+00
1907	US	United States	New Jersey	Trenton	40.2237000	-74.7641000	362501	2026-01-25 22:40:05.006669+00
1908	TW	Taiwan	Keelung	Keelung	25.1333000	121.7333000	362487	2026-01-25 22:40:05.006669+00
1909	TZ	Tanzania	Geita	Geita	-2.8714000	32.2294000	361671	2026-01-25 22:40:05.006669+00
1910	RU	Russia	Ivanovskaya Oblast’	Ivanovo	56.9967000	40.9819000	361644	2026-01-25 22:40:05.006669+00
1911	EC	Ecuador	Azuay	Cuenca	-2.8974000	-79.0045000	361524	2026-01-25 22:40:05.006669+00
1912	GB	United Kingdom	Cardiff	Caerdydd	51.4817000	-3.1792000	361469	2026-01-25 22:40:05.006669+00
1913	BR	Brazil	Santa Catarina	Blumenau	-26.9189000	-49.0658000	361261	2026-01-25 22:40:05.006669+00
1914	CN	China	Shanghai	Nanqiao	30.9167000	121.4547000	361185	2026-01-25 22:40:05.006669+00
1915	BY	Belarus	Hrodzyenskaya Voblasts’	Hrodna	53.6667000	23.8333000	361115	2026-01-25 22:40:05.006669+00
1916	IT	Italy	Tuscany	Florence	43.7714000	11.2542000	360930	2026-01-25 22:40:05.006669+00
1917	SO	Somalia	Bay	Buurhakaba	2.7837000	44.0833000	360795	2026-01-25 22:40:05.006669+00
1918	ID	Indonesia	Bengkulu	Bengkulu	-3.7956000	102.2592000	360495	2026-01-25 22:40:05.006669+00
1919	BR	Brazil	Rio Grande do Sul	Caxias do Sul	-29.1678000	-51.1789000	360419	2026-01-25 22:40:05.006669+00
1920	SE	Sweden	Skåne	Malmö	55.5833000	13.0333000	360249	2026-01-25 22:40:05.006669+00
1921	CN	China	Sichuan	Shuanghe	30.3746000	106.7903000	360000	2026-01-25 22:40:05.006669+00
1922	HT	Haiti	Ouest	Pétion-Ville	18.5098000	-72.2856000	359615	2026-01-25 22:40:05.006669+00
1923	CN	China	Liaoning	Dengtacun	41.4333000	123.3333000	359401	2026-01-25 22:40:05.006669+00
1924	US	United States	Alabama	Huntsville	34.6981000	-86.6412000	359389	2026-01-25 22:40:05.006669+00
1925	NL	Netherlands	Utrecht	Utrecht	52.0908000	5.1217000	359370	2026-01-25 22:40:05.006669+00
1926	ID	Indonesia	Sulawesi Tengah	Palu	-0.8950000	119.8594000	359350	2026-01-25 22:40:05.006669+00
1927	IN	India	Rājasthān	Sīkar	27.6200000	75.1500000	359293	2026-01-25 22:40:05.006669+00
1928	NG	Nigeria	Abia	Umuahia	5.5333000	7.4833000	359230	2026-01-25 22:40:05.006669+00
1929	DE	Germany	North Rhine-Westphalia	Wuppertal	51.2667000	7.1833000	358938	2026-01-25 22:40:05.006669+00
1930	CO	Colombia	Valle del Cauca	Palmira	3.5833000	-76.2500000	358895	2026-01-25 22:40:05.006669+00
1931	ES	Spain	Valencia	Alicante	38.3453000	-0.4831000	358720	2026-01-25 22:40:05.006669+00
1932	BR	Brazil	São Paulo	São José do Rio Prêto	-20.8200000	-49.3789000	358523	2026-01-25 22:40:05.006669+00
1933	EG	Egypt	Al Minūfīyah	Ash Shuhadā’	30.5968000	30.8993000	358486	2026-01-25 22:40:05.006669+00
1934	NG	Nigeria	Ondo	Ondo	7.0833000	4.8333000	358430	2026-01-25 22:40:05.006669+00
1935	BY	Belarus	Vitsyebskaya Voblasts’	Vitsyebsk	55.1917000	30.2056000	358395	2026-01-25 22:40:05.006669+00
1936	IN	India	Bihār	Sasarām	24.9500000	84.0300000	358283	2026-01-25 22:40:05.006669+00
1937	TR	Turkey	İstanbul	Sultanbeyli	40.9683000	29.2617000	358201	2026-01-25 22:40:05.006669+00
1938	CN	China	Shaanxi	Xunyang	32.8341000	109.3653000	357876	2026-01-25 22:40:05.006669+00
1939	KZ	Kazakhstan	Zhambyl	Taraz	42.9000000	71.3667000	357795	2026-01-25 22:40:05.006669+00
1940	AO	Angola	Benguela	Cubal	-13.0333000	14.2500000	357618	2026-01-25 22:40:05.006669+00
1941	CN	China	Heilongjiang	Anda	46.4240000	125.3520000	357535	2026-01-25 22:40:05.006669+00
1942	AO	Angola	Moxico	Luena	-11.7918000	19.9062000	357413	2026-01-25 22:40:05.006669+00
1943	IN	India	Haryāna	Karnāl	29.6860000	76.9890000	357334	2026-01-25 22:40:05.006669+00
1944	HT	Haiti	Artibonite	Gonaïves	19.4456000	-72.6883000	356324	2026-01-25 22:40:05.006669+00
1945	UA	Ukraine	Vinnytska Oblast	Vinnytsia	49.2333000	28.4833000	356303	2026-01-25 22:40:05.006669+00
1946	MX	Mexico	Veracruz	Minatitlán	17.9833000	-94.5500000	356020	2026-01-25 22:40:05.006669+00
1947	CN	China	Gansu	Linxia Chengguanzhen	35.6047000	103.2422000	355968	2026-01-25 22:40:05.006669+00
1948	IN	India	Odisha	Brahmapur	19.3150000	84.7941000	355823	2026-01-25 22:40:05.006669+00
1949	US	United States	California	Modesto	37.6375000	-121.0028000	355686	2026-01-25 22:40:05.006669+00
1950	BR	Brazil	Ceará	Caucaia	-3.7328000	-38.6558000	355679	2026-01-25 22:40:05.006669+00
1951	PH	Philippines	Laguna	Cabuyao	14.2750000	121.1250000	355330	2026-01-25 22:40:05.006669+00
1952	SD	Sudan	Gedaref	Gedaref	14.0333000	35.3833000	354927	2026-01-25 22:40:05.006669+00
1953	PH	Philippines	Pampanga	San Fernando	15.0300000	120.6800000	354666	2026-01-25 22:40:05.006669+00
1954	JP	Japan	Saitama	Kawagoe	35.9251000	139.4858000	354598	2026-01-25 22:40:05.006669+00
1955	NP	Nepal	Gaṇḍakī	Pokhara	28.2097000	83.9853000	353841	2026-01-25 22:40:05.006669+00
1956	FR	France	Provence-Alpes-Côte d’Azur	Nice	43.7034000	7.2663000	353701	2026-01-25 22:40:05.006669+00
1957	MX	Mexico	Tabasco	Villahermosa	17.9892000	-92.9281000	353577	2026-01-25 22:40:05.006669+00
1958	JP	Japan	Wakayama	Wakayama	34.2333000	135.1667000	353299	2026-01-25 22:40:05.006669+00
1959	BY	Belarus	Mahilyowskaya Voblasts’	Mahilyow	53.9167000	30.3500000	353110	2026-01-25 22:40:05.006669+00
1960	KG	Kyrgyzstan	Osh	Osh	40.5333000	72.7833000	353080	2026-01-25 22:40:05.006669+00
1961	JP	Japan	Tōkyō	Kita-ku	35.7500000	139.7333000	353058	2026-01-25 22:40:05.006669+00
1962	KR	Korea, South	Gyeonggi	Gimpo	37.7000000	126.6000000	352683	2026-01-25 22:40:05.006669+00
1963	AR	Argentina	Corrientes	Corrientes	-27.4833000	-58.8167000	352646	2026-01-25 22:40:05.006669+00
1964	PK	Pakistan	Sindh	Thari Mir Wah	27.0683000	68.6023000	352491	2026-01-25 22:40:05.006669+00
1965	JP	Japan	Nara	Nara	34.6844000	135.8050000	352377	2026-01-25 22:40:05.006669+00
1966	RU	Russia	Vladimirskaya Oblast’	Vladimir	56.1286000	40.4058000	352347	2026-01-25 22:40:05.006669+00
1967	KP	Korea, North	P’yŏngbuk	Sinŭiju	40.1000000	124.4000000	352000	2026-01-25 22:40:05.006669+00
1968	BO	Bolivia	Oruro	Oruro	-17.9667000	-67.1167000	351802	2026-01-25 22:40:05.006669+00
1969	RU	Russia	Arkhangel’skaya Oblast’	Arkhangelsk	64.5431000	40.5375000	351488	2026-01-25 22:40:05.006669+00
1970	PH	Philippines	Batangas	Batangas	13.8300000	121.0000000	351437	2026-01-25 22:40:05.006669+00
1971	IN	India	Mahārāshtra	Ahmadnagar	19.0800000	74.7300000	350859	2026-01-25 22:40:05.006669+00
1972	BG	Bulgaria	Varna	Varna	43.2114000	27.9111000	350745	2026-01-25 22:40:05.006669+00
1973	TR	Turkey	Mersin	Tarsus	36.9165000	34.8951000	350732	2026-01-25 22:40:05.006669+00
1974	TR	Turkey	İstanbul	Sarıyer	41.1669000	29.0572000	350454	2026-01-25 22:40:05.006669+00
1975	KZ	Kazakhstan	Abay	Semey	50.4333000	80.2667000	350201	2026-01-25 22:40:05.006669+00
1976	CU	Cuba	Holguín	Holguín	20.8872000	-76.2631000	350191	2026-01-25 22:40:05.006669+00
1977	BD	Bangladesh	Dhaka	Tungi	23.8915000	90.4023000	350000	2026-01-25 22:40:05.006669+00
1978	ET	Ethiopia	Sumalē	Godē	5.9527000	43.5516000	350000	2026-01-25 22:40:05.006669+00
1979	IQ	Iraq	Arbīl	Sawrān	36.6532000	44.5441000	350000	2026-01-25 22:40:05.006669+00
1980	VN	Vietnam	Bình Định	An Nhơn	13.9170000	109.0830000	350000	2026-01-25 22:40:05.006669+00
1981	BR	Brazil	Pernambuco	Olinda	-8.0089000	-34.8550000	349976	2026-01-25 22:40:05.006669+00
1982	BR	Brazil	São Paulo	Praia Grande	-24.0058000	-46.4028000	349935	2026-01-25 22:40:05.006669+00
1983	JP	Japan	Tōkyō	Shinjuku	35.7014000	139.7097000	349385	2026-01-25 22:40:05.006669+00
1984	CL	Chile	Antofagasta	Antofagasta	-23.6500000	-70.4000000	348517	2026-01-25 22:40:05.006669+00
1985	TR	Turkey	Konya	Meram	37.8364000	32.4383000	348325	2026-01-25 22:40:05.006669+00
1986	BR	Brazil	Paraná	Cascavel	-24.9558000	-53.4553000	348051	2026-01-25 22:40:05.006669+00
1987	TR	Turkey	Denizli	Pamukkale	37.9167000	29.1167000	347926	2026-01-25 22:40:05.006669+00
1988	BR	Brazil	Rio Grande do Sul	Canoas	-29.9200000	-51.1800000	347657	2026-01-25 22:40:05.006669+00
1989	JP	Japan	Ōsaka	Takatsuki	34.8461000	135.6175000	347496	2026-01-25 22:40:05.006669+00
1990	CN	China	Hubei	Yidu	30.3780000	111.4500000	347388	2026-01-25 22:40:05.006669+00
1991	MZ	Mozambique	Nampula	António Enes	-16.2308000	39.9105000	347175	2026-01-25 22:40:05.006669+00
1992	BG	Bulgaria	Plovdiv	Plovdiv	42.1434000	24.7510000	346893	2026-01-25 22:40:05.006669+00
1993	AU	Australia	New South Wales	Central Coast	-33.3000000	151.2000000	346596	2026-01-25 22:40:05.006669+00
1994	US	United States	Hawaii	Honolulu	21.3294000	-157.8460000	346323	2026-01-25 22:40:05.006669+00
1995	TR	Turkey	İzmir	Karşıyaka	38.4594000	27.1153000	346264	2026-01-25 22:40:05.006669+00
1996	IN	India	Uttar Pradesh	Shāhjānpur	27.8800000	79.9100000	346103	2026-01-25 22:40:05.006669+00
1997	NG	Nigeria	Federal Capital Territory	Gwagwalada	8.9392000	7.0758000	346000	2026-01-25 22:40:05.006669+00
1998	IN	India	Tamil Nādu	Āvadi	13.1147000	80.1098000	345996	2026-01-25 22:40:05.006669+00
1999	KP	Korea, North	Hamnam	Tanch’ŏn	40.4580000	128.9110000	345875	2026-01-25 22:40:05.006669+00
2000	US	United States	North Carolina	Greensboro	36.0956000	-79.8271000	345858	2026-01-25 22:40:05.006669+00
2001	IN	India	Karnātaka	Khānāpur	15.6394000	74.5083000	345839	2026-01-25 22:40:05.528262+00
2002	SD	Sudan	Gezira	Wad Medani	14.4000000	33.5100000	345290	2026-01-25 22:40:05.528262+00
2003	US	United States	Indiana	Fort Wayne	41.0888000	-85.1436000	345279	2026-01-25 22:40:05.528262+00
2004	SD	Sudan	White Nile	Kūstī	13.1700000	32.6600000	345068	2026-01-25 22:40:05.528262+00
2005	GB	United Kingdom	Belfast	Belfast	54.5967000	-5.9300000	345006	2026-01-25 22:40:05.528262+00
2006	IN	India	Andhra Pradesh	Cuddapah	14.4700000	78.8200000	344893	2026-01-25 22:40:05.528262+00
2007	JP	Japan	Tōkyō	Nakano	35.7074000	139.6638000	344880	2026-01-25 22:40:05.528262+00
2008	CN	China	Fujian	Yong’an	25.9420000	117.3650000	344793	2026-01-25 22:40:05.528262+00
2009	IN	India	Tamil Nādu	Alamādi	13.1097000	80.0972000	344701	2026-01-25 22:40:05.528262+00
2010	BR	Brazil	São Paulo	Carapicuíba	-23.5228000	-46.8358000	344596	2026-01-25 22:40:05.528262+00
2011	US	United States	California	Anaheim	33.8390000	-117.8574000	344553	2026-01-25 22:40:05.528262+00
2012	BY	Belarus	Brestskaya Voblasts’	Brest	52.1347000	23.6569000	344470	2026-01-25 22:40:05.528262+00
2013	JP	Japan	Shiga	Ōtsu	35.0167000	135.8500000	343991	2026-01-25 22:40:05.528262+00
2014	LS	Lesotho	Maseru	Maseru	-29.3100000	27.4800000	343541	2026-01-25 22:40:05.528262+00
2015	KZ	Kazakhstan	Pavlodar	Pavlodar	52.3000000	76.9500000	343091	2026-01-25 22:40:05.528262+00
2016	TH	Thailand	Chon Buri	Chon Buri	13.3611000	100.9850000	342959	2026-01-25 22:40:05.528262+00
2017	PH	Philippines	Naga	Naga City	13.6244000	123.1864000	342769	2026-01-25 22:40:05.528262+00
2018	TJ	Tajikistan	Nohiyahoi Tobei Jumhurí	Vahdat	38.5531000	69.0206000	342700	2026-01-25 22:40:05.528262+00
2019	BR	Brazil	Santa Catarina	Florianópolis	-27.5933000	-48.5530000	342315	2026-01-25 22:40:05.528262+00
2020	BR	Brazil	Pernambuco	Paulista	-7.9408000	-34.8728000	342167	2026-01-25 22:40:05.528262+00
2021	TN	Tunisia	Sfax	Sfax	34.7400000	10.7600000	341999	2026-01-25 22:40:05.528262+00
2022	IN	India	Andhra Pradesh	Rājahmundry	16.9800000	81.7800000	341831	2026-01-25 22:40:05.528262+00
2023	JP	Japan	Saitama	Koshigaya	35.8911000	139.7909000	341784	2026-01-25 22:40:05.528262+00
2024	CN	China	Hunan	Hongjiang	27.1910000	109.8190000	341706	2026-01-25 22:40:05.528262+00
2025	TR	Turkey	Malatya	Yeşilyurt	38.2961000	38.2489000	341654	2026-01-25 22:40:05.528262+00
2026	VN	Vietnam	Bà Rịa-Vũng Tàu	Vũng Tàu	10.3833000	107.1167000	341552	2026-01-25 22:40:05.528262+00
2027	KR	Korea, South	Jeonbuk	Jeonju	35.8167000	127.1500000	341545	2026-01-25 22:40:05.528262+00
2028	IN	India	Rājasthān	Alwar	27.5498000	76.6355000	341422	2026-01-25 22:40:05.528262+00
2029	CN	China	Jilin	Huadian	42.9720000	126.7460000	341308	2026-01-25 22:40:05.528262+00
2030	JP	Japan	Saitama	Tokorozawa	35.7996000	139.4686000	341289	2026-01-25 22:40:05.528262+00
2031	AZ	Azerbaijan	Sumqayıt	Sumqayıt	40.5961000	49.6700000	341200	2026-01-25 22:40:05.528262+00
2032	BR	Brazil	Bahia	Vitória da Conquista	-14.8661000	-40.8394000	341128	2026-01-25 22:40:05.528262+00
2033	CI	Côte d’Ivoire	Yamoussoukro	Yamoussoukro	6.8161000	-5.2742000	340234	2026-01-25 22:40:05.528262+00
2034	VN	Vietnam	Đắk Lắk	Buôn Ma Thuột	12.6667000	108.0500000	340000	2026-01-25 22:40:05.528262+00
2035	US	United States	Texas	Corpus Christi	27.7254000	-97.3767000	339432	2026-01-25 22:40:05.528262+00
2036	US	United States	Colorado	Fort Collins	40.5477000	-105.0656000	339256	2026-01-25 22:40:05.528262+00
2037	CN	China	Heilongjiang	Mishan	45.5298000	131.8466000	339103	2026-01-25 22:40:05.528262+00
2038	UA	Ukraine	Donetska Oblast	Makiivka	48.0556000	37.9611000	338968	2026-01-25 22:40:05.528262+00
2039	US	United States	New York	Islip	40.7385000	-73.1888000	338784	2026-01-25 22:40:05.528262+00
2040	MX	Mexico	Morelos	Cuernavaca	18.9186000	-99.2342000	338650	2026-01-25 22:40:05.528262+00
2041	CA	Canada	Ontario	Markham	43.8767000	-79.2633000	338503	2026-01-25 22:40:05.528262+00
2042	DE	Germany	North Rhine-Westphalia	Bielefeld	52.0211000	8.5347000	338410	2026-01-25 22:40:05.528262+00
2043	PL	Poland	Kujawsko-Pomorskie	Bydgoszcz	53.1219000	18.0003000	337666	2026-01-25 22:40:05.528262+00
2044	KR	Korea, South	Gyeongnam	Chinju	35.2000000	128.0833000	337230	2026-01-25 22:40:05.528262+00
2045	GB	United Kingdom	Reading	Reading	51.4542000	-0.9731000	337108	2026-01-25 22:40:05.528262+00
2046	ZA	South Africa	Gauteng	Randburg	-26.0936000	28.0064000	337053	2026-01-25 22:40:05.528262+00
2047	JP	Japan	Fukushima	Iwaki	37.0505000	140.8877000	336111	2026-01-25 22:40:05.528262+00
2048	CA	Canada	Ontario	Oshawa	43.9000000	-78.8500000	335949	2026-01-25 22:40:05.528262+00
2049	DE	Germany	North Rhine-Westphalia	Bonn	50.7353000	7.1022000	335789	2026-01-25 22:40:05.528262+00
2050	IN	India	Odisha	Sambalpur	21.4700000	83.9700000	335761	2026-01-25 22:40:05.528262+00
2051	EC	Ecuador	Santo Domingo de los Tsáchilas	Santo Domingo de los Colorados	-0.2542000	-79.1719000	334826	2026-01-25 22:40:05.528262+00
2052	MX	Mexico	Michoacán	Uruapan	19.4208000	-102.0628000	334749	2026-01-25 22:40:05.528262+00
2053	PL	Poland	Lubelskie	Lublin	51.2500000	22.5667000	334681	2026-01-25 22:40:05.528262+00
2054	BR	Brazil	Rondônia	Porto Velho	-8.7619000	-63.9039000	334661	2026-01-25 22:40:05.528262+00
2055	CN	China	Guangxi	Licheng	24.5000000	110.4000000	334527	2026-01-25 22:40:05.528262+00
2056	CN	China	Henan	Huichang	34.9073000	112.7914000	334213	2026-01-25 22:40:05.528262+00
2057	FI	Finland	Pirkanmaa	Tampere	61.4981000	23.7600000	334112	2026-01-25 22:40:05.528262+00
2058	US	United States	California	Antioch	37.9787000	-121.7960000	333347	2026-01-25 22:40:05.528262+00
2059	IN	India	Bihār	Muzaffarpur	26.1225000	85.3906000	333200	2026-01-25 22:40:05.528262+00
2060	RU	Russia	Zabaykal’skiy Kray	Chita	52.0500000	113.4667000	333159	2026-01-25 22:40:05.528262+00
2061	CL	Chile	Valparaíso	Viña del Mar	-33.0244000	-71.5517000	332875	2026-01-25 22:40:05.528262+00
2062	PK	Pakistan	Sindh	Khipro	25.8230000	69.3770000	332833	2026-01-25 22:40:05.528262+00
2063	KR	Korea, South	Chungnam	Asan	36.7836000	127.0042000	332790	2026-01-25 22:40:05.528262+00
2064	UZ	Uzbekistan	Qoraqalpog‘iston	Nukus	42.4667000	59.6000000	332500	2026-01-25 22:40:05.528262+00
2065	PK	Pakistan	Punjab	Chak Jhumra	31.5667000	73.1833000	332461	2026-01-25 22:40:05.528262+00
2066	UA	Ukraine	Krym, Avtonomna Respublika	Simferopol	44.9519000	34.1022000	332317	2026-01-25 22:40:05.528262+00
2067	TR	Turkey	İzmir	Konak	38.4189000	27.1285000	332277	2026-01-25 22:40:05.528262+00
2068	MX	Mexico	San Luis Potosí	Soledad de Graciano Sánchez	22.1833000	-100.9333000	332072	2026-01-25 22:40:05.528262+00
2069	OM	Oman	Z̧ufār	Şalālah	17.0197000	54.0897000	331949	2026-01-25 22:40:05.528262+00
2070	BR	Brazil	Pará	Santarém	-2.4431000	-54.7083000	331937	2026-01-25 22:40:05.528262+00
2071	SA	Saudi Arabia	Al Madīnah al Munawwarah	Yanbu‘	24.0523000	38.1503000	331916	2026-01-25 22:40:05.528262+00
2072	JP	Japan	Gunma	Maebashi	36.3895000	139.0634000	331849	2026-01-25 22:40:05.528262+00
2073	RU	Russia	Kaluzhskaya Oblast’	Kaluga	54.5500000	36.2833000	331842	2026-01-25 22:40:05.528262+00
2074	AZ	Azerbaijan	Gəncə	Gəncə	40.6828000	46.3606000	331400	2026-01-25 22:40:05.528262+00
2075	JP	Japan	Hokkaidō	Asahikawa	43.7667000	142.3667000	331392	2026-01-25 22:40:05.528262+00
2076	US	United States	Mississippi	Jackson	32.3157000	-90.2125000	331332	2026-01-25 22:40:05.528262+00
2077	ID	Indonesia	Sulawesi Tenggara	Kendari	-3.9907000	122.5086000	331013	2026-01-25 22:40:05.528262+00
2078	KR	Korea, South	Gangwon	Wŏnju	37.3417000	127.9208000	330854	2026-01-25 22:40:05.528262+00
2079	EG	Egypt	Al Minūfīyah	Birkat as Sab‘	30.6291000	31.0824000	330847	2026-01-25 22:40:05.528262+00
2080	NG	Nigeria	Nasarawa	Lafia	8.4917000	8.5167000	330712	2026-01-25 22:40:05.528262+00
2081	IQ	Iraq	Dahūk	Dahūk	36.8500000	42.9833000	330600	2026-01-25 22:40:05.528262+00
2082	RU	Russia	Sverdlovskaya Oblast’	Nizhniy Tagil	57.9167000	59.9667000	330507	2026-01-25 22:40:05.528262+00
2083	IE	Ireland	Dublin	Finglas	53.3892000	-6.2969000	330506	2026-01-25 22:40:05.528262+00
2084	IN	India	West Bengal	Kāmārhāti	22.6686000	88.3704000	330211	2026-01-25 22:40:05.528262+00
2085	CY	Cyprus	Lefkosía	Nicosia	35.1725000	33.3650000	330000	2026-01-25 22:40:05.528262+00
2086	CN	China	Hunan	Lengshuijiang	27.6860000	111.4360000	329912	2026-01-25 22:40:05.528262+00
2087	BR	Brazil	Minas Gerais	Ribeirão das Neves	-19.7669000	-44.0869000	329794	2026-01-25 22:40:05.528262+00
2088	SN	Senegal	Dakar	Guédiawaye	14.7724000	-17.3884000	329659	2026-01-25 22:40:05.528262+00
2089	MX	Mexico	Sonora	Ciudad Obregón	27.4939000	-109.9389000	329404	2026-01-25 22:40:05.528262+00
2090	IN	India	Uttar Pradesh	Campīernagar	27.0290000	83.2668000	329104	2026-01-25 22:40:05.528262+00
2091	TH	Thailand	Chon Buri	Phatthaya	12.9357000	100.8890000	328961	2026-01-25 22:40:05.528262+00
2092	CN	China	Jilin	Minzhu	43.7238000	127.3448000	328925	2026-01-25 22:40:05.528262+00
2093	RU	Russia	Belgorodskaya Oblast’	Belgorod	50.6000000	36.6000000	328482	2026-01-25 22:40:05.528262+00
2094	MX	Mexico	Durango	Gómez Palacio	25.5611000	-103.4983000	327985	2026-01-25 22:40:05.528262+00
2095	IN	India	Karnātaka	Bijāpur	16.8300000	75.7100000	327427	2026-01-25 22:40:05.528262+00
2096	PH	Philippines	Nueva Ecija	Cabanatuan City	15.4908000	120.9678000	327325	2026-01-25 22:40:05.528262+00
2097	TH	Thailand	Chon Buri	Si Racha	13.1740000	100.9300000	327172	2026-01-25 22:40:05.528262+00
2098	MX	Mexico	Guanajuato	Salamanca	20.5703000	-101.1972000	327169	2026-01-25 22:40:05.528262+00
2099	IN	India	Mahārāshtra	Ratnāgiri	16.9944000	73.3000000	327120	2026-01-25 22:40:05.528262+00
2100	CN	China	Inner Mongolia	Ulanhot	46.0722000	122.0933000	327081	2026-01-25 22:40:05.528262+00
2101	ZM	Zambia	Eastern	Chipata	-13.6453000	32.6464000	327059	2026-01-25 22:40:05.528262+00
2102	JP	Japan	Fukushima	Koriyama	37.4004000	140.3597000	327040	2026-01-25 22:40:05.528262+00
2103	CN	China	Shanxi	Yunzhong	39.8279000	113.1000000	326849	2026-01-25 22:40:05.528262+00
2104	US	United States	North Carolina	Fayetteville	35.0850000	-78.9772000	326821	2026-01-25 22:40:05.528262+00
2105	TR	Turkey	İstanbul	Arnavutköy	41.1856000	28.7406000	326452	2026-01-25 22:40:05.528262+00
2106	TR	Turkey	İstanbul	Küçükçekmece	41.0000000	28.8000000	326452	2026-01-25 22:40:05.528262+00
2107	ZA	South Africa	Gauteng	Roodepoort	-26.1625000	27.8725000	326416	2026-01-25 22:40:05.528262+00
2108	PE	Peru	Ucayali	Pucallpa	-8.3833000	-74.5500000	326040	2026-01-25 22:40:05.528262+00
2109	PH	Philippines	Laguna	San Pedro	14.3583000	121.0583000	326001	2026-01-25 22:40:05.528262+00
2110	US	United States	South Carolina	Myrtle Beach	33.7094000	-78.8844000	325829	2026-01-25 22:40:05.528262+00
2111	JP	Japan	Kōchi	Kōchi	33.5589000	133.5314000	325535	2026-01-25 22:40:05.528262+00
2112	IN	India	Chhattīsgarh	Jagdalpur	19.1800000	81.9200000	325463	2026-01-25 22:40:05.528262+00
2113	IN	India	Uttar Pradesh	Rāmpur	28.8000000	79.0000000	325248	2026-01-25 22:40:05.528262+00
2114	MY	Malaysia	Sarawak	Kuching	1.5300000	110.3300000	325132	2026-01-25 22:40:05.528262+00
2115	PH	Philippines	Cotabato	Cotabato	7.2200000	124.2500000	325079	2026-01-25 22:40:05.528262+00
2116	FR	France	Pays de la Loire	Nantes	47.2181000	-1.5528000	325070	2026-01-25 22:40:05.528262+00
2117	US	United States	Nevada	Henderson	36.0133000	-115.0381000	324523	2026-01-25 22:40:05.528262+00
2118	BR	Brazil	Espírito Santo	Cariacica	-20.2639000	-40.4200000	324285	2026-01-25 22:40:05.528262+00
2119	US	United States	Alabama	Mobile	30.6782000	-88.1162000	324067	2026-01-25 22:40:05.528262+00
2120	ET	Ethiopia	Oromīya	Nazrēt	8.5414000	39.2689000	324000	2026-01-25 22:40:05.528262+00
2121	MA	Morocco	Marrakech-Safi	Safi	32.2833000	-9.2333000	323888	2026-01-25 22:40:05.528262+00
2122	KE	Kenya	Kiambu	Kikuyu	-1.2463000	36.6629000	323881	2026-01-25 22:40:05.528262+00
2123	ES	Spain	Andalusia	Córdoba	37.8900000	-4.7800000	323763	2026-01-25 22:40:05.528262+00
2124	MY	Malaysia	Johor	Kluang	2.0383000	103.3179000	323762	2026-01-25 22:40:05.528262+00
2125	ET	Ethiopia	Tigray	Mekele	13.4969000	39.4769000	323700	2026-01-25 22:40:05.528262+00
2126	BR	Brazil	Rio Grande do Sul	Pelotas	-31.7719000	-52.3428000	323158	2026-01-25 22:40:05.528262+00
2127	CA	Canada	Ontario	Vaughan	43.8333000	-79.5000000	323103	2026-01-25 22:40:05.528262+00
2128	CN	China	Yunnan	Kaiyuan	23.7111000	103.2461000	323031	2026-01-25 22:40:05.528262+00
2129	CN	China	Hunan	Tangdong	25.9730000	113.2310000	322990	2026-01-25 22:40:05.528262+00
2130	DE	Germany	North Rhine-Westphalia	Münster	51.9625000	7.6256000	322904	2026-01-25 22:40:05.528262+00
2131	BR	Brazil	Espírito Santo	Vitória	-20.3106000	-40.2972000	322869	2026-01-25 22:40:05.528262+00
2132	IN	India	Karnātaka	Shimoga	13.9333000	75.5667000	322650	2026-01-25 22:40:05.528262+00
2133	AO	Angola	Uíge	Uíge	-7.6167000	15.0500000	322531	2026-01-25 22:40:05.528262+00
2134	CN	China	Xinjiang	Hotan	37.1167000	79.9167000	322300	2026-01-25 22:40:05.528262+00
2135	NG	Nigeria	Niger	Minna	9.6139000	6.5569000	322163	2026-01-25 22:40:05.528262+00
2136	CN	China	Heilongjiang	Ning’an	44.3410000	129.4830000	322127	2026-01-25 22:40:05.528262+00
2137	CU	Cuba	Camagüey	Camagüey	21.3786000	-77.9186000	321992	2026-01-25 22:40:05.528262+00
2138	MA	Morocco	Oriental	Taourirt	34.4169000	-2.8850000	321876	2026-01-25 22:40:05.528262+00
2139	AR	Argentina	Jujuy	San Salvador de Jujuy	-24.1833000	-65.3000000	321789	2026-01-25 22:40:05.528262+00
2140	IN	India	Uttarākhand	Kāshīpur	29.2200000	78.9500000	321623	2026-01-25 22:40:05.528262+00
2141	VN	Vietnam	Bình Dương	Thủ Dầu Một	10.9667000	106.6500000	321607	2026-01-25 22:40:05.528262+00
2142	BR	Brazil	Espírito Santo	Serra	-20.1289000	-40.3078000	321181	2026-01-25 22:40:05.528262+00
2143	US	United States	Kentucky	Lexington	38.0423000	-84.4587000	321122	2026-01-25 22:40:05.528262+00
2144	BO	Bolivia	La Paz	La Paz	-16.4958000	-68.1333000	321073	2026-01-25 22:40:05.528262+00
2145	ID	Indonesia	Jawa Barat	Sukabumi	-6.9181000	106.9315000	320970	2026-01-25 22:40:05.528262+00
2146	AO	Angola	Cuando Cubango	Menongue	-14.6556000	17.6842000	320914	2026-01-25 22:40:05.528262+00
2147	NG	Nigeria	Kogi	Okene	7.5619000	6.2411000	320260	2026-01-25 22:40:05.528262+00
2148	IN	India	Gujarāt	Jūnāgadh	21.5222000	70.4579000	320250	2026-01-25 22:40:05.528262+00
2149	MX	Mexico	Sinaloa	Guasavito	25.5744000	-108.4706000	320000	2026-01-25 22:40:05.528262+00
2150	KP	Korea, North	P’yŏngnam	Kaech’ŏn	39.6986000	125.9061000	319554	2026-01-25 22:40:05.528262+00
2151	MX	Mexico	Puebla	Tehuacán	18.4617000	-97.3928000	319375	2026-01-25 22:40:05.528262+00
2152	MX	Mexico	Veracruz	Coatzacoalcos	18.1414000	-94.4344000	319187	2026-01-25 22:40:05.528262+00
2153	RE	Reunion	\N	Saint-Denis	-20.8789000	55.4481000	319141	2026-01-25 22:40:05.528262+00
2154	RW	Rwanda	Southern Province	Muhanga	-2.0845000	29.7527000	319141	2026-01-25 22:40:05.528262+00
2155	CN	China	Inner Mongolia	Zalantun	48.0270000	122.7080000	318933	2026-01-25 22:40:05.528262+00
2156	PK	Pakistan	Punjab	Hafizabad	32.0714000	73.6878000	318621	2026-01-25 22:40:05.528262+00
2157	NG	Nigeria	Katsina	Katsina	12.2500000	7.5000000	318459	2026-01-25 22:40:05.528262+00
2158	DO	Dominican Republic	Cibao Norte	Puerto Plata	19.8000000	-70.6833000	318419	2026-01-25 22:40:05.528262+00
2159	KR	Korea, South	Gyeonggi	Gwangmyeongni	37.4760000	126.8660000	318021	2026-01-25 22:40:05.528262+00
2160	US	United States	Michigan	Lansing	42.7142000	-84.5601000	318001	2026-01-25 22:40:05.528262+00
2161	BR	Brazil	São Paulo	Taubaté	-23.0333000	-45.5500000	317915	2026-01-25 22:40:05.528262+00
2162	CN	China	Jilin	Zhengjiatun	43.5183000	123.5027000	317758	2026-01-25 22:40:05.528262+00
2163	PG	Papua New Guinea	National Capital	Port Moresby	-9.4789000	147.1494000	317374	2026-01-25 22:40:05.528262+00
2164	CO	Colombia	Bogotá	Fontibón	4.6786000	-74.1411000	317179	2026-01-25 22:40:05.528262+00
2165	IN	India	Uttar Pradesh	Hāpur	28.7309000	77.7757000	317004	2026-01-25 22:40:05.528262+00
2166	DE	Germany	Baden-Württemberg	Mannheim	49.4878000	8.4661000	316877	2026-01-25 22:40:05.528262+00
2167	BR	Brazil	São Paulo	Barueri	-23.5111000	-46.8764000	316473	2026-01-25 22:40:05.528262+00
2168	US	United States	Georgia	Savannah	32.0286000	-81.1821000	316446	2026-01-25 22:40:05.528262+00
2169	JP	Japan	Okinawa	Naha	26.2122000	127.6792000	316048	2026-01-25 22:40:05.528262+00
2170	IT	Italy	Puglia	Bari	41.1253000	16.8667000	316015	2026-01-25 22:40:05.528262+00
2171	IN	India	Kerala	Pattikād	10.5276000	76.2144000	315957	2026-01-25 22:40:05.528262+00
2172	CN	China	Guangdong	Xiaoli	22.6721000	113.2509000	315820	2026-01-25 22:40:05.528262+00
2173	US	United States	Ohio	Youngstown	41.0993000	-80.6463000	315751	2026-01-25 22:40:05.528262+00
2174	IN	India	Kerala	Trichūr	10.5276000	76.2144000	315596	2026-01-25 22:40:05.528262+00
2175	CN	China	Jiangsu	Yingzhong	32.2370000	119.8150000	315462	2026-01-25 22:40:05.528262+00
2176	SS	South Sudan	Jonglei	Bor	6.2072000	31.5591000	315351	2026-01-25 22:40:05.528262+00
2177	RU	Russia	Volgogradskaya Oblast’	Volzhskiy	48.8056000	44.7417000	315220	2026-01-25 22:40:05.528262+00
2178	PA	Panama	Panamá	San Miguelito	9.0503000	-79.4707000	315019	2026-01-25 22:40:05.528262+00
2179	GN	Guinea	N’Zérékoré	N’Zérékoré	7.7522000	-8.8217000	315000	2026-01-25 22:40:05.528262+00
2180	TR	Turkey	Balıkesir	Balıkesir	39.6333000	27.8833000	314958	2026-01-25 22:40:05.528262+00
2181	FI	Finland	Uusimaa	Espoo	60.2056000	24.6556000	314821	2026-01-25 22:40:05.528262+00
2182	MY	Malaysia	Johor	Muar	2.0337000	102.5666000	314776	2026-01-25 22:40:05.528262+00
2183	US	United States	Michigan	Ann Arbor	42.2759000	-83.7310000	314647	2026-01-25 22:40:05.528262+00
2184	PK	Pakistan	Punjab	Kasur	31.1167000	74.4500000	314617	2026-01-25 22:40:05.528262+00
2185	CO	Colombia	Bogotá	Usme	4.4464000	-74.1522000	314431	2026-01-25 22:40:05.528262+00
2186	IN	India	West Bengal	Barddhamān	23.2333000	87.8667000	314265	2026-01-25 22:40:05.528262+00
2187	TN	Tunisia	Sousse	Sousse	35.8333000	10.6333000	314071	2026-01-25 22:40:05.528262+00
2188	GB	United Kingdom	Kingston upon Hull, City of	Kingston upon Hull	53.7444000	-0.3325000	314018	2026-01-25 22:40:05.528262+00
2189	PH	Philippines	Rizal	Binangonan	14.4514000	121.1919000	313631	2026-01-25 22:40:05.528262+00
2190	CI	Côte d’Ivoire	Abidjan	Attiecoubé	5.3453000	-4.0350000	313135	2026-01-25 22:40:05.528262+00
2191	RU	Russia	Moskovskaya Oblast’	Podolsk	55.4311000	37.5456000	312911	2026-01-25 22:40:05.528262+00
2192	RU	Russia	Smolenskaya Oblast’	Smolensk	54.7828000	32.0453000	312896	2026-01-25 22:40:05.528262+00
2193	CN	China	Gansu	Jiayuguan	39.7732000	98.2882000	312663	2026-01-25 22:40:05.528262+00
2194	MY	Malaysia	Johor	Pasir Gudang	1.4620000	103.9053000	312499	2026-01-25 22:40:05.528262+00
2195	RU	Russia	Vologodskaya Oblast’	Vologda	59.2167000	39.9000000	312420	2026-01-25 22:40:05.528262+00
2196	IR	Iran	Golestān	Gorgān	36.8369000	54.4372000	312223	2026-01-25 22:40:05.528262+00
2197	PH	Philippines	Cavite	Tanza	14.3944000	120.8531000	312116	2026-01-25 22:40:05.528262+00
2198	RU	Russia	Sakha (Yakutiya)	Yakutsk	62.0300000	129.7300000	311760	2026-01-25 22:40:05.528262+00
2199	US	United States	California	Santa Ana	33.7367000	-117.8819000	311639	2026-01-25 22:40:05.528262+00
2200	IT	Italy	Sicilia	Catania	37.5027000	15.0873000	311584	2026-01-25 22:40:05.528262+00
2201	IN	India	Mahārāshtra	Panvel	18.9944000	73.1139000	311434	2026-01-25 22:40:05.528262+00
2202	BR	Brazil	São Paulo	Guarujá	-23.9936000	-46.2564000	311230	2026-01-25 22:40:05.528262+00
2203	IN	India	Andhra Pradesh	Nizāmābād	18.6720000	78.0940000	311152	2026-01-25 22:40:05.528262+00
2204	VN	Vietnam	Bình Định	Quy Nhơn	13.7667000	109.2333000	311000	2026-01-25 22:40:05.528262+00
2205	RU	Russia	Kurganskaya Oblast’	Kurgan	55.4667000	65.3500000	310911	2026-01-25 22:40:05.528262+00
2206	RU	Russia	Mordoviya	Saransk	54.1833000	45.1833000	310898	2026-01-25 22:40:05.528262+00
2207	SA	Saudi Arabia	Ḩā’il	Ḩā’il	27.5167000	41.6833000	310897	2026-01-25 22:40:05.528262+00
2208	CN	China	Guangdong	Datang	22.9406000	113.9436000	310889	2026-01-25 22:40:05.528262+00
2209	CN	China	Jiangxi	Longquan	25.9106000	114.7860000	310700	2026-01-25 22:40:05.528262+00
2210	ZA	South Africa	Western Cape	Mitchells Plain	-34.0506000	18.6181000	310485	2026-01-25 22:40:05.528262+00
2211	JP	Japan	Mie	Yokkaichi	34.9650000	136.6244000	310263	2026-01-25 22:40:05.528262+00
2212	MX	Mexico	México	Chalco	19.2647000	-98.8975000	310130	2026-01-25 22:40:05.528262+00
2213	DE	Germany	Baden-Württemberg	Karlsruhe	49.0092000	8.4040000	309964	2026-01-25 22:40:05.528262+00
2214	IR	Iran	Tehrān	Shahrīār	35.6531000	51.0600000	309607	2026-01-25 22:40:05.528262+00
2215	IR	Iran	Tehrān	Shahr-e Qods	35.7103000	51.1131000	309605	2026-01-25 22:40:05.528262+00
2216	PY	Paraguay	Alto Paraná	Ciudad del Este	-25.5167000	-54.6161000	308983	2026-01-25 22:40:05.528262+00
2217	TZ	Tanzania	Tabora	Tabora	-5.0167000	32.8000000	308741	2026-01-25 22:40:05.528262+00
2218	MX	Mexico	Nuevo León	Ciudad Benito Juárez	25.6500000	-100.0833000	308285	2026-01-25 22:40:05.528262+00
2219	CN	China	Heilongjiang	Beian	48.2500000	126.5167000	308237	2026-01-25 22:40:05.528262+00
2220	US	United States	California	Irvine	33.6772000	-117.7738000	308160	2026-01-25 22:40:05.528262+00
2221	TJ	Tajikistan	Nohiyahoi Tobei Jumhurí	Hisor	38.5264000	68.5381000	308100	2026-01-25 22:40:05.528262+00
2222	KE	Kenya	Nakuru	Nakuru	-0.2833000	36.0667000	307990	2026-01-25 22:40:05.528262+00
2223	ID	Indonesia	Jawa Barat	Karawang	-6.3125000	107.2950000	307880	2026-01-25 22:40:05.528262+00
2224	KP	Korea, North	Hwangbuk	Sariwŏn	38.5064000	125.7597000	307764	2026-01-25 22:40:05.528262+00
2225	US	United States	Minnesota	St. Paul	44.9478000	-93.1039000	307762	2026-01-25 22:40:05.528262+00
2226	US	United States	New York	Poughkeepsie	41.6950000	-73.9211000	307738	2026-01-25 22:40:05.528262+00
2227	TR	Turkey	Malatya	Battalgazi	38.4228000	38.3656000	307478	2026-01-25 22:40:05.528262+00
2228	VN	Vietnam	Thanh Hóa	Nghi Sơn	19.4170000	105.7500000	307304	2026-01-25 22:40:05.528262+00
2229	CN	China	Jilin	Guangming	45.3333000	122.7833000	307215	2026-01-25 22:40:05.528262+00
2230	US	United States	New Jersey	Newark	40.7245000	-74.1725000	307188	2026-01-25 22:40:05.528262+00
2231	IN	India	Mahārāshtra	Parbhani	19.2700000	76.7800000	307170	2026-01-25 22:40:05.528262+00
2232	FR	France	Occitanie	Montpellier	43.6119000	3.8772000	307101	2026-01-25 22:40:05.528262+00
2233	PH	Philippines	Puerto Princesa	Puerto Princesa	9.7500000	118.7500000	307079	2026-01-25 22:40:05.528262+00
2234	IN	India	Haryāna	Hisar	29.1500000	75.7000000	307024	2026-01-25 22:40:05.528262+00
2235	BR	Brazil	Minas Gerais	Montes Claros	-16.7322000	-43.8636000	306947	2026-01-25 22:40:05.528262+00
2236	BR	Brazil	Minas Gerais	Betim	-19.9678000	-44.1978000	306675	2026-01-25 22:40:05.528262+00
2237	CA	Canada	Ontario	Windsor	42.2833000	-83.0000000	306519	2026-01-25 22:40:05.528262+00
2238	JP	Japan	Aichi	Kasugai	35.2475000	136.9722000	306449	2026-01-25 22:40:05.528262+00
2239	MX	Mexico	Nuevo León	Ciudad Santa Catarina	25.6833000	-100.4500000	306322	2026-01-25 22:40:05.528262+00
2240	IN	India	Rājasthān	Fatehpur	27.9800000	74.9500000	305638	2026-01-25 22:40:05.528262+00
2241	IN	India	Madhya Pradesh	Birania	27.9800000	74.9500000	305638	2026-01-25 22:40:05.528262+00
2242	MX	Mexico	Tamaulipas	Ciudad Victoria	23.7389000	-99.1431000	305155	2026-01-25 22:40:05.528262+00
2243	LT	Lithuania	Kauno Miestas	Kaunas	54.9000000	23.9333000	305120	2026-01-25 22:40:05.528262+00
2244	MX	Mexico	Quintana Roo	Playa del Carmen	20.6281000	-87.0755000	304942	2026-01-25 22:40:05.528262+00
2245	CN	China	Beijing	Yonghetun	39.9131000	116.6458000	304781	2026-01-25 22:40:05.528262+00
2246	IR	Iran	Eşfahān	Kāshān	33.9825000	51.4325000	304487	2026-01-25 22:40:05.528262+00
2247	MX	Mexico	México	La Peña	19.3606000	-98.9417000	304088	2026-01-25 22:40:05.528262+00
2248	TZ	Tanzania	Rukwa	Sumbawanga	-7.9667000	31.6167000	303986	2026-01-25 22:40:05.528262+00
2249	PT	Portugal	Porto	Vila Nova de Gaia	41.1333000	-8.6167000	303824	2026-01-25 22:40:05.528262+00
2250	RU	Russia	Orlovskaya Oblast’	Orël	52.9686000	36.0694000	303696	2026-01-25 22:40:05.528262+00
2251	RU	Russia	North Ossetia	Vladikavkaz	43.0400000	44.6775000	303597	2026-01-25 22:40:05.528262+00
2252	BR	Brazil	São Paulo	São Vicente	-23.9664000	-46.3861000	303551	2026-01-25 22:40:05.528262+00
2253	IN	India	Tamil Nādu	Kāraikkudi	10.0735000	78.7732000	303291	2026-01-25 22:40:05.528262+00
2254	DE	Germany	Bavaria	Augsburg	48.3689000	10.8978000	303150	2026-01-25 22:40:05.528262+00
2255	TJ	Tajikistan	Sughd	Panjakent	39.5000000	67.6167000	303000	2026-01-25 22:40:05.528262+00
2256	JP	Japan	Akita	Akita	39.7200000	140.1026000	302984	2026-01-25 22:40:05.528262+00
2257	IN	India	Rājasthān	Lachhmangarh Sīkar	27.8225000	75.0253000	302956	2026-01-25 22:40:05.528262+00
2258	JP	Japan	Fukuoka	Kurume	33.3192000	130.5083000	302858	2026-01-25 22:40:05.528262+00
2259	EG	Egypt	Ash Sharqīyah	Az Zaqāzīq	30.5667000	31.5000000	302840	2026-01-25 22:40:05.528262+00
2260	BR	Brazil	Tocantins	Palmas	-10.1886000	-48.3336000	302692	2026-01-25 22:40:05.528262+00
2261	AR	Argentina	Buenos Aires	Bahía Blanca	-38.7167000	-62.2667000	301572	2026-01-25 22:40:05.528262+00
2262	EG	Egypt	Qinā	Al Waqf	26.0866000	32.4226000	301486	2026-01-25 22:40:05.528262+00
2263	CL	Chile	Región Metropolitana	San Bernardo	-33.5833000	-70.7000000	301313	2026-01-25 22:40:05.528262+00
2264	MX	Mexico	Querétaro	San Juan del Río	20.3833000	-99.9833000	301237	2026-01-25 22:40:05.528262+00
2265	CO	Colombia	Quindío	Armenia	4.5300000	-75.6800000	301226	2026-01-25 22:40:05.528262+00
2266	CN	China	Hunan	Qianzhou	28.2760000	109.7120000	301000	2026-01-25 22:40:05.528262+00
2267	CO	Colombia	Cauca	Popayán	2.4542000	-76.6092000	300837	2026-01-25 22:40:05.528262+00
2268	ES	Spain	Castille-Leon	Valladolid	41.6528000	-4.7236000	300618	2026-01-25 22:40:05.528262+00
2269	SA	Saudi Arabia	Makkah al Mukarramah	Al Qunfudhah	19.1264000	41.0789000	300516	2026-01-25 22:40:05.528262+00
2270	TR	Turkey	Tekirdağ	Çorlu	41.1500000	27.8000000	300296	2026-01-25 22:40:05.528262+00
2271	CN	China	Shaanxi	Binxian	35.0542000	108.0814000	300226	2026-01-25 22:40:05.528262+00
2272	CN	China	Henan	Yakou	33.2950000	113.5269000	300200	2026-01-25 22:40:05.528262+00
2273	GB	United Kingdom	Newcastle upon Tyne	Newcastle	54.9780000	-1.6102000	300196	2026-01-25 22:40:05.528262+00
2274	IN	India	Puducherry	Oulgaret	11.9265000	79.7789000	300104	2026-01-25 22:40:05.528262+00
2275	ET	Ethiopia	Sīdama	Āwasa	7.0500000	38.4667000	300100	2026-01-25 22:40:05.528262+00
2276	IN	India	West Bengal	Ingrāj Bāzār	25.0119000	88.1433000	300088	2026-01-25 22:40:05.528262+00
2277	BR	Brazil	Mato Grosso	Várzea Grande	-15.6469000	-56.1328000	300078	2026-01-25 22:40:05.528262+00
2278	MX	Mexico	Oaxaca	Oaxaca	17.0606000	-96.7253000	300050	2026-01-25 22:40:05.528262+00
2279	BO	Bolivia	Chuquisaca	Sucre	-19.0475000	-65.2600000	300000	2026-01-25 22:40:05.528262+00
2280	CO	Colombia	Santander	Barrancabermeja	7.0667000	-73.8500000	300000	2026-01-25 22:40:05.528262+00
2281	EG	Egypt	Al Iskandarīyah	Al ‘Ajamī	31.1227000	29.7838000	300000	2026-01-25 22:40:05.528262+00
2282	EG	Egypt	Ad Daqahlīyah	Al Maţarīyah	31.1833000	32.0333000	300000	2026-01-25 22:40:05.528262+00
2283	IN	India	Odisha	Bada Barabīl	22.1200000	85.4000000	300000	2026-01-25 22:40:05.528262+00
2284	IQ	Iraq	Al Qādisīyah	Ash Shāmīyah	31.9625000	44.6008000	300000	2026-01-25 22:40:05.528262+00
2285	PK	Pakistan	Punjab	Khairpur Tamewah	29.5800000	72.2328000	300000	2026-01-25 22:40:05.528262+00
2286	UG	Uganda	Jinja	Jinja	0.4233000	33.2039000	300000	2026-01-25 22:40:05.528262+00
2287	US	United States	California	Santa Rosa	38.4458000	-122.7067000	299986	2026-01-25 22:40:05.528262+00
2288	SY	Syria	Ar Raqqah	Ar Raqqah	35.9304000	39.0200000	299824	2026-01-25 22:40:05.528262+00
2289	PK	Pakistan	Punjab	Chakwal	32.9303000	72.8556000	299751	2026-01-25 22:40:05.528262+00
2290	JP	Japan	Hyōgo	Ōakashichō	34.6500000	135.0000000	299699	2026-01-25 22:40:05.528262+00
2291	US	United States	New York	Oyster Bay	40.7846000	-73.5140000	299519	2026-01-25 22:40:05.528262+00
2292	UZ	Uzbekistan	Farg‘ona	Farg‘ona	40.3864000	71.7864000	299200	2026-01-25 22:40:05.528262+00
2293	TJ	Tajikistan	Nohiyahoi Tobei Jumhurí	Tursunzoda	38.5108000	68.2303000	298800	2026-01-25 22:40:05.528262+00
2294	RU	Russia	Vologodskaya Oblast’	Cherepovets	59.1167000	37.9000000	298790	2026-01-25 22:40:05.528262+00
2295	AR	Argentina	Chaco	Resistencia	-27.4514000	-58.9867000	298611	2026-01-25 22:40:05.528262+00
2296	ID	Indonesia	Jawa Timur	Jember	-8.1727000	113.6873000	298585	2026-01-25 22:40:05.528262+00
2297	SA	Saudi Arabia	Ash Sharqīyah	Al Mubarraz	25.4416000	49.6642000	298562	2026-01-25 22:40:05.528262+00
2298	ID	Indonesia	Jawa Tengah	Pekalongan	-6.8833000	109.6667000	298386	2026-01-25 22:40:05.528262+00
2299	MX	Mexico	Sinaloa	Los Mochis	25.7835000	-108.9937000	298009	2026-01-25 22:40:05.528262+00
2300	JP	Japan	Tōkyō	Toshima	35.7333000	139.7167000	297954	2026-01-25 22:40:05.528262+00
2301	MX	Mexico	Hidalgo	Pachuca	20.1000000	-98.7500000	297848	2026-01-25 22:40:05.528262+00
2302	KR	Korea, South	Gyeongnam	Yangsan	35.3333000	129.0333000	297532	2026-01-25 22:40:05.528262+00
2303	US	United States	North Carolina	Concord	35.3933000	-80.6369000	297379	2026-01-25 22:40:05.528262+00
2304	MX	Mexico	Tamaulipas	Tampico	22.2553000	-97.8686000	297284	2026-01-25 22:40:05.528262+00
2305	IN	India	Bihār	Bihār	25.1970000	85.5180000	297268	2026-01-25 22:40:05.528262+00
2306	MA	Morocco	Rabat-Salé-Kénitra	Temara	33.9267000	-6.9122000	297098	2026-01-25 22:40:05.528262+00
2307	GQ	Equatorial Guinea	Bioko Norte	Malabo	3.7456000	8.7744000	297000	2026-01-25 22:40:05.528262+00
2308	US	United States	Florida	Winter Haven	28.0118000	-81.7014000	296830	2026-01-25 22:40:05.528262+00
2309	CL	Chile	Valparaíso	Valparaíso	-33.0461000	-71.6197000	296655	2026-01-25 22:40:05.528262+00
2310	ID	Indonesia	Jawa Barat	Cirebon	-6.7071000	108.5574000	296389	2026-01-25 22:40:05.528262+00
2311	PH	Philippines	Davao del Norte	Tagum	7.4478000	125.8078000	296202	2026-01-25 22:40:05.528262+00
2312	TR	Turkey	İstanbul	Çekme	41.0369000	29.1786000	296066	2026-01-25 22:40:05.528262+00
2313	IN	India	Bihār	Darbhanga	26.1700000	85.9000000	296039	2026-01-25 22:40:05.528262+00
2314	BD	Bangladesh	Chattogram	Comilla	23.4500000	91.2000000	296010	2026-01-25 22:40:05.528262+00
2315	IN	India	Gujarāt	Idar	23.8390000	73.0020000	295971	2026-01-25 22:40:05.528262+00
2316	ID	Indonesia	Jawa Barat	Pondokaren	-6.2811000	106.7019000	295812	2026-01-25 22:40:05.528262+00
2317	ID	Indonesia	Papua Barat	Sorong	-0.8667000	131.2500000	295809	2026-01-25 22:40:05.528262+00
2318	EG	Egypt	Al Buḩayrah	Shubrākhīt	31.0279000	30.7149000	295777	2026-01-25 22:40:05.528262+00
2319	CO	Colombia	Santander	Floridablanca	7.2167000	-73.0667000	295724	2026-01-25 22:40:05.528262+00
2320	PH	Philippines	Cavite	Silang	14.2306000	120.9750000	295644	2026-01-25 22:40:05.528262+00
2321	SA	Saudi Arabia	Ar Riyāḑ	Al Kharj	24.1483000	47.3050000	295462	2026-01-25 22:40:05.528262+00
2322	SN	Senegal	Dakar	Rufisque	14.7140000	-17.2723000	295459	2026-01-25 22:40:05.528262+00
2323	EC	Ecuador	Guayas	Eloy Alfaro	-2.1733000	-79.8311000	295211	2026-01-25 22:40:05.528262+00
2324	US	United States	North Carolina	Asheville	35.5707000	-82.5537000	295040	2026-01-25 22:40:05.528262+00
2325	IN	India	Uttar Pradesh	Sikandarābād	28.4512000	77.6955000	294858	2026-01-25 22:40:05.528262+00
2326	GB	United Kingdom	Stockport	Stockport	53.4083000	-2.1494000	294773	2026-01-25 22:40:05.528262+00
2327	EG	Egypt	Ash Sharqīyah	Kafr Şaqr	30.7934000	31.6257000	294765	2026-01-25 22:40:05.528262+00
2328	CI	Côte d’Ivoire	Gôh-Djiboua	Divo	5.8372000	-5.3572000	294559	2026-01-25 22:40:05.528262+00
2329	AO	Angola	Huambo	Vila Teixeira da Silva	-12.1958000	15.8556000	294494	2026-01-25 22:40:05.528262+00
2330	TR	Turkey	Bursa	İnegöl	40.0806000	29.5097000	294485	2026-01-25 22:40:05.528262+00
2331	ZA	South Africa	Western Cape	Paarl	-33.7242000	18.9558000	294457	2026-01-25 22:40:05.528262+00
2332	BD	Bangladesh	Rangpur	Rangpur	25.7500000	89.2444000	294265	2026-01-25 22:40:05.528262+00
2333	PL	Poland	Podlaskie	Białystok	53.1353000	23.1456000	294242	2026-01-25 22:40:05.528262+00
2334	ES	Spain	Galicia	Vigo	42.2314000	-8.7124000	293977	2026-01-25 22:40:05.528262+00
2335	TR	Turkey	Trabzon	Trabzon	41.0050000	39.7225000	293661	2026-01-25 22:40:05.528262+00
2336	US	United States	Ohio	Canton	40.8078000	-81.3676000	293657	2026-01-25 22:40:05.528262+00
2337	MX	Mexico	México	Coacalco	19.6333000	-99.0931000	293444	2026-01-25 22:40:05.528262+00
2338	IN	India	Mizoram	Āīzawl	23.7272000	92.7178000	293416	2026-01-25 22:40:05.528262+00
2339	IN	India	West Bengal	Bāli	22.6500000	88.3400000	293373	2026-01-25 22:40:05.528262+00
2340	GB	United Kingdom	Bradford	Bradford	53.8000000	-1.7500000	293277	2026-01-25 22:40:05.528262+00
2341	PH	Philippines	Pampanga	Mabalacat	15.2200000	120.5800000	293244	2026-01-25 22:40:05.528262+00
2342	CN	China	Jiangxi	Dexing	28.9306000	117.5947000	293201	2026-01-25 22:40:05.528262+00
2343	US	United States	Nebraska	Lincoln	40.8099000	-96.6784000	293055	2026-01-25 22:40:05.528262+00
2344	CN	China	Heilongjiang	Hailin	44.5940000	129.3800000	292755	2026-01-25 22:40:05.528262+00
2345	AT	Austria	Steiermark	Graz	47.0708000	15.4386000	292630	2026-01-25 22:40:05.528262+00
2346	FR	France	Grand Est	Strasbourg	48.5833000	7.7458000	291709	2026-01-25 22:40:05.528262+00
2347	US	United States	Michigan	Flint	43.0236000	-83.6921000	291688	2026-01-25 22:40:05.528262+00
2348	RU	Russia	Chechnya	Groznyy	43.3125000	45.6986000	291687	2026-01-25 22:40:05.528262+00
2349	ZA	South Africa	North West	Mahikeng	-25.8656000	25.6436000	291527	2026-01-25 22:40:05.528262+00
2350	PE	Peru	Ancash	Chimbote	-9.0745000	-78.5936000	291408	2026-01-25 22:40:05.528262+00
2351	NO	Norway	Vestland	Bergen	60.3925000	5.3233000	291189	2026-01-25 22:40:05.528262+00
2352	CA	Canada	Quebec	Gatineau	45.4833000	-75.6500000	291041	2026-01-25 22:40:05.528262+00
2353	IN	India	Bihār	Surajgarha	25.2500000	86.2300000	290998	2026-01-25 22:40:05.528262+00
2354	US	United States	Florida	Lakeland	28.0557000	-81.9545000	290762	2026-01-25 22:40:05.528262+00
2355	DZ	Algeria	Batna	Batna	35.5500000	6.1667000	290645	2026-01-25 22:40:05.528262+00
2356	SV	El Salvador	San Miguel	San Miguel	13.4814000	-88.1775000	290612	2026-01-25 22:40:05.528262+00
2357	DK	Denmark	Midtjylland	Aarhus	56.1572000	10.2107000	290598	2026-01-25 22:40:05.528262+00
2358	JP	Japan	Iwate	Morioka	39.7021000	141.1545000	290553	2026-01-25 22:40:05.528262+00
2359	CN	China	Heilongjiang	Hong’an	47.2100000	123.6100000	289999	2026-01-25 22:40:05.528262+00
2360	IN	India	Tamil Nādu	Nāgercoil	8.1750000	77.4306000	289916	2026-01-25 22:40:05.528262+00
2361	PH	Philippines	Bulacan	Santa Maria	14.8200000	120.9600000	289820	2026-01-25 22:40:05.528262+00
2362	RU	Russia	Tambovskaya Oblast’	Tambov	52.7231000	41.4539000	289701	2026-01-25 22:40:05.528262+00
2363	US	United States	New Jersey	Jersey City	40.7184000	-74.0686000	289691	2026-01-25 22:40:05.528262+00
2364	IN	India	Madhya Pradesh	Dewās	22.9600000	76.0600000	289550	2026-01-25 22:40:05.528262+00
2365	KE	Kenya	Uasin Gishu	Eldoret	0.5167000	35.2833000	289380	2026-01-25 22:40:05.528262+00
2366	GB	United Kingdom	Nottingham	Nottingham	52.9561000	-1.1512000	289301	2026-01-25 22:40:05.528262+00
2367	MM	Burma	Magway	Magway	20.1500000	94.9500000	289247	2026-01-25 22:40:05.528262+00
2368	US	United States	Alaska	Anchorage	61.1508000	-149.1091000	289069	2026-01-25 22:40:05.528262+00
2369	US	United States	Missouri	Springfield	37.1943000	-93.2916000	289041	2026-01-25 22:40:05.528262+00
2370	AR	Argentina	Neuquén	Neuquén	-38.9525000	-68.0642000	288896	2026-01-25 22:40:05.528262+00
2371	TR	Turkey	İstanbul	Tuzla	40.8161000	29.3006000	288878	2026-01-25 22:40:05.528262+00
2372	ZM	Zambia	Central	Kabwe	-14.4333000	28.4500000	288598	2026-01-25 22:40:05.528262+00
2373	VE	Venezuela	Zulia	Cabimas	10.4000000	-71.4500000	288595	2026-01-25 22:40:05.528262+00
2374	DZ	Algeria	Sétif	Sétif	36.1900000	5.4100000	288461	2026-01-25 22:40:05.528262+00
2375	IN	India	Bihār	Sonpur	25.7000000	85.1800000	288102	2026-01-25 22:40:05.528262+00
2376	IN	India	West Bengal	Hugli	22.9000000	88.3900000	288090	2026-01-25 22:40:05.528262+00
2377	IN	India	West Bengal	Chunchura	22.9000000	88.3900000	288090	2026-01-25 22:40:05.528262+00
2378	JP	Japan	Tōkyō	Meguro	35.6333000	139.6833000	288088	2026-01-25 22:40:05.528262+00
2379	BR	Brazil	Goiás	Anápolis	-16.3269000	-48.9528000	288085	2026-01-25 22:40:05.528262+00
2380	EC	Ecuador	El Oro	Machala	-3.2667000	-79.9667000	288072	2026-01-25 22:40:05.528262+00
2381	PY	Paraguay	Central	San Lorenzo	-25.3400000	-57.5200000	287977	2026-01-25 22:40:05.528262+00
2382	BR	Brazil	São Paulo	Franca	-20.5389000	-47.4008000	287737	2026-01-25 22:40:05.528262+00
2383	VN	Vietnam	Bắc Ninh	Bắc Ninh	21.1833000	106.0500000	287658	2026-01-25 22:40:05.528262+00
2384	IN	India	Mahārāshtra	Ichalkaranji	16.7000000	74.4700000	287570	2026-01-25 22:40:05.528262+00
2385	IN	India	Andhra Pradesh	Tirupati	13.6500000	79.4200000	287482	2026-01-25 22:40:05.528262+00
2386	US	United States	Texas	Plano	33.0502000	-96.7486000	287339	2026-01-25 22:40:05.528262+00
2387	MM	Burma	Ayeyarwady	Pathein	16.7842000	94.7333000	287071	2026-01-25 22:40:05.528262+00
2388	CO	Colombia	Sucre	Sincelejo	9.2950000	-75.3961000	286716	2026-01-25 22:40:05.528262+00
2389	RO	Romania	Cluj	Cluj-Napoca	46.7667000	23.5833000	286598	2026-01-25 22:40:05.528262+00
2390	TZ	Tanzania	Ruvuma	Songea	-10.6833000	35.6500000	286285	2026-01-25 22:40:05.528262+00
2391	PE	Peru	Tacna	Tacna	-18.0147000	-70.2489000	286240	2026-01-25 22:40:05.528262+00
2392	HK	Hong Kong	\N	Tin Shui Wai	22.4600000	114.0020000	286232	2026-01-25 22:40:05.528262+00
2393	BR	Brazil	Ceará	Juazeiro do Norte	-7.2128000	-39.3150000	286120	2026-01-25 22:40:05.528262+00
2394	IQ	Iraq	Al Başrah	Al Qurnah	31.0155000	47.4336000	286073	2026-01-25 22:40:05.528262+00
2395	IN	India	Punjab	Bhatinda	30.2300000	74.9519000	285813	2026-01-25 22:40:05.528262+00
2396	PL	Poland	Śląskie	Katowice	50.2625000	19.0217000	285711	2026-01-25 22:40:05.528262+00
2397	DE	Germany	Hesse	Wiesbaden	50.0825000	8.2400000	285522	2026-01-25 22:40:05.528262+00
2398	UG	Uganda	Masaka	Masaka	-0.3411000	31.7361000	285509	2026-01-25 22:40:05.528262+00
2399	BR	Brazil	Paraná	Foz do Iguaçu	-25.5400000	-54.5875000	285415	2026-01-25 22:40:05.528262+00
2400	GB	United Kingdom	Bolton	Bolton	53.5783000	-2.4300000	285372	2026-01-25 22:40:05.528262+00
2401	PH	Philippines	Laguna	San Pablo	14.0700000	121.3250000	285348	2026-01-25 22:40:05.528262+00
2402	MX	Mexico	México	Huixquilucan	19.3611000	-99.3508000	284965	2026-01-25 22:40:05.528262+00
2403	EG	Egypt	Kafr ash Shaykh	Qillīn	31.0475000	30.8549000	284853	2026-01-25 22:40:05.528262+00
2404	HT	Haiti	Ouest	Croix-des-Bouquets	18.5761000	-72.2269000	284812	2026-01-25 22:40:05.528262+00
2405	GT	Guatemala	Guatemala	San Juan Sacatepéquez	14.7189000	-90.6442000	284798	2026-01-25 22:40:05.528262+00
2406	CZ	Czechia	Moravskoslezský Kraj	Ostrava	49.8356000	18.2925000	284765	2026-01-25 22:40:05.528262+00
2407	SV	El Salvador	San Salvador	Soyapango	13.7333000	-89.1500000	284659	2026-01-25 22:40:05.528262+00
2408	SI	Slovenia	Ljubljana	Ljubljana	46.0514000	14.5061000	284293	2026-01-25 22:40:05.528262+00
2409	JP	Japan	Fukushima	Fukushima	37.7608000	140.4747000	284282	2026-01-25 22:40:05.528262+00
2410	MM	Burma	Bago	Bago	17.3333000	96.4833000	284179	2026-01-25 22:40:05.528262+00
2411	HT	Haiti	Ouest	Delmas	18.5500000	-72.3000000	284079	2026-01-25 22:40:05.528262+00
2412	CN	China	Guizhou	Fuquan	26.6863000	107.5204000	283904	2026-01-25 22:40:05.528262+00
2413	JP	Japan	Ōsaka	Ibaraki	34.8164000	135.5686000	283835	2026-01-25 22:40:05.528262+00
2414	RU	Russia	Khanty-Mansiyskiy Avtonomnyy Okrug-Yugra	Nizhnevartovsk	60.9500000	76.6000000	283256	2026-01-25 22:40:05.528262+00
2415	US	United States	Texas	Lubbock	33.5657000	-101.8879000	283024	2026-01-25 22:40:05.528262+00
2416	IN	India	Madhya Pradesh	Satna	24.6005000	80.8322000	283004	2026-01-25 22:40:05.528262+00
2417	VE	Venezuela	Táchira	San Cristóbal	7.7667000	-72.2333000	282830	2026-01-25 22:40:05.528262+00
2418	UA	Ukraine	Chernihivska Oblast	Chernihiv	51.4939000	31.2947000	282747	2026-01-25 22:40:05.528262+00
2419	TR	Turkey	İstanbul	Güngören	41.0225000	28.8717000	282692	2026-01-25 22:40:05.528262+00
2420	CL	Chile	Araucanía	Temuco	-38.7333000	-72.6667000	282415	2026-01-25 22:40:05.528262+00
2421	PE	Peru	Ica	Ica	-14.0667000	-75.7333000	282407	2026-01-25 22:40:05.528262+00
2422	US	United States	Iowa	Davenport	41.5565000	-90.6053000	282356	2026-01-25 22:40:05.528262+00
2423	TH	Thailand	Phitsanulok	Phitsanulok	16.8158000	100.2636000	281929	2026-01-25 22:40:05.528262+00
2424	PK	Pakistan	Punjab	Khanewal	30.3000000	71.9333000	281890	2026-01-25 22:40:05.528262+00
2425	CN	China	Inner Mongolia	Jining	41.0300000	113.0800000	281716	2026-01-25 22:40:05.528262+00
2426	KR	Korea, South	Gangwon	Chuncheon	37.8667000	127.7333000	281596	2026-01-25 22:40:05.528262+00
2427	TR	Turkey	Sakarya	Sakarya	40.7833000	30.4000000	281489	2026-01-25 22:40:05.528262+00
2428	NG	Nigeria	Zamfara	Kaura Namoda	12.6000000	6.5897000	281367	2026-01-25 22:40:05.528262+00
2429	IR	Iran	Tehrān	Malārd	35.6806000	50.9783000	281027	2026-01-25 22:40:05.528262+00
2430	UZ	Uzbekistan	Buxoro	Bukhara	39.7667000	64.4231000	280187	2026-01-25 22:40:05.528262+00
2431	US	United States	Pennsylvania	Reading	40.3400000	-75.9267000	280030	2026-01-25 22:40:05.528262+00
2432	PK	Pakistan	Punjab	Marot	28.5100000	71.5000000	280000	2026-01-25 22:40:05.528262+00
2433	AO	Angola	Cuanza-Sul	Sumbe	-11.2053000	13.8417000	279968	2026-01-25 22:40:05.528262+00
2434	PK	Pakistan	Khyber Pakhtunkhwa	Mingaora	34.7717000	72.3600000	279914	2026-01-25 22:40:05.528262+00
2435	AO	Angola	Huambo	Caála	-12.8500000	15.5500000	279792	2026-01-25 22:40:05.528262+00
2436	UA	Ukraine	Poltavska Oblast	Poltava	49.5894000	34.5514000	279593	2026-01-25 22:40:05.528262+00
2437	RU	Russia	Kareliya	Petrozavodsk	61.7833000	34.3333000	279190	2026-01-25 22:40:05.528262+00
2438	UA	Ukraine	Khersonska Oblast	Kherson	46.6425000	32.6250000	279131	2026-01-25 22:40:05.528262+00
2439	PH	Philippines	Lucena	Lucena	13.9300000	121.6200000	278924	2026-01-25 22:40:05.528262+00
2440	BR	Brazil	Rio de Janeiro	Petrópolis	-22.5050000	-43.1789000	278881	2026-01-25 22:40:05.528262+00
2441	ID	Indonesia	Sulawesi Barat	Mamuju	-2.6833000	118.9000000	278764	2026-01-25 22:40:05.528262+00
2442	IN	India	Uttar Pradesh	Mau	25.9417000	83.5611000	278745	2026-01-25 22:40:05.528262+00
2443	VN	Vietnam	An Giang	Long Xuyên	10.3736000	105.4458000	278658	2026-01-25 22:40:05.528262+00
2444	KR	Korea, South	Gyeongbuk	Gyeongsan	35.8167000	128.7333000	278500	2026-01-25 22:40:05.528262+00
2445	IN	India	West Bengal	Bārāsat	22.7200000	88.4800000	278435	2026-01-25 22:40:05.528262+00
2446	UZ	Uzbekistan	Qashqadaryo	Qarshi	38.8667000	65.8000000	278300	2026-01-25 22:40:05.528262+00
2447	US	United States	Louisiana	Shreveport	32.4653000	-93.7955000	278269	2026-01-25 22:40:05.528262+00
2448	US	United States	Arizona	Chandler	33.2825000	-111.8514000	278123	2026-01-25 22:40:05.528262+00
2449	ID	Indonesia	Sumatera Utara	Pematangsiantar	2.9600000	99.0600000	278055	2026-01-25 22:40:05.528262+00
2450	GB	United Kingdom	Sunderland	Sunderland	54.9060000	-1.3810000	277417	2026-01-25 22:40:05.528262+00
2451	RU	Russia	Bashkortostan	Sterlitamak	53.6333000	55.9500000	277410	2026-01-25 22:40:05.528262+00
2452	SV	El Salvador	Santa Ana	Santa Ana	13.9950000	-89.5561000	277264	2026-01-25 22:40:05.528262+00
2453	TR	Turkey	İstanbul	Büyükçekmece	41.0200000	28.5775000	277181	2026-01-25 22:40:05.528262+00
2454	CI	Côte d’Ivoire	Gôh-Djiboua	Gagnoa	6.1333000	-5.9333000	277044	2026-01-25 22:40:05.528262+00
2455	CN	China	Hunan	Xingsha	28.2573000	113.1234000	277034	2026-01-25 22:40:05.528262+00
2456	ET	Ethiopia	Dirē Dawa	Dire Dawa	9.6000000	41.8667000	277000	2026-01-25 22:40:05.528262+00
2457	AF	Afghanistan	Helmand	Lashkar Gāh	31.5831000	64.3692000	276831	2026-01-25 22:40:05.528262+00
2458	CO	Colombia	Antioquia	Itagüí	6.1667000	-75.6167000	276744	2026-01-25 22:40:05.528262+00
2459	PE	Peru	Puno	Juliaca	-15.4833000	-70.1333000	276110	2026-01-25 22:40:05.528262+00
2460	AR	Argentina	Misiones	Posadas	-27.3667000	-55.9000000	275988	2026-01-25 22:40:05.528262+00
2461	ID	Indonesia	Jawa Tengah	Tegal	-6.8675000	109.1375000	275789	2026-01-25 22:40:05.528262+00
2462	IN	India	Uttar Pradesh	Farrukhābād	27.3900000	79.5810000	275754	2026-01-25 22:40:05.528262+00
2463	US	United States	Indiana	South Bend	41.6767000	-86.2696000	275725	2026-01-25 22:40:05.528262+00
2464	RU	Russia	Moskovskaya Oblast’	Mytishchi	55.9167000	37.7667000	275313	2026-01-25 22:40:05.528262+00
2465	KR	Korea, South	Jeonbuk	Kunsan	35.9833000	126.7167000	275155	2026-01-25 22:40:05.528262+00
2466	US	United States	North Carolina	Wilmington	34.2099000	-77.8866000	275128	2026-01-25 22:40:05.528262+00
2467	US	United States	California	Chula Vista	32.6281000	-117.0144000	275030	2026-01-25 22:40:05.528262+00
2468	RU	Russia	Mariy-El	Yoshkar-Ola	56.6500000	47.8833000	274715	2026-01-25 22:40:05.528262+00
2469	IN	India	Madhya Pradesh	Saugor	23.8300000	78.7100000	274556	2026-01-25 22:40:05.528262+00
2470	UA	Ukraine	Khmelnytska Oblast	Khmelnytskyi	49.4167000	27.0000000	274452	2026-01-25 22:40:05.528262+00
2471	IN	India	Uttar Pradesh	Khorabar	26.7410000	83.8880000	274403	2026-01-25 22:40:05.528262+00
2472	BS	Bahamas, The	\N	Nassau	25.0442000	-77.3503000	274400	2026-01-25 22:40:05.528262+00
2473	US	United States	Illinois	Rockford	42.2596000	-89.0640000	274256	2026-01-25 22:40:05.528262+00
2474	TJ	Tajikistan	Sughd	Isfara	40.1167000	70.6333000	274000	2026-01-25 22:40:05.528262+00
2475	IN	India	Madhya Pradesh	Ratlām	23.3340000	75.0370000	273892	2026-01-25 22:40:05.528262+00
2476	PK	Pakistan	Sindh	Mehrabpur	27.0994000	68.4208000	273764	2026-01-25 22:40:05.528262+00
2477	KR	Korea, South	Jeonnam	Yeosu	34.7607000	127.6622000	273761	2026-01-25 22:40:05.528262+00
2478	CN	China	Fujian	Shaowu	27.3403000	117.4925000	273721	2026-01-25 22:40:05.528262+00
2479	BR	Brazil	Paraná	Ponta Grossa	-25.0950000	-50.1619000	273616	2026-01-25 22:40:05.528262+00
2480	BR	Brazil	São Paulo	Taboão da Serra	-23.6019000	-46.7528000	273542	2026-01-25 22:40:05.528262+00
2481	TJ	Tajikistan	Sughd	Istaravshan	39.9108000	69.0064000	273500	2026-01-25 22:40:05.528262+00
2482	PH	Philippines	Rizal	San Mateo	14.6969000	121.1219000	273306	2026-01-25 22:40:05.528262+00
2483	JP	Japan	Mie	Tsu	34.7331000	136.5133000	273267	2026-01-25 22:40:05.528262+00
2484	BR	Brazil	Maranhão	Imperatriz	-5.5258000	-47.4758000	273110	2026-01-25 22:40:05.528262+00
2485	CN	China	Shanxi	Huozhou	36.5690000	111.7551000	272987	2026-01-25 22:40:05.528262+00
2486	DO	Dominican Republic	Ozama	Los Alcarrizos	18.5167000	-70.0167000	272776	2026-01-25 22:40:05.528262+00
2487	CI	Côte d’Ivoire	Bas-Sassandra	Soubré	5.7836000	-6.5939000	272773	2026-01-25 22:40:05.528262+00
2488	US	United States	Oregon	Eugene	44.0564000	-123.1174000	272737	2026-01-25 22:40:05.528262+00
2489	IR	Iran	Āz̄arbāyjān-e Sharqī	Marāgheh	37.3894000	46.2378000	272400	2026-01-25 22:40:05.528262+00
2490	ID	Indonesia	Sulawesi Barat	Majene	-3.5403000	118.9707000	272377	2026-01-25 22:40:05.528262+00
2491	CN	China	Sichuan	Huilong	30.3866000	106.7756000	272332	2026-01-25 22:40:05.528262+00
2492	US	United States	Oregon	Salem	44.9233000	-123.0244000	272331	2026-01-25 22:40:05.528262+00
2493	JP	Japan	Tōkyō	Sumida	35.7000000	139.8167000	272085	2026-01-25 22:40:05.528262+00
2494	AO	Angola	Cuanza-Sul	Gabela	-10.8500000	14.3667000	271843	2026-01-25 22:40:05.528262+00
2495	SY	Syria	Dayr az Zawr	Dayr az Zawr	35.3304000	40.1300000	271800	2026-01-25 22:40:05.528262+00
2496	RO	Romania	Iaşi	Iaşi	47.1622000	27.5889000	271692	2026-01-25 22:40:05.528262+00
2497	IR	Iran	Māzandarān	Sartā	36.4486000	53.3233000	271467	2026-01-25 22:40:05.528262+00
2498	US	United States	Arizona	Gilbert	33.3100000	-111.7463000	271118	2026-01-25 22:40:05.528262+00
2499	CN	China	Jilin	Da’an	45.5000000	124.2833000	270911	2026-01-25 22:40:05.528262+00
2500	US	United States	Nevada	North Las Vegas	36.2883000	-115.0888000	270773	2026-01-25 22:40:05.528262+00
2501	KR	Korea, South	Jeonbuk	Iksan	35.9439000	126.9544000	270758	2026-01-25 22:40:05.528262+00
2502	VN	Vietnam	Tiền Giang	Mỹ Tho	10.3500000	106.3500000	270700	2026-01-25 22:40:05.528262+00
2503	NG	Nigeria	Yobe	Nguru	12.8792000	10.4525000	270632	2026-01-25 22:40:05.528262+00
2504	JP	Japan	Ibaraki	Mito	36.3658000	140.4712000	270445	2026-01-25 22:40:05.528262+00
2505	KR	Korea, South	Gyeonggi	Kunp’o	37.3500000	126.9500000	270443	2026-01-25 22:40:05.528262+00
2506	CN	China	Guangdong	Bijiao	22.9253000	113.2067000	270310	2026-01-25 22:40:05.528262+00
2507	UA	Ukraine	Cherkaska Oblast	Cherkasy	49.4444000	32.0597000	269836	2026-01-25 22:40:05.528262+00
2508	TR	Turkey	Çorum	Bayat	40.5455000	34.9570000	269595	2026-01-25 22:40:05.528262+00
2509	TR	Turkey	Çorum	Çorum	40.5455000	34.9570000	269595	2026-01-25 22:40:05.528262+00
2510	IN	India	Jammu and Kashmīr	Handwāra	34.3997000	74.2817000	269311	2026-01-25 22:40:05.528262+00
2511	ID	Indonesia	Sumatera Utara	Binjai	3.5986000	98.4803000	269053	2026-01-25 22:40:05.528262+00
2512	DE	Germany	North Rhine-Westphalia	Mönchengladbach	51.2000000	6.4333000	268943	2026-01-25 22:40:05.528262+00
2513	AF	Afghanistan	Kunduz	Kunduz	36.7286000	68.8681000	268893	2026-01-25 22:40:05.528262+00
2514	AR	Argentina	Entre Ríos	Paraná	-31.7331000	-60.5297000	268889	2026-01-25 22:40:05.528262+00
2515	KR	Korea, South	Jeonnam	Yeosu	34.7333000	127.7333000	268823	2026-01-25 22:40:05.528262+00
2516	IN	India	Chhattīsgarh	Drug	21.1900000	81.2800000	268806	2026-01-25 22:40:05.528262+00
2517	PK	Pakistan	Balochistan	Turbat	26.0042000	63.0606000	268625	2026-01-25 22:40:05.528262+00
2518	ES	Spain	Asturias	Gijón	43.5333000	-5.7000000	268561	2026-01-25 22:40:05.528262+00
2519	BD	Bangladesh	Chattogram	Brāhmanbāria	23.9723000	91.1099000	268279	2026-01-25 22:40:05.528262+00
2520	VN	Vietnam	Thái Bình	Thái Bình	20.4461000	106.3422000	268167	2026-01-25 22:40:05.528262+00
2521	JP	Japan	Chiba	Ichihara	35.4981000	140.1154000	268038	2026-01-25 22:40:05.528262+00
2522	BO	Bolivia	Tarija	Tarija	-21.5333000	-64.7333000	268000	2026-01-25 22:40:05.528262+00
2523	EG	Egypt	Al Minūfīyah	Shibīn al Kawm	30.5500000	31.0000000	267945	2026-01-25 22:40:05.528262+00
2524	TR	Turkey	Şanlıurfa	Siverek	37.7500000	39.3167000	267942	2026-01-25 22:40:05.528262+00
2525	GB	United Kingdom	Plymouth	Plymouth	50.3714000	-4.1422000	267918	2026-01-25 22:40:05.528262+00
2526	EG	Egypt	Aswān	Aswān	24.0889000	32.8997000	267913	2026-01-25 22:40:05.528262+00
2527	BO	Bolivia	Potosí	Potosí	-19.5892000	-65.7533000	267907	2026-01-25 22:40:05.528262+00
2528	CN	China	Heilongjiang	Hulin	45.7667000	132.9333000	267870	2026-01-25 22:40:05.528262+00
2529	RU	Russia	Kostromskaya Oblast’	Kostroma	57.7681000	40.9269000	267481	2026-01-25 22:40:05.528262+00
2530	RU	Russia	Murmanskaya Oblast’	Murmansk	68.9706000	33.0750000	267422	2026-01-25 22:40:05.528262+00
2531	NE	Niger	Maradi	Maradi	13.5010000	7.1036000	267249	2026-01-25 22:40:05.528262+00
2532	LA	Laos	Xiangkhouang	Xiangkhoang	19.4167000	103.5000000	267172	2026-01-25 22:40:05.528262+00
2533	IN	India	Andhra Pradesh	Anantapur	14.6800000	77.5990000	267161	2026-01-25 22:40:05.528262+00
2534	TR	Turkey	Mardin	Kızıltepe	37.1939000	40.5861000	267151	2026-01-25 22:40:05.528262+00
2535	TR	Turkey	Adıyaman	Adıyaman	37.7639000	38.2778000	267131	2026-01-25 22:40:05.528262+00
2536	ZA	South Africa	Eastern Cape	East London	-33.0175000	27.9047000	267007	2026-01-25 22:40:05.528262+00
2537	CA	Canada	Saskatchewan	Saskatoon	52.1333000	-106.6833000	266141	2026-01-25 22:40:05.528262+00
2538	BR	Brazil	São Paulo	Sumaré	-22.8219000	-47.2669000	265955	2026-01-25 22:40:05.528262+00
2539	DE	Germany	North Rhine-Westphalia	Gelsenkirchen	51.5167000	7.1000000	265885	2026-01-25 22:40:05.528262+00
2540	JP	Japan	Niigata	Nagaoka	37.4462000	138.8512000	265868	2026-01-25 22:40:05.528262+00
2541	PK	Pakistan	Khyber Pakhtunkhwa	Khwazakhela	34.9333000	72.4667000	265571	2026-01-25 22:40:05.528262+00
2542	US	United States	California	Santa Clarita	34.4175000	-118.4964000	265529	2026-01-25 22:40:05.528262+00
2543	KR	Korea, South	Jeonnam	Suncheon	34.9506000	127.4875000	265390	2026-01-25 22:40:05.528262+00
2544	TZ	Tanzania	Coast	Kibaha	-6.7667000	38.9167000	265360	2026-01-25 22:40:05.528262+00
2545	RU	Russia	Kabardino-Balkariya	Nalchik	43.4833000	43.6167000	265162	2026-01-25 22:40:05.528262+00
2546	BE	Belgium	Flanders	Gent	51.0536000	3.7253000	265086	2026-01-25 22:40:05.528262+00
2547	TR	Turkey	Şanlıurfa	Karaköprü	37.1847000	38.7908000	265035	2026-01-25 22:40:05.528262+00
2548	MG	Madagascar	Antananarivo	Antsirabe	-19.8667000	47.0333000	265018	2026-01-25 22:40:05.528262+00
2549	BD	Bangladesh	Chattogram	Feni	23.0150000	91.3967000	265000	2026-01-25 22:40:05.528262+00
2550	IN	India	Manipur	Imphāl	24.8074000	93.9384000	264986	2026-01-25 22:40:05.528262+00
2551	MM	Burma	Shan State	Taunggyi	20.7836000	97.0354000	264804	2026-01-25 22:40:05.528262+00
2552	MX	Mexico	Sonora	Nogales	31.3000000	-110.9333000	264782	2026-01-25 22:40:05.528262+00
2553	SD	Sudan	East Darfur	Ed Daein	11.4672000	26.1317000	264734	2026-01-25 22:40:05.528262+00
2554	IR	Iran	Khūzestān	Dezfūl	32.3786000	48.4144000	264709	2026-01-25 22:40:05.528262+00
2555	BR	Brazil	Rio Grande do Norte	Mossoró	-5.1878000	-37.3439000	264577	2026-01-25 22:40:05.528262+00
2556	GB	United Kingdom	Milton Keynes	Milton Keynes	52.0400000	-0.7600000	264349	2026-01-25 22:40:05.528262+00
2557	UA	Ukraine	Chernivetska Oblast	Chernivtsi	48.3000000	25.9333000	264298	2026-01-25 22:40:05.528262+00
2558	ID	Indonesia	Riau	Dumai	1.6667000	101.4500000	264084	2026-01-25 22:40:05.528262+00
2559	BR	Brazil	Santa Catarina	Itajaí	-26.9078000	-48.6619000	264054	2026-01-25 22:40:05.528262+00
2560	TR	Turkey	Kütahya	Kütahya	39.4167000	29.9833000	263863	2026-01-25 22:40:05.528262+00
2561	RO	Romania	Constanţa	Constanţa	44.1667000	28.6333000	263707	2026-01-25 22:40:05.528262+00
2562	PY	Paraguay	Central	Luque	-25.2672000	-57.4853000	263604	2026-01-25 22:40:05.528262+00
2563	JP	Japan	Nara	Yao	34.6269000	135.6010000	263436	2026-01-25 22:40:05.528262+00
2564	AF	Afghanistan	Nangarhār	Jalālābād	34.4342000	70.4478000	263312	2026-01-25 22:40:05.528262+00
2565	TW	Taiwan	Chiayi	Chiayi	23.4800000	120.4497000	263188	2026-01-25 22:40:05.528262+00
2566	PK	Pakistan	Sindh	Nawabshah	26.2442000	68.4100000	263102	2026-01-25 22:40:05.528262+00
2567	PH	Philippines	Cebu	Talisay	10.2500000	123.8300000	263048	2026-01-25 22:40:05.528262+00
2568	CG	Congo (Brazzaville)	Kouilou	Tchibota	-4.1794000	11.3731000	262931	2026-01-25 22:40:05.528262+00
2569	AO	Angola	Huíla	Matala	-14.7306000	15.0367000	262763	2026-01-25 22:40:05.528262+00
2570	US	United States	Illinois	Peoria	40.7520000	-89.6154000	262461	2026-01-25 22:40:05.528262+00
2571	AR	Argentina	Buenos Aires	Quilmes	-34.7167000	-58.2667000	262379	2026-01-25 22:40:05.528262+00
2572	RU	Russia	Krasnodarskiy Kray	Novorossiysk	44.7167000	37.7833000	261937	2026-01-25 22:40:05.528262+00
2573	AU	Australia	New South Wales	Wollongong	-34.4331000	150.8831000	261896	2026-01-25 22:40:05.528262+00
2574	UA	Ukraine	Zhytomyrska Oblast	Zhytomyr	50.2500000	28.6667000	261624	2026-01-25 22:40:05.528262+00
2575	JP	Japan	Fukui	Fukui	36.0641000	136.2196000	261474	2026-01-25 22:40:05.528262+00
2576	IN	India	Bihār	Arrah	25.5514000	84.6603000	261430	2026-01-25 22:40:05.528262+00
2577	US	United States	Florida	Tallahassee	30.4551000	-84.2527000	261271	2026-01-25 22:40:05.528262+00
2578	PH	Philippines	Bulacan	Malolos	14.8436000	120.8114000	261189	2026-01-25 22:40:05.528262+00
2579	MX	Mexico	Sonora	Heroica Nogales	31.3186000	-110.9458000	261137	2026-01-25 22:40:05.528262+00
2580	US	United States	Texas	Killeen	31.0753000	-97.7297000	261099	2026-01-25 22:40:05.528262+00
2581	TZ	Tanzania	Simiyu	Bariadi	-2.7919000	33.9894000	260927	2026-01-25 22:40:05.528262+00
2582	NG	Nigeria	Adamawa	Hong	10.2317000	12.9303000	260900	2026-01-25 22:40:05.528262+00
2583	VE	Venezuela	Miranda	Santa Teresa del Tuy	10.2333000	-66.6639000	260899	2026-01-25 22:40:05.528262+00
2584	US	United States	Florida	St. Petersburg	27.7931000	-82.6652000	260646	2026-01-25 22:40:05.528262+00
2585	JP	Japan	Tōkyō	Fuchū	35.6689000	139.4776000	260508	2026-01-25 22:40:05.528262+00
2586	JP	Japan	Tōkyō	Minato	35.6581000	139.7514000	260486	2026-01-25 22:40:05.528262+00
2587	RS	Serbia	Novi Sad	Novi Sad	45.2542000	19.8425000	260438	2026-01-25 22:40:05.528262+00
2588	ZA	South Africa	Gauteng	Boksburg	-26.2125000	28.2625000	260321	2026-01-25 22:40:05.528262+00
2589	PH	Philippines	Olongapo	Olongapo	14.8300000	120.2800000	260317	2026-01-25 22:40:05.528262+00
2590	VN	Vietnam	Quảng Ngãi	Quảng Ngãi	15.1167000	108.8000000	260252	2026-01-25 22:40:05.528262+00
2591	RU	Russia	Saratovskaya Oblast’	Engels	51.5017000	46.1222000	260190	2026-01-25 22:40:05.528262+00
2592	US	United States	Washington	Kennewick	46.1978000	-119.1732000	260091	2026-01-25 22:40:05.528262+00
2593	IN	India	Tamil Nādu	Sivakāsi	9.4533000	77.8024000	260047	2026-01-25 22:40:05.528262+00
2594	IQ	Iraq	Al Qādisīyah	Al Ḩamzah	31.7244000	44.9769000	260000	2026-01-25 22:40:05.528262+00
2595	PK	Pakistan	Gilgit-Baltistan	Skardu	35.2903000	75.6444000	260000	2026-01-25 22:40:05.528262+00
2596	UZ	Uzbekistan	Farg‘ona	Qo‘qon	40.5286000	70.9425000	259700	2026-01-25 22:40:05.528262+00
2597	PK	Pakistan	Sindh	Kotri	25.3740000	68.3013000	259358	2026-01-25 22:40:05.528262+00
2598	LY	Libya	Mişrātah	Mişrātah	32.3775000	15.0920000	259056	2026-01-25 22:40:05.528262+00
2599	TR	Turkey	Aydın	Aydın	37.8481000	27.8453000	259027	2026-01-25 22:40:05.528262+00
2600	SD	Sudan	Sennar	Singa	13.1483000	33.9311000	259000	2026-01-25 22:40:05.528262+00
2601	AF	Afghanistan	Takhār	Tāluqān	36.7167000	69.5167000	258758	2026-01-25 22:40:05.528262+00
2602	EC	Ecuador	Manabí	Manta	-0.9500000	-80.7162000	258697	2026-01-25 22:40:05.528262+00
2603	AO	Angola	Huambo	Ndulo	-11.4833000	15.8333000	258161	2026-01-25 22:40:05.528262+00
2604	AO	Angola	Bié	Andulo	-11.4926000	16.7035000	258161	2026-01-25 22:40:05.528262+00
2605	ES	Spain	Basque Country	Vitoria-Gasteiz	42.8500000	-2.6833000	257968	2026-01-25 22:40:05.528262+00
2606	JP	Japan	Kanagawa	Hiratsuka	35.3167000	139.3500000	257662	2026-01-25 22:40:05.528262+00
2607	US	United States	Georgia	Columbus	32.5100000	-84.8771000	257578	2026-01-25 22:40:05.528262+00
2608	IQ	Iraq	As Sulaymānīyah	Rāniyah	36.2550000	44.8822000	257577	2026-01-25 22:40:05.528262+00
2609	DZ	Algeria	Annaba	Annaba	36.9000000	7.7667000	257359	2026-01-25 22:40:05.528262+00
2610	IN	India	Uttar Pradesh	Etāwah	26.7700000	79.0300000	256838	2026-01-25 22:40:05.528262+00
2611	BD	Bangladesh	Dhaka	Siddhirganj	23.6913000	90.5149000	256760	2026-01-25 22:40:05.528262+00
2612	RU	Russia	Moskovskaya Oblast’	Khimki	55.8892000	37.4450000	256684	2026-01-25 22:40:05.528262+00
2613	ZM	Zambia	Copperbelt	Chingola	-12.5333000	27.8500000	256560	2026-01-25 22:40:05.528262+00
2614	UA	Ukraine	Sumska Oblast	Sumy	50.9119000	34.8028000	256474	2026-01-25 22:40:05.528262+00
2615	CN	China	Inner Mongolia	Yakeshi	49.2860000	120.7120000	256396	2026-01-25 22:40:05.528262+00
2616	BR	Brazil	São Paulo	Indaiatuba	-23.0903000	-47.2181000	256223	2026-01-25 22:40:05.528262+00
2617	ZA	South Africa	Free State	Bloemfontein	-29.1167000	26.2167000	256185	2026-01-25 22:40:05.528262+00
2618	US	United States	Texas	Laredo	27.5625000	-99.4874000	255949	2026-01-25 22:40:05.528262+00
2619	IN	India	Andhra Pradesh	Malkājgiri	17.4519000	78.5362000	255899	2026-01-25 22:40:05.528262+00
2620	ZA	South Africa	Gauteng	Germiston	-26.2178000	28.1672000	255863	2026-01-25 22:40:05.528262+00
2621	IT	Italy	Veneto	Verona	45.4386000	10.9928000	255588	2026-01-25 22:40:05.528262+00
2622	JP	Japan	Hyōgo	Kakogawachō-honmachi	34.7500000	134.8333000	255523	2026-01-25 22:40:05.528262+00
2623	GB	United Kingdom	Derby	Derby	52.9247000	-1.4780000	255394	2026-01-25 22:40:05.528262+00
2624	ID	Indonesia	Jawa Barat	Pasarkemis	-6.1703000	106.5300000	255345	2026-01-25 22:40:05.528262+00
2625	GB	United Kingdom	Westminster	Westminster	51.4947000	-0.1353000	255324	2026-01-25 22:40:05.528262+00
2626	MY	Malaysia	Terengganu	Kuala Terengganu	5.3304000	103.1200000	255109	2026-01-25 22:40:05.528262+00
2627	US	United States	Texas	Irving	32.8583000	-96.9702000	255036	2026-01-25 22:40:05.528262+00
2628	GT	Guatemala	Alta Verapaz	San Pedro Carchá	15.4667000	-90.3000000	255006	2026-01-25 22:40:05.528262+00
2629	AO	Angola	Namibe	Moçâmedes	-15.1953000	12.1508000	255000	2026-01-25 22:40:05.528262+00
2630	JP	Japan	Tokushima	Tokushima	34.0667000	134.5500000	254510	2026-01-25 22:40:05.528262+00
2631	BR	Brazil	São Paulo	São Carlos	-22.0178000	-47.8908000	254484	2026-01-25 22:40:05.528262+00
2632	CA	Canada	Quebec	Longueuil	45.5333000	-73.5167000	254483	2026-01-25 22:40:05.528262+00
2633	PH	Philippines	Bulacan	Marilao	14.7581000	120.9481000	254453	2026-01-25 22:40:05.528262+00
2634	IN	India	Andhra Pradesh	Tuni	17.3500000	82.5500000	254425	2026-01-25 22:40:05.528262+00
2635	ET	Ethiopia	YeDebub Bihēroch Bihēreseboch na Hizboch	Sodo	6.8550000	37.7808000	254295	2026-01-25 22:40:05.528262+00
2636	IQ	Iraq	Dhī Qār	Ash Shaţrah	31.4175000	46.1772000	254000	2026-01-25 22:40:05.528262+00
2637	IQ	Iraq	Baghdād	Sab‘ al Būr	33.4617000	44.1557000	254000	2026-01-25 22:40:05.528262+00
2638	MQ	Martinique	\N	Fort-de-France	14.6000000	-61.0667000	253995	2026-01-25 22:40:05.528262+00
2639	MM	Burma	Mon State	Mawlamyine	16.4847000	97.6258000	253734	2026-01-25 22:40:05.528262+00
2640	BR	Brazil	Pernambuco	Caruaru	-8.2828000	-35.9758000	253634	2026-01-25 22:40:05.528262+00
2641	EG	Egypt	Al Gharbīyah	Ţanţā	30.7833000	31.0000000	253600	2026-01-25 22:40:05.528262+00
2642	IN	India	Mahārāshtra	Amarnāth	19.2090000	73.1860000	253475	2026-01-25 22:40:05.528262+00
2643	BJ	Benin	Atlantique	Godomè	6.3667000	2.3500000	253262	2026-01-25 22:40:05.528262+00
2644	IN	India	Gujarāt	Rāpar	23.5700000	70.6300000	253137	2026-01-25 22:40:05.528262+00
2645	IN	India	Bihār	Samāstipur	25.8629000	85.7811000	253136	2026-01-25 22:40:05.528262+00
2646	IN	India	Karnātaka	Gokāk	16.1667000	74.8333000	253000	2026-01-25 22:40:05.528262+00
2647	TR	Turkey	Antalya	Manavgat	36.7833000	31.4333000	252941	2026-01-25 22:40:05.528262+00
2648	JP	Japan	Fukuoka	Shinozaki	33.9578000	130.9414000	252844	2026-01-25 22:40:05.528262+00
2649	DE	Germany	North Rhine-Westphalia	Aachen	50.7756000	6.0836000	252769	2026-01-25 22:40:05.528262+00
2650	BR	Brazil	Rio Grande do Norte	Parnamirim	-5.9158000	-35.2628000	252716	2026-01-25 22:40:05.528262+00
2651	BD	Bangladesh	Khulna	Jhenida	23.5425000	89.1749000	252500	2026-01-25 22:40:05.528262+00
2652	ID	Indonesia	Jawa Barat	Cimanggis	-6.3645000	106.8591000	252370	2026-01-25 22:40:05.528262+00
2653	IN	India	Rājasthān	Bharatpur	27.2200000	77.4800000	252342	2026-01-25 22:40:05.528262+00
2654	VE	Venezuela	Miranda	Los Teques	10.3333000	-67.0417000	252242	2026-01-25 22:40:05.528262+00
2655	US	United States	Illinois	Round Lake Beach	42.3791000	-88.0811000	252224	2026-01-25 22:40:05.528262+00
2656	TR	Turkey	Osmaniye	Osmaniye	37.0750000	36.2500000	252186	2026-01-25 22:40:05.528262+00
2657	BR	Brazil	Minas Gerais	Uberaba	-19.7478000	-47.9319000	252051	2026-01-25 22:40:05.528262+00
2658	IN	India	Bihār	Begusarai	25.4200000	86.1300000	252008	2026-01-25 22:40:05.528262+00
2659	ID	Indonesia	Jawa Timur	Kediri	-7.8111000	112.0047000	252000	2026-01-25 22:40:05.528262+00
2660	KP	Korea, North	Chagang	Kanggye	40.9667000	126.6000000	251971	2026-01-25 22:40:05.528262+00
2661	JP	Japan	Hokkaidō	Hakodate	41.7686000	140.7289000	251891	2026-01-25 22:40:05.528262+00
2662	PH	Philippines	Tacloban	Tacloban	11.2400000	125.0000000	251881	2026-01-25 22:40:05.528262+00
2663	TR	Turkey	Afyonkarahisar	Afyonkarahisar	38.7578000	30.5386000	251799	2026-01-25 22:40:05.528262+00
2664	TR	Turkey	Hatay	İskenderun	36.5817000	36.1650000	251682	2026-01-25 22:40:05.528262+00
2665	US	United States	Alabama	Montgomery	32.3482000	-86.2668000	251545	2026-01-25 22:40:05.528262+00
2666	JP	Japan	Saitama	Sōka	35.8254000	139.8053000	251390	2026-01-25 22:40:05.528262+00
2667	IN	India	Kerala	Nedumana	8.9139000	76.6889000	251384	2026-01-25 22:40:05.528262+00
2668	DO	Dominican Republic	Yuma	Higüey	18.6181000	-68.7111000	251243	2026-01-25 22:40:05.528262+00
2669	US	United States	Virginia	Chesapeake	36.6778000	-76.3023000	251153	2026-01-25 22:40:05.528262+00
2670	GB	United Kingdom	Wolverhampton	Wolverhampton	52.5833000	-2.1333000	250970	2026-01-25 22:40:05.528262+00
2671	GP	Guadeloupe	\N	Pointe-à-Pitre	16.2411000	-61.5331000	250952	2026-01-25 22:40:05.528262+00
2672	IQ	Iraq	Al Anbār	Al Fallūjah	33.3500000	43.7833000	250884	2026-01-25 22:40:05.528262+00
2673	RO	Romania	Timiş	Timişoara	45.7597000	21.2300000	250849	2026-01-25 22:40:05.528262+00
2674	GQ	Equatorial Guinea	Litoral	Bata	1.8650000	9.7700000	250770	2026-01-25 22:40:05.528262+00
2675	DE	Germany	Saxony	Chemnitz	50.8333000	12.9167000	250681	2026-01-25 22:40:05.528262+00
2676	VN	Vietnam	Kiến Giang	Rạch Giá	10.0167000	105.0833000	250660	2026-01-25 22:40:05.528262+00
2677	BD	Bangladesh	Chattogram	Companiganj	22.8730000	91.2782000	250579	2026-01-25 22:40:05.528262+00
2678	IT	Italy	Veneto	Venice	45.4397000	12.3319000	250369	2026-01-25 22:40:05.528262+00
2679	IR	Iran	Māzandarān	Bābol	36.5475000	52.6783000	250217	2026-01-25 22:40:05.528262+00
2680	US	United States	Arizona	Glendale	33.5791000	-112.2311000	250193	2026-01-25 22:40:05.528262+00
2681	MX	Mexico	Baja California Sur	La Paz	24.1422000	-110.3108000	250141	2026-01-25 22:40:05.528262+00
2682	IQ	Iraq	As Sulaymānīyah	Kalār	34.6281000	45.3185000	250000	2026-01-25 22:40:05.528262+00
2683	KZ	Kazakhstan	Türkistan	Türkistan	43.3019000	68.2692000	250000	2026-01-25 22:40:05.528262+00
2684	LY	Libya	Al Jabal al Akhḑar	Al Bayḑā’	32.7628000	21.7550000	250000	2026-01-25 22:40:05.528262+00
2685	MM	Burma	Mandalay	Natogyi	21.4167000	95.6500000	250000	2026-01-25 22:40:05.528262+00
2686	SD	Sudan	Blue Nile	Kurmuk	10.5563000	34.2848000	250000	2026-01-25 22:40:05.528262+00
2687	IN	India	Delhi	New Delhi	28.6139000	77.2089000	249998	2026-01-25 22:40:05.528262+00
2688	CL	Chile	Región Metropolitana	Las Condes	-33.4117000	-70.5500000	249893	2026-01-25 22:40:05.528262+00
2689	CD	Congo (Kinshasa)	Nord-Kivu	Goma	-1.6794000	29.2336000	249862	2026-01-25 22:40:05.528262+00
2690	IL	Israel	Central	Rishon LeẔiyyon	31.9500000	34.8000000	249860	2026-01-25 22:40:05.528262+00
2691	CL	Chile	Los Lagos	Osorno	-40.5725000	-73.1353000	249728	2026-01-25 22:40:05.528262+00
2692	MX	Mexico	Campeche	Campeche	19.8500000	-90.5306000	249623	2026-01-25 22:40:05.528262+00
2693	IN	India	Tamil Nādu	Tiruvottiyūr	13.1600000	80.3000000	249446	2026-01-25 22:40:05.528262+00
2694	ID	Indonesia	Kalimantan Tengah	Palangkaraya	-2.2100000	113.9200000	249434	2026-01-25 22:40:05.528262+00
2695	ES	Spain	Galicia	A Coruña	43.3650000	-8.4100000	249261	2026-01-25 22:40:05.528262+00
2696	CA	Canada	British Columbia	Burnaby	49.2667000	-122.9667000	249125	2026-01-25 22:40:05.528262+00
2697	IN	India	Bihār	Rāmnagar	27.1700000	84.3200000	249102	2026-01-25 22:40:05.528262+00
2698	BR	Brazil	São Paulo	Limeira	-22.5647000	-47.4017000	249046	2026-01-25 22:40:05.528262+00
2699	DE	Germany	Schleswig-Holstein	Kiel	54.3233000	10.1394000	248873	2026-01-25 22:40:05.528262+00
2700	MX	Mexico	Campeche	Carmen	18.6431000	-91.8306000	248845	2026-01-25 22:40:05.528262+00
2701	IN	India	Gujarāt	Gāndhīdhām	23.0800000	70.1300000	248705	2026-01-25 22:40:05.528262+00
2702	BJ	Benin	Alibori	Banikoara	11.3000000	2.4333000	248621	2026-01-25 22:40:05.528262+00
2703	IN	India	Rājasthān	Salūmbar	24.0800000	74.0200000	248337	2026-01-25 22:40:05.528262+00
2704	KR	Korea, South	Gyeongbuk	Kyŏngju	35.8500000	129.2167000	248244	2026-01-25 22:40:05.528262+00
2705	FI	Finland	Uusimaa	Vantaa	60.2944000	25.0403000	248199	2026-01-25 22:40:05.528262+00
2706	MY	Malaysia	Sarawak	Sibu	2.3030000	111.8430000	247995	2026-01-25 22:40:05.528262+00
2707	IR	Iran	Māzandarān	Qā’em Shahr	36.4636000	52.8581000	247953	2026-01-25 22:40:05.528262+00
2708	TR	Turkey	İstanbul	Beykoz	41.1342000	29.0922000	247875	2026-01-25 22:40:05.528262+00
2709	US	United States	New Hampshire	Nashua	42.7491000	-71.4910000	247828	2026-01-25 22:40:05.528262+00
2710	PK	Pakistan	Punjab	Sahiwal	30.6611000	73.1083000	247706	2026-01-25 22:40:05.528262+00
2711	TR	Turkey	Isparta	Isparta	37.7647000	30.5567000	247580	2026-01-25 22:40:05.528262+00
2712	PH	Philippines	Navotas	Navotas	14.6667000	120.9417000	247543	2026-01-25 22:40:05.528262+00
2713	CU	Cuba	Villa Clara	Santa Clara	22.4067000	-79.9531000	247436	2026-01-25 22:40:05.528262+00
2714	JP	Japan	Yamagata	Yamagata	38.2554000	140.3396000	247234	2026-01-25 22:40:05.528262+00
2715	TR	Turkey	Aksaray	Aksaray	38.3742000	34.0289000	247147	2026-01-25 22:40:05.528262+00
2716	BR	Brazil	Minas Gerais	Governador Valadares	-18.8508000	-41.9489000	247131	2026-01-25 22:40:05.528262+00
2717	IR	Iran	Eşfahān	Khomeynī Shahr	32.6803000	51.5361000	247128	2026-01-25 22:40:05.528262+00
2718	CN	China	Guangdong	Shijing	23.0930000	113.7965000	246960	2026-01-25 22:40:05.528262+00
2719	US	United States	Pennsylvania	York	39.9651000	-76.7315000	246769	2026-01-25 22:40:05.528262+00
2720	GB	United Kingdom	Swansea	Abertawe	51.6167000	-3.9500000	246700	2026-01-25 22:40:05.528262+00
2721	JP	Japan	Ibaraki	Tsukuba-kenkyūgakuen-toshi	36.0835000	140.0764000	246647	2026-01-25 22:40:05.528262+00
2722	BO	Bolivia	Oruro	Oruro	-17.9799000	-67.1300000	246501	2026-01-25 22:40:05.528262+00
2723	BR	Brazil	Rio de Janeiro	Macaé	-22.3708000	-41.7869000	246391	2026-01-25 22:40:05.528262+00
2724	HU	Hungary	Győr-Moson-Sopron	Győr	47.6842000	17.6344000	246159	2026-01-25 22:40:05.528262+00
2725	EG	Egypt	Ash Sharqīyah	Al ‘Āshir min Ramaḑān	30.2964000	31.7463000	246148	2026-01-25 22:40:05.528262+00
2726	MG	Madagascar	Mahajanga	Mahajanga	-15.6700000	46.3450000	246022	2026-01-25 22:40:05.528262+00
2727	LK	Sri Lanka	Western	Mount Lavinia	6.8339000	79.8644000	245974	2026-01-25 22:40:05.528262+00
2728	US	United States	Texas	Garland	32.9100000	-96.6304000	245298	2026-01-25 22:40:05.528262+00
2729	PL	Poland	Pomorskie	Gdynia	54.5175000	18.5400000	245222	2026-01-25 22:40:05.528262+00
2730	GB	United Kingdom	Barnsley	Barnsley	53.5547000	-1.4791000	245199	2026-01-25 22:40:05.528262+00
2731	MY	Malaysia	Perak	Taiping	4.8650000	100.7200000	245182	2026-01-25 22:40:05.528262+00
2732	RU	Russia	Komi	Syktyvkar	61.6667000	50.8167000	245083	2026-01-25 22:40:05.528262+00
2733	GB	United Kingdom	Stoke-on-Trent	Stoke-on-Trent	53.0255000	-2.1761000	245000	2026-01-25 22:40:05.528262+00
2734	BR	Brazil	Maranhão	São José de Ribamar	-2.5619000	-44.0539000	244579	2026-01-25 22:40:05.528262+00
2735	US	United States	South Carolina	Rock Hill	34.9415000	-81.0241000	244403	2026-01-25 22:40:05.528262+00
2736	IN	India	Puducherry	Puducherry	11.9167000	79.8167000	244377	2026-01-25 22:40:05.528262+00
2737	AR	Argentina	Buenos Aires	Merlo	-34.6653000	-58.7275000	244168	2026-01-25 22:40:05.528262+00
2738	EC	Ecuador	Manabí	Portoviejo	-1.0561000	-80.4553000	244129	2026-01-25 22:40:05.528262+00
2739	EG	Egypt	Al Buḩayrah	Damanhūr	31.0500000	30.4667000	244043	2026-01-25 22:40:05.528262+00
2740	BA	Bosnia and Herzegovina	Bosnia and Herzegovina, Federation of	Sarajevo	43.8564000	18.4131000	244000	2026-01-25 22:40:05.528262+00
2741	BD	Bangladesh	Khulna	Jessore	23.1704000	89.2000000	243987	2026-01-25 22:40:05.528262+00
2742	UA	Ukraine	Rivnenska Oblast	Rivne	50.6192000	26.2519000	243873	2026-01-25 22:40:05.528262+00
2743	LK	Sri Lanka	Western	Kesbewa	6.7914000	79.9378000	243842	2026-01-25 22:40:05.528262+00
2744	IN	India	Uttar Pradesh	Kanpur	26.4499000	80.3319000	243800	2026-01-25 22:40:05.528262+00
2745	JP	Japan	Shizuoka	Fuji	35.1613000	138.6763000	243739	2026-01-25 22:40:05.528262+00
2746	NL	Netherlands	Noord-Brabant	Eindhoven	51.4344000	5.4842000	243730	2026-01-25 22:40:05.528262+00
2747	IR	Iran	Khorāsān-e Raẕavī	Sabzevār	36.2125000	57.6764000	243700	2026-01-25 22:40:05.528262+00
2748	BR	Brazil	Rio Grande do Sul	Santa Maria	-29.6839000	-53.8069000	243611	2026-01-25 22:40:05.528262+00
2749	ET	Ethiopia	Āmara	Bahir Dar	11.6000000	37.3833000	243300	2026-01-25 22:40:05.528262+00
2750	CN	China	Heilongjiang	Wudalianchi	48.7500000	126.1667000	243283	2026-01-25 22:40:05.528262+00
2751	ES	Spain	Valencia	Elche	38.2669000	-0.6983000	243128	2026-01-25 22:40:05.528262+00
2752	MM	Burma	Kachin State	Myitkyina	25.3833000	97.4000000	243031	2026-01-25 22:40:05.528262+00
2753	IN	India	Andhra Pradesh	Rāmgundam	18.7639000	79.4750000	242979	2026-01-25 22:40:05.528262+00
2754	VN	Vietnam	Phú Yên	Tuy Hòa	13.0819000	109.2950000	242840	2026-01-25 22:40:05.528262+00
2755	JP	Japan	Nagasaki	Sasebo	33.1800000	129.7150000	242664	2026-01-25 22:40:05.528262+00
2756	NG	Nigeria	Delta	Sapele	5.9000000	5.6667000	242652	2026-01-25 22:40:05.528262+00
2757	NP	Nepal	Province Number One	Birāṭnagar	26.4833000	87.2833000	242548	2026-01-25 22:40:05.528262+00
2758	IN	India	Mahārāshtra	Pandharpur	17.6778000	75.3278000	242515	2026-01-25 22:40:05.528262+00
2759	UZ	Uzbekistan	Farg‘ona	Marg‘ilon	40.4711000	71.7247000	242500	2026-01-25 22:40:05.528262+00
2760	KZ	Kazakhstan	Qyzylorda	Qyzylorda	44.8500000	65.5167000	242462	2026-01-25 22:40:05.528262+00
2761	CA	Canada	Ontario	St. Catharines	43.1833000	-79.2333000	242460	2026-01-25 22:40:05.528262+00
2762	JP	Japan	Kanagawa	Chigasaki	35.3333000	139.4000000	242347	2026-01-25 22:40:05.528262+00
2763	BR	Brazil	São Paulo	Araraquara	-21.7939000	-48.1758000	242228	2026-01-25 22:40:05.528262+00
2764	DE	Germany	Saxony-Anhalt	Halle	51.4828000	11.9697000	242172	2026-01-25 22:40:05.528262+00
2765	US	United States	Arizona	Scottsdale	33.6872000	-111.8651000	242169	2026-01-25 22:40:05.528262+00
2766	BR	Brazil	Rio de Janeiro	Volta Redonda	-22.5231000	-44.1042000	242063	2026-01-25 22:40:05.528262+00
2767	BR	Brazil	São Paulo	Americana	-22.7392000	-47.3314000	242018	2026-01-25 22:40:05.528262+00
2768	CN	China	Fujian	Zhangping	25.2902000	117.4200000	242000	2026-01-25 22:40:05.528262+00
2769	CI	Côte d’Ivoire	Montagnes	Man	7.4004000	-7.5500000	241969	2026-01-25 22:40:05.528262+00
2770	BR	Brazil	Minas Gerais	Sete Lagoas	-19.4658000	-44.2469000	241835	2026-01-25 22:40:05.528262+00
2771	BD	Bangladesh	Chattogram	Bānchpār	23.2081000	90.7979000	241799	2026-01-25 22:40:05.528262+00
2772	SA	Saudi Arabia	Al Jawf	Sakākā	29.9697000	40.2000000	241669	2026-01-25 22:40:05.528262+00
2773	KP	Korea, North	Hwangnam	Haeju	38.0333000	125.7167000	241599	2026-01-25 22:40:05.528262+00
2774	RU	Russia	Rostovskaya Oblast’	Taganrog	47.2167000	38.9167000	241557	2026-01-25 22:40:05.528262+00
2775	VN	Vietnam	Hải Dương	Hải Dương	20.9397000	106.3306000	241373	2026-01-25 22:40:05.528262+00
2776	IN	India	Bihār	Masaurhi Buzurg	25.3500000	85.0200000	241216	2026-01-25 22:40:05.528262+00
2777	ET	Ethiopia	Oromīya	Gelemso	8.8167000	40.5167000	241200	2026-01-25 22:40:05.528262+00
2778	IN	India	Kerala	Alleppey	9.4900000	76.3300000	240991	2026-01-25 22:40:05.528262+00
2779	SR	Suriname	Paramaribo	Paramaribo	5.8522000	-55.2039000	240924	2026-01-25 22:40:05.528262+00
2780	VE	Venezuela	Miranda	Baruta	10.4322000	-66.8739000	240755	2026-01-25 22:40:05.528262+00
2781	BR	Brazil	São Paulo	Marília	-22.2139000	-49.9458000	240590	2026-01-25 22:40:05.528262+00
2782	IN	India	Bihār	Katihār	25.5300000	87.5800000	240565	2026-01-25 22:40:05.528262+00
2783	PE	Peru	San Martín	Tarapoto	-6.4833000	-76.3667000	240453	2026-01-25 22:40:05.528262+00
2784	RU	Russia	Tatarstan	Nizhnekamsk	55.6333000	51.8167000	240379	2026-01-25 22:40:05.528262+00
2785	CN	China	Xinjiang	Atushi	39.7162000	76.1684000	240368	2026-01-25 22:40:05.528262+00
2786	IQ	Iraq	Al Başrah	Abī al Khaşīb	30.4464000	47.9781000	240300	2026-01-25 22:40:05.528262+00
2787	BR	Brazil	São Paulo	Jacareí	-23.3050000	-45.9658000	240275	2026-01-25 22:40:05.528262+00
2788	KP	Korea, North	P’yŏngnam	Anju	39.6200000	125.6600000	240117	2026-01-25 22:40:05.528262+00
2789	DE	Germany	Saxony-Anhalt	Magdeburg	52.1317000	11.6392000	240114	2026-01-25 22:40:05.528262+00
2790	IR	Iran	Khūzestān	Andīmeshk	32.4714000	48.3489000	240113	2026-01-25 22:40:05.528262+00
2791	JP	Japan	Tōkyō	Bunkyō-ku	35.7167000	139.7500000	240069	2026-01-25 22:40:05.528262+00
2792	RU	Russia	Amurskaya Oblast’	Blagoveshchensk	50.2500000	127.5333000	239864	2026-01-25 22:40:05.528262+00
2793	UA	Ukraine	Donetska Oblast	Horlivka	48.3000000	38.0500000	239828	2026-01-25 22:40:05.528262+00
2794	IN	India	Rājasthān	Ahor	25.3670000	72.7830000	239642	2026-01-25 22:40:05.528262+00
2795	JP	Japan	Kanagawa	Yato	35.4833000	139.4500000	239146	2026-01-25 22:40:05.528262+00
2796	JP	Japan	Nagano	Matsumoto	36.2380000	137.9720000	239115	2026-01-25 22:40:05.528262+00
2797	MZ	Mozambique	Manica	Chimoio	-19.1167000	33.4500000	238976	2026-01-25 22:40:05.528262+00
2798	FR	France	Hauts-de-France	Lille	50.6278000	3.0583000	238695	2026-01-25 22:40:05.528262+00
2799	TZ	Tanzania	Kigoma	Kasulu	-4.5800000	30.1000000	238321	2026-01-25 22:40:05.528262+00
2800	UA	Ukraine	Ivano-Frankivska Oblast	Ivano-Frankivsk	48.9228000	24.7106000	238196	2026-01-25 22:40:05.528262+00
2801	JP	Japan	Tōkyō	Chōfugaoka	35.6506000	139.5407000	238087	2026-01-25 22:40:05.528262+00
2802	AR	Argentina	Buenos Aires	González Catán	-34.7667000	-58.6167000	238067	2026-01-25 22:40:05.528262+00
2803	CN	China	Fujian	Wuyishan	27.7564000	118.0353000	238000	2026-01-25 22:40:05.528262+00
2804	CN	China	Shaanxi	Shenmu	38.8244000	110.4831000	237846	2026-01-25 22:40:05.528262+00
2805	IN	India	Rājasthān	Gangānagar	29.9200000	73.8800000	237780	2026-01-25 22:40:05.528262+00
2806	RO	Romania	Braşov	Braşov	45.6667000	25.6167000	237589	2026-01-25 22:40:05.528262+00
2807	IR	Iran	Māzandarān	Āmol	36.4703000	52.3467000	237528	2026-01-25 22:40:05.528262+00
2808	DE	Germany	Baden-Württemberg	Freiburg im Breisgau	47.9950000	7.8500000	237244	2026-01-25 22:40:05.528262+00
2809	MX	Mexico	Coahuila	Monclova	26.9103000	-101.4222000	237169	2026-01-25 22:40:05.528262+00
2810	CN	China	Guizhou	Chishui	28.5904000	105.6975000	237052	2026-01-25 22:40:05.528262+00
2811	BJ	Benin	Donga	Djougou	9.7000000	1.6667000	237040	2026-01-25 22:40:05.528262+00
2812	PK	Pakistan	Sindh	Mirpur Khas	25.5250000	69.0158000	236961	2026-01-25 22:40:05.528262+00
2813	KP	Korea, North	P’yŏngnam	P’yŏngsŏng-si	39.2605000	125.8618000	236609	2026-01-25 22:40:05.528262+00
2814	US	United States	New York	North Hempstead	40.7912000	-73.6688000	236600	2026-01-25 22:40:05.528262+00
2815	ZA	South Africa	Gauteng	Centurion	-25.8603000	28.1894000	236580	2026-01-25 22:40:05.528262+00
2816	IN	India	Assam	Tinkhang	27.2300000	95.1700000	236571	2026-01-25 22:40:05.528262+00
2817	IN	India	Madhya Pradesh	Rewa	24.5381000	81.2953000	236519	2026-01-25 22:40:05.528262+00
2818	TR	Turkey	Uşak	Uşak	38.6778000	29.4042000	236366	2026-01-25 22:40:05.528262+00
2819	RU	Russia	Moskovskaya Oblast’	Lyubertsy	55.6783000	37.8944000	236339	2026-01-25 22:40:05.528262+00
2820	IR	Iran	Tehrān	Pākdasht	35.4828000	51.6814000	236319	2026-01-25 22:40:05.528262+00
2821	MY	Malaysia	Selangor	Kajang	2.9927000	101.7909000	236240	2026-01-25 22:40:05.528262+00
2822	IL	Israel	Central	Petaẖ Tiqwa	32.0833000	34.8833000	236169	2026-01-25 22:40:05.528262+00
2823	SA	Saudi Arabia	‘Asīr	Abhā	18.2167000	42.5000000	236157	2026-01-25 22:40:05.528262+00
2824	EG	Egypt	Al Minyā	Al Minyā	28.0833000	30.7500000	236043	2026-01-25 22:40:05.528262+00
2825	NG	Nigeria	Oyo	Iseyin	7.9667000	3.6000000	236000	2026-01-25 22:40:05.528262+00
2826	HK	Hong Kong	\N	Central District	22.2867000	114.1550000	235953	2026-01-25 22:40:05.528262+00
2827	BW	Botswana	Gaborone	Gaborone	-24.6569000	25.9086000	235884	2026-01-25 22:40:05.528262+00
2828	NE	Niger	Zinder	Zinder	13.8014000	8.9849000	235605	2026-01-25 22:40:05.528262+00
2829	CN	China	Xinjiang	Bole	44.8539000	82.0514000	235585	2026-01-25 22:40:05.528262+00
2830	PR	Puerto Rico	Puerto Rico	Aguadilla	18.4382000	-67.1537000	235546	2026-01-25 22:40:05.528262+00
2831	RU	Russia	Khabarovskiy Kray	Komsomol’sk-na-Amure	50.5667000	137.0000000	235488	2026-01-25 22:40:05.528262+00
2832	AO	Angola	Benguela	Ganda	-13.0167000	14.6333000	235486	2026-01-25 22:40:05.528262+00
2833	US	United States	Virginia	Arlington	38.8786000	-77.1011000	235463	2026-01-25 22:40:05.528262+00
2834	IN	India	West Bengal	Uluberiya	22.4700000	88.1100000	235345	2026-01-25 22:40:05.528262+00
2835	IN	India	Uttar Pradesh	Bulandshahr	28.4069000	77.8497000	235310	2026-01-25 22:40:05.528262+00
2836	ID	Indonesia	Aceh	Banda Aceh	5.5500000	95.3175000	235305	2026-01-25 22:40:05.528262+00
2837	IR	Iran	Eşfahān	Najafābād	32.6331000	51.3650000	235281	2026-01-25 22:40:05.528262+00
2838	JP	Japan	Tōkyō	Shibuya-ku	35.6594000	139.7006000	235193	2026-01-25 22:40:05.528262+00
2839	VN	Vietnam	Bà Rịa-Vũng Tàu	Bà Rịa	10.4992000	107.1675000	235192	2026-01-25 22:40:05.528262+00
2840	CU	Cuba	Granma	Bayamo	20.3795000	-76.6433000	235107	2026-01-25 22:40:05.528262+00
2841	CY	Cyprus	Lemesós	Limassol	34.6747000	33.0442000	235056	2026-01-25 22:40:05.528262+00
2842	US	United States	Virginia	Norfolk	36.8945000	-76.2590000	235037	2026-01-25 22:40:05.528262+00
2843	GY	Guyana	Demerara-Mahaica	Georgetown	6.8011000	-58.1550000	235017	2026-01-25 22:40:05.528262+00
2844	IR	Iran	Lorestān	Borūjerd	33.9111000	48.7522000	234997	2026-01-25 22:40:05.528262+00
2845	YE	Yemen	Ibb	Ibb	13.9759000	44.1709000	234837	2026-01-25 22:40:05.528262+00
2846	US	United States	Wisconsin	Appleton	44.2780000	-88.3892000	234701	2026-01-25 22:40:05.528262+00
2847	MX	Mexico	Nuevo León	García	25.8167000	-100.5833000	234698	2026-01-25 22:40:05.528262+00
2848	BR	Brazil	Alagoas	Arapiraca	-9.7525000	-36.6611000	234696	2026-01-25 22:40:05.528262+00
2849	CN	China	Zhejiang	Longquan	28.0667000	119.1333000	234626	2026-01-25 22:40:05.528262+00
2850	VN	Vietnam	Hòa Bình	Hòa Bình	20.8133000	105.3383000	234567	2026-01-25 22:40:05.528262+00
2851	MY	Malaysia	Sarawak	Miri	4.3999000	113.9845000	234541	2026-01-25 22:40:05.528262+00
2852	BR	Brazil	Ceará	Maracanaú	-3.8769000	-38.6258000	234509	2026-01-25 22:40:05.528262+00
2853	KZ	Kazakhstan	West Kazakhstan	Oral	51.2225000	51.3725000	234184	2026-01-25 22:40:05.528262+00
2854	RO	Romania	Dolj	Craiova	44.3333000	23.8167000	234140	2026-01-25 22:40:05.528262+00
2855	IN	India	Karnātaka	Rāichūr	16.2000000	77.3700000	234073	2026-01-25 22:40:05.528262+00
2856	AR	Argentina	Formosa	Formosa	-26.1833000	-58.1833000	234000	2026-01-25 22:40:05.528262+00
2857	ID	Indonesia	Jawa Tengah	Purwokerto	-7.4278000	109.2417000	233865	2026-01-25 22:40:05.528262+00
2858	IN	India	Uttar Pradesh	Chauhanpatti	25.1500000	82.6000000	233691	2026-01-25 22:40:05.528262+00
2859	SL	Sierra Leone	Southern	Bo	7.9564000	-11.7400000	233684	2026-01-25 22:40:05.528262+00
2860	CF	Central African Republic	Nana-Mambéré	Mambéré	5.5000000	15.5000000	233666	2026-01-25 22:40:05.528262+00
2861	NG	Nigeria	Borno	Damboa	11.1500000	12.7500000	233500	2026-01-25 22:40:05.528262+00
2862	NL	Netherlands	Groningen	Groningen	53.2167000	6.5667000	233273	2026-01-25 22:40:05.528262+00
2863	KR	Korea, South	Gyeonggi	Anyang	37.3833000	126.9333000	233172	2026-01-25 22:40:05.528262+00
2864	AU	Australia	Queensland	Ipswich	-27.6144000	152.7608000	232930	2026-01-25 22:40:05.528262+00
2865	MY	Malaysia	Perak	Teluk Intan	4.0119000	101.0314000	232800	2026-01-25 22:40:05.528262+00
2866	SN	Senegal	Thiès	Mbour	14.4104000	-16.9649000	232777	2026-01-25 22:40:05.528262+00
2867	DO	Dominican Republic	Valdesia	San Cristóbal	18.4167000	-70.1333000	232769	2026-01-25 22:40:05.528262+00
2868	ES	Spain	Andalusia	Granada	37.1781000	-3.6008000	232717	2026-01-25 22:40:05.528262+00
2869	BR	Brazil	Rio Grande do Sul	Gravataí	-29.9433000	-50.9939000	232629	2026-01-25 22:40:05.528262+00
2870	IN	India	Kerala	Cannanore	11.8745000	75.3704000	232486	2026-01-25 22:40:05.528262+00
2871	TZ	Tanzania	Singida	Singida	-4.8167000	34.7500000	232459	2026-01-25 22:40:05.528262+00
2872	TZ	Tanzania	Kigoma	Kigoma	-4.8833000	29.6333000	232388	2026-01-25 22:40:05.528262+00
2873	PK	Pakistan	Punjab	Okara	30.8092000	73.4536000	232386	2026-01-25 22:40:05.528262+00
2874	JP	Japan	Saga	Saga	33.2636000	130.3008000	232359	2026-01-25 22:40:05.528262+00
2875	CN	China	Yunnan	Lin’an	23.6025000	102.8309000	232160	2026-01-25 22:40:05.528262+00
2876	US	United States	Nevada	Enterprise	36.0091000	-115.2278000	232043	2026-01-25 22:40:05.528262+00
2877	CD	Congo (Kinshasa)	Nord-Kivu	Beni	0.5000000	29.4667000	232000	2026-01-25 22:40:05.528262+00
2878	IN	India	Andhra Pradesh	Machilīpatnam	16.1700000	81.1300000	232000	2026-01-25 22:40:05.528262+00
2879	BD	Bangladesh	Rājshāhi	Nazipur	25.0455000	88.7609000	231900	2026-01-25 22:40:05.528262+00
2880	PT	Portugal	Porto	Porto	41.1495000	-8.6108000	231800	2026-01-25 22:40:05.528262+00
2881	US	United States	Mississippi	Gulfport	30.4274000	-89.0704000	231754	2026-01-25 22:40:05.528262+00
2882	EG	Egypt	Kafr ash Shaykh	Biyalā	31.1742000	31.2218000	231569	2026-01-25 22:40:05.528262+00
2883	US	United States	Louisiana	Lafayette	30.2082000	-92.0325000	231548	2026-01-25 22:40:05.528262+00
2884	IR	Iran	Khūzestān	Madan	30.3469000	48.2825000	231476	2026-01-25 22:40:05.528262+00
2885	CN	China	Guangdong	Huangjingkeng	22.9173000	113.9958000	231399	2026-01-25 22:40:05.528262+00
2886	CL	Chile	Libertador General Bernardo O’Higgins	Rancagua	-34.1667000	-70.7500000	231370	2026-01-25 22:40:05.528262+00
2887	VN	Vietnam	Thái Nguyên	Phú Yên	21.4156000	105.8739000	231363	2026-01-25 22:40:05.528262+00
2888	BR	Brazil	Minas Gerais	Divinópolis	-20.1389000	-44.8839000	231091	2026-01-25 22:40:05.528262+00
2889	IR	Iran	Tehrān	Qarchak	35.4267000	51.5842000	231075	2026-01-25 22:40:05.528262+00
2890	PH	Philippines	Ormoc	Ormoc	11.0106000	124.6075000	230998	2026-01-25 22:40:05.528262+00
2891	JP	Japan	Nagasaki	Yoshiichō-shimobaru	33.1800000	129.7150000	230873	2026-01-25 22:40:05.528262+00
2892	MX	Mexico	Zacatecas	Fresnillo	23.1750000	-102.8675000	230865	2026-01-25 22:40:05.528262+00
2893	TM	Turkmenistan	Lebap	Türkmenabat	39.0833000	63.5667000	230861	2026-01-25 22:40:05.528262+00
2894	VN	Vietnam	Hà Nội	Sơn Tây	21.1333000	105.5000000	230577	2026-01-25 22:40:05.528262+00
2895	ID	Indonesia	Kalimantan Barat	Singkawang	0.9000000	108.9833000	230376	2026-01-25 22:40:05.528262+00
2896	ML	Mali	Sikasso	Zégoua	10.4519000	-5.6511000	230360	2026-01-25 22:40:05.528262+00
2897	SO	Somalia	Shabeellaha Hoose	Marka	1.7156000	44.7703000	230100	2026-01-25 22:40:05.528262+00
2898	BD	Bangladesh	Barishal	Barishal	22.7000000	90.3667000	230000	2026-01-25 22:40:05.528262+00
2899	MY	Malaysia	Johor	Kulai	1.6561000	103.6032000	230000	2026-01-25 22:40:05.528262+00
2900	IN	India	Rājasthān	Pāli	25.7700000	73.3300000	229956	2026-01-25 22:40:05.528262+00
2901	IN	India	Gujarāt	Songadh	21.1670000	73.5640000	229782	2026-01-25 22:40:05.528262+00
2902	IN	India	Andhra Pradesh	Gadda Madiral	18.7519000	79.5133000	229644	2026-01-25 22:40:05.528262+00
2903	IN	India	Tamil Nādu	Hosūr	12.7409000	77.8253000	229528	2026-01-25 22:40:05.528262+00
2904	TR	Turkey	Ordu	Ordu	40.9833000	37.8833000	229214	2026-01-25 22:40:05.528262+00
2905	SK	Slovakia	Košice	Košice	48.7167000	21.2500000	229040	2026-01-25 22:40:05.528262+00
2906	JP	Japan	Saitama	Kasukabe	35.9753000	139.7523000	228975	2026-01-25 22:40:05.528262+00
2907	IR	Iran	Khorāsān-e Shomālī	Bojnūrd	37.4722000	57.3289000	228931	2026-01-25 22:40:05.528262+00
2908	CO	Colombia	Antioquia	Envigado	6.1667000	-75.5667000	228848	2026-01-25 22:40:05.528262+00
2909	IN	India	Uttarākhand	Haridwār	29.9450000	78.1630000	228832	2026-01-25 22:40:05.528262+00
2910	IN	India	Andhra Pradesh	Vizianagaram	18.1159000	83.4060000	228720	2026-01-25 22:40:05.528262+00
2911	ES	Spain	Catalonia	Tarrasa	41.5700000	2.0130000	228708	2026-01-25 22:40:05.528262+00
2912	BR	Brazil	São Paulo	Suzano	-23.5428000	-46.3108000	228690	2026-01-25 22:40:05.528262+00
2913	GT	Guatemala	Alta Verapaz	Cobán	15.4833000	-90.3667000	228664	2026-01-25 22:40:05.528262+00
2914	US	United States	Washington	Bremerton	47.5436000	-122.7121000	228576	2026-01-25 22:40:05.528262+00
2915	MA	Morocco	Béni Mellal-Khénifra	Khénifra	32.9394000	-5.6675000	228567	2026-01-25 22:40:05.528262+00
2916	DE	Germany	North Rhine-Westphalia	Krefeld	51.3333000	6.5667000	228550	2026-01-25 22:40:05.528262+00
2917	US	United States	California	Fremont	37.5265000	-121.9843000	228518	2026-01-25 22:40:05.528262+00
2918	CU	Cuba	Guantánamo	Guantánamo	20.1383000	-75.2061000	228436	2026-01-25 22:40:05.528262+00
2919	SA	Saudi Arabia	Jāzān	Şabyā	17.1495000	42.6254000	228375	2026-01-25 22:40:05.528262+00
2920	IN	India	Mahārāshtra	Pāthardi	19.1700000	75.1800000	228279	2026-01-25 22:40:05.528262+00
2921	BR	Brazil	Rio de Janeiro	Magé	-22.6528000	-43.0408000	228127	2026-01-25 22:40:05.528262+00
2922	JP	Japan	Ōsaka	Neya	34.7667000	135.6333000	227997	2026-01-25 22:40:05.528262+00
2923	IN	India	Tamil Nādu	Mel Pālaiyam	8.7000000	77.7069000	227895	2026-01-25 22:40:05.528262+00
2924	LB	Lebanon	Liban-Nord	Tripoli	34.4367000	35.8344000	227857	2026-01-25 22:40:05.528262+00
2925	FR	France	Bretagne	Rennes	48.1147000	-1.6794000	227830	2026-01-25 22:40:05.528262+00
2926	BR	Brazil	Minas Gerais	Ipatinga	-19.4678000	-42.5369000	227731	2026-01-25 22:40:05.528262+00
2927	EG	Egypt	Sūhāj	Sāqultah	26.6582000	31.6714000	227719	2026-01-25 22:40:05.528262+00
2928	US	United States	Wisconsin	Green Bay	44.5148000	-87.9895000	227679	2026-01-25 22:40:05.528262+00
2929	HN	Honduras	Cortés	Choloma	15.6127000	-87.9507000	227535	2026-01-25 22:40:05.528262+00
2930	IN	India	Uttarākhand	Khatīma	28.9198000	79.9699000	227226	2026-01-25 22:40:05.528262+00
2931	ES	Spain	Catalonia	Badalona	41.4489000	2.2461000	227083	2026-01-25 22:40:05.528262+00
2932	IN	India	Gujarāt	Petlād	22.4700000	72.8000000	227031	2026-01-25 22:40:05.528262+00
2933	UA	Ukraine	Dnipropetrovska Oblast	Kamianske	48.5167000	34.6133000	226845	2026-01-25 22:40:05.528262+00
2934	JP	Japan	Saitama	Ageoshimo	35.9774000	139.5932000	226616	2026-01-25 22:40:05.528262+00
2935	TW	Taiwan	Changhua	Changhua	24.0667000	120.5333000	226564	2026-01-25 22:40:05.528262+00
2936	CA	Canada	Saskatchewan	Regina	50.4547000	-104.6067000	226404	2026-01-25 22:40:05.528262+00
2937	VN	Vietnam	Cà Mau	Cà Mau	9.1833000	105.1500000	226372	2026-01-25 22:40:05.528262+00
2938	RU	Russia	Moskovskaya Oblast’	Korolëv	55.9167000	37.8167000	226007	2026-01-25 22:40:05.528262+00
2939	CN	China	Heilongjiang	Tieli	46.9500000	128.0500000	225960	2026-01-25 22:40:05.528262+00
2940	CN	China	Anhui	Dianbu	31.8883000	117.4608000	225808	2026-01-25 22:40:05.528262+00
2941	RU	Russia	Sankt-Peterburg	Kolpino	59.7333000	30.6000000	225801	2026-01-25 22:40:05.528262+00
2942	MX	Mexico	Guerrero	Chilpancingo	17.5500000	-99.5000000	225728	2026-01-25 22:40:05.528262+00
2943	BR	Brazil	Goiás	Rio Verde	-17.7978000	-50.9278000	225696	2026-01-25 22:40:05.528262+00
2944	PH	Philippines	Bulacan	Meycauayan	14.7300000	120.9500000	225673	2026-01-25 22:40:05.528262+00
2945	BR	Brazil	São Paulo	Presidente Prudente	-22.1258000	-51.3889000	225668	2026-01-25 22:40:05.528262+00
2946	IR	Iran	Tehrān	Varāmīn	35.3503000	51.6364000	225628	2026-01-25 22:40:05.528262+00
2947	ID	Indonesia	Sumatera Utara	Padangsidempuan	1.3786000	99.2722000	225544	2026-01-25 22:40:05.528262+00
2948	AO	Angola	Cuanza-Sul	Uacu Cungo	-11.3583000	15.1194000	225520	2026-01-25 22:40:05.528262+00
2949	IN	India	Tamil Nādu	Pudukkottai	10.3833000	78.8001000	225500	2026-01-25 22:40:05.528262+00
2950	CN	China	Jilin	Hunchun	42.8630000	130.3660000	225454	2026-01-25 22:40:05.528262+00
2951	IN	India	Gujarāt	Nadiād	22.6900000	72.8600000	225132	2026-01-25 22:40:05.528262+00
2952	MG	Madagascar	Toamasina	Toamasina	-18.1550000	49.4100000	225116	2026-01-25 22:40:05.528262+00
2953	US	United States	North Dakota	Fargo	46.8651000	-96.8292000	225066	2026-01-25 22:40:05.528262+00
2954	UA	Ukraine	Ternopilska Oblast	Ternopil	49.5667000	25.6000000	225004	2026-01-25 22:40:05.528262+00
2955	ZW	Zimbabwe	Manicaland	Mutare	-18.9667000	32.6333000	224802	2026-01-25 22:40:05.528262+00
2956	BD	Bangladesh	Khulna	Chuādānga	23.6418000	88.8577000	224576	2026-01-25 22:40:05.528262+00
2957	CU	Cuba	Camagüey	Carlos Manuel de Céspedes	21.5767000	-78.2775000	224488	2026-01-25 22:40:05.528262+00
2958	CN	China	Jilin	Nong’an	44.4347000	125.1750000	224387	2026-01-25 22:40:05.528262+00
2959	JP	Japan	Gunma	Ōta	36.2911000	139.3754000	224358	2026-01-25 22:40:05.528262+00
2960	US	United States	Florida	Deltona	28.9050000	-81.2137000	224303	2026-01-25 22:40:05.528262+00
2961	BR	Brazil	Rio de Janeiro	Itaboraí	-22.7475000	-42.8558000	224267	2026-01-25 22:40:05.528262+00
2962	MX	Mexico	Jalisco	Puerto Vallarta	20.6458000	-105.2222000	224166	2026-01-25 22:40:05.528262+00
2963	PY	Paraguay	Central	Capiatá	-25.3538000	-57.4426000	224152	2026-01-25 22:40:05.528262+00
2964	BR	Brazil	Rio Grande do Sul	Viamão	-30.0808000	-51.0228000	224112	2026-01-25 22:40:05.528262+00
2965	BR	Brazil	Santa Catarina	Chapecó	-27.0958000	-52.6178000	224013	2026-01-25 22:40:05.528262+00
2966	AR	Argentina	Buenos Aires	Banfield	-34.7500000	-58.3833000	223898	2026-01-25 22:40:05.528262+00
2967	JP	Japan	Kanagawa	Atsugichō	35.4333000	139.3667000	223815	2026-01-25 22:40:05.528262+00
2968	BD	Bangladesh	Chattogram	Cox’s Bāzār	21.4539000	91.9677000	223522	2026-01-25 22:40:05.528262+00
2969	IR	Iran	Būshehr	Bandar-e Būshehr	28.9264000	50.8514000	223504	2026-01-25 22:40:05.528262+00
2970	ID	Indonesia	Sumatera Utara	Tanjung Morawa	3.5167000	98.7833000	223450	2026-01-25 22:40:05.528262+00
2971	US	United States	Texas	Brownsville	25.9975000	-97.4580000	223416	2026-01-25 22:40:05.528262+00
2972	BR	Brazil	São Paulo	Itapevi	-23.5489000	-46.9342000	223404	2026-01-25 22:40:05.528262+00
2973	ID	Indonesia	Jawa Timur	Probolinggo	-7.7500000	113.2167000	223159	2026-01-25 22:40:05.528262+00
2974	IN	India	Tamil Nādu	Tanjore	10.7870000	79.1378000	222943	2026-01-25 22:40:05.528262+00
2975	DE	Germany	Rhineland-Palatinate	Mainz	49.9994000	8.2736000	222889	2026-01-25 22:40:05.528262+00
2976	JP	Japan	Aomori	Hachinohe	40.5123000	141.4884000	222799	2026-01-25 22:40:05.528262+00
2977	AO	Angola	Bengo	Barra do Dande	-8.4728000	13.3731000	222528	2026-01-25 22:40:05.528262+00
2978	TR	Turkey	Mersin	Mezitli	36.7500000	34.5333000	222436	2026-01-25 22:40:05.528262+00
2979	ZA	South Africa	Gauteng	Sandton	-26.1070000	28.0517000	222415	2026-01-25 22:40:05.528262+00
2980	RU	Russia	Novgorodskaya Oblast’	Velikiy Novgorod	58.5500000	31.2667000	222340	2026-01-25 22:40:05.528262+00
2981	IE	Ireland	Cork	Cork	51.9000000	-8.4731000	222333	2026-01-25 22:40:05.528262+00
2982	TL	Timor-Leste	Díli	Dili	-8.5594000	125.5795000	222323	2026-01-25 22:40:05.528262+00
2983	GR	Greece	Thessalía	Týrnavos	39.7333000	22.2833000	222280	2026-01-25 22:40:05.528262+00
2984	NG	Nigeria	Ondo	Owo	7.1961000	5.5864000	222262	2026-01-25 22:40:05.528262+00
2985	GB	United Kingdom	Swindon	Swindon	51.5600000	-1.7800000	222193	2026-01-25 22:40:05.528262+00
2986	ID	Indonesia	Jawa Barat	Ciputat	-6.3111000	106.7619000	222186	2026-01-25 22:40:05.528262+00
2987	ES	Spain	Catalonia	Sabadell	41.5486000	2.1075000	222177	2026-01-25 22:40:05.528262+00
2988	MM	Burma	Tanintharyi	Myeik	12.4333000	98.6000000	222056	2026-01-25 22:40:05.528262+00
2989	IN	India	Uttarākhand	Kichha	28.9200000	79.5000000	221965	2026-01-25 22:40:05.528262+00
2990	US	United States	Florida	Hialeah	25.8696000	-80.3045000	221901	2026-01-25 22:40:05.528262+00
2991	CN	China	Guangdong	Longjiang	22.8853000	113.0758000	221881	2026-01-25 22:40:05.528262+00
2992	IN	India	Madhya Pradesh	Katri	23.4800000	80.4000000	221875	2026-01-25 22:40:05.528262+00
2993	JP	Japan	Hyōgo	Takarazuka	34.8114000	135.3406000	221846	2026-01-25 22:40:05.528262+00
2994	US	United States	California	San Bernardino	34.1416000	-117.2943000	221774	2026-01-25 22:40:05.528262+00
2995	TR	Turkey	Adana	Sarıçam	37.0333000	35.4167000	221733	2026-01-25 22:40:05.528262+00
2996	GN	Guinea	N’Zérékoré	Guéckédou	8.5667000	-10.1333000	221715	2026-01-25 22:40:05.528262+00
2997	IR	Iran	Khorāsān-e Raẕavī	Neyshābūr	36.2200000	58.8200000	221700	2026-01-25 22:40:05.528262+00
2998	CN	China	Guangdong	Xiqiao	22.9409000	112.9819000	221670	2026-01-25 22:40:05.528262+00
2999	YE	Yemen	Ibb	Ibb	13.9667000	44.1667000	221472	2026-01-25 22:40:05.528262+00
3000	VN	Vietnam	Sóc Trăng	Sóc Trăng	9.6028000	105.9736000	221430	2026-01-25 22:40:05.528262+00
\.


--
-- Data for Name: metrics_queue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.metrics_queue (id, payload, created_at, processed, processed_at) FROM stdin;
1	{"ok": true, "city": "Wekiwa Springs", "time": "2026-01-25T17:43:07-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_dash_home", "os_name": "Windows", "tile_id": "tile_dashboard", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://example.com", "page_url": "http://localhost/linknest/#/tile/tile_dashboard?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "2378d1fc3b27ad1478148e31bf254b00e8e6a375255cf2935ae7b2bfe0dbb21f", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769380987631, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": null, "response_type": "opaque", "error_category": "cors_opaque", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 34, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:43:07.852562+00	t	2026-01-25 22:45:13.35109+00
2	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:43:07-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_dash_portal", "os_name": "Windows", "tile_id": "tile_dashboard", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://portal.example.com", "page_url": "http://localhost/linknest/#/tile/tile_dashboard?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "944524a07529054983f439f1a9ee05358a0ed681d94478cf5c03875fece18fcb", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769380987631, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 40, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://portal.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:43:07.860239+00	t	2026-01-25 22:45:13.35109+00
3	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:43:07-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_dash_email", "os_name": "Windows", "tile_id": "tile_dashboard", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://mail.example.com", "page_url": "http://localhost/linknest/#/tile/tile_dashboard?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "90fc625553d8698fd651c288d7ecea59ef1bdcfbb63fd8a652c6eacea9b4f9e6", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769380987631, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 40, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://mail.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:43:07.867247+00	t	2026-01-25 22:45:13.35109+00
4	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:43:07-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_dash_sales", "os_name": "Windows", "tile_id": "tile_dashboard", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://reports.example.com/sales", "page_url": "http://localhost/linknest/#/tile/tile_dashboard?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "396efea4dd262c4d1b371e8dd8c93ba23be6c9dc677b2e16486cec342ec81169", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769380987631, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 40, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://reports.example.com/sales", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:43:07.872945+00	t	2026-01-25 22:45:13.35109+00
5	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:43:07-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_dash_hr", "os_name": "Windows", "tile_id": "tile_dashboard", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://reports.example.com/hr", "page_url": "http://localhost/linknest/#/tile/tile_dashboard?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "b9bec014ed1921545f9e5940bdf7c4d03ce5692954039947f64ae53265ca453f", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769380987671, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 28, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://reports.example.com/hr", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:43:07.879473+00	t	2026-01-25 22:45:13.35109+00
6	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:43:07-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_dash_admin", "os_name": "Windows", "tile_id": "tile_dashboard", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://admin.example.com", "page_url": "http://localhost/linknest/#/tile/tile_dashboard?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "49bfc235630ca541d10b5c6252e03222699a61c2a6ff99cb0405d57a3f29b4d0", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769380987671, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 46, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://admin.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:43:07.885557+00	t	2026-01-25 22:45:13.35109+00
10	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:45:20-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_dash_sales", "os_name": "Windows", "tile_id": "tile_dashboard", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://reports.example.com/sales", "page_url": "http://localhost/linknest/#/tile/tile_dashboard?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "199eaecb6725d01bb46c7a853d8907040aa8d1ef94ab5000e4e8889df9e79229", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381120525, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 40, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://reports.example.com/sales", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:45:20.737258+00	t	2026-01-25 22:45:21.425016+00
11	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:45:20-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_dash_hr", "os_name": "Windows", "tile_id": "tile_dashboard", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://reports.example.com/hr", "page_url": "http://localhost/linknest/#/tile/tile_dashboard?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "1137110dbdf1124f8ac73d0fe68c6a779260fd10305563a3df6d2f10b5815181", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381120568, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 45, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://reports.example.com/hr", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:45:20.745024+00	t	2026-01-25 22:45:21.425016+00
7	{"ok": true, "city": "Wekiwa Springs", "time": "2026-01-25T17:45:20-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_dash_home", "os_name": "Windows", "tile_id": "tile_dashboard", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://example.com", "page_url": "http://localhost/linknest/#/tile/tile_dashboard?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "c4909ee0d88a8de6aae15beb59fab10e5db07658b82563641b9df27a415d9b01", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381120525, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": null, "response_type": "opaque", "error_category": "cors_opaque", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 43, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:45:20.713968+00	t	2026-01-25 22:45:21.425016+00
8	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:45:20-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_dash_portal", "os_name": "Windows", "tile_id": "tile_dashboard", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://portal.example.com", "page_url": "http://localhost/linknest/#/tile/tile_dashboard?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "7d879f5db6bf25b66ba387cee22aaf51f9014aaee5c4a4e09fb36b8f0e31f996", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381120525, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 35, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://portal.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:45:20.721393+00	t	2026-01-25 22:45:21.425016+00
9	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:45:20-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_dash_email", "os_name": "Windows", "tile_id": "tile_dashboard", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://mail.example.com", "page_url": "http://localhost/linknest/#/tile/tile_dashboard?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "b68a7e001da4b1276047e0cdc4111ede380989725460a41a9fb1afb6ec9bd9b6", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381120525, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 41, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://mail.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:45:20.728711+00	t	2026-01-25 22:45:21.425016+00
12	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:45:20-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_dash_admin", "os_name": "Windows", "tile_id": "tile_dashboard", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://admin.example.com", "page_url": "http://localhost/linknest/#/tile/tile_dashboard?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "792622664e815c623c350c45f06566727f3ff839904f7c1850cb5db3ae7d8c78", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381120568, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 45, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://admin.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:45:20.753195+00	t	2026-01-25 22:45:21.425016+00
13	{"ok": true, "city": "Wekiwa Springs", "time": "2026-01-25T17:46:27-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_dash_home", "os_name": "Windows", "tile_id": "tile_dashboard", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://example.com", "page_url": "http://localhost/linknest/#/tile/tile_dashboard?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "3b604af4b9404b0e7e687c71c861679bfab6f1d539e67bf251a811dd9762a39f", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381186810, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": null, "response_type": "opaque", "error_category": "cors_opaque", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 38, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:46:27.025407+00	t	2026-01-25 22:46:27.822425+00
14	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:46:27-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_dash_portal", "os_name": "Windows", "tile_id": "tile_dashboard", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://portal.example.com", "page_url": "http://localhost/linknest/#/tile/tile_dashboard?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "d82aa006a0f603091ab2bbc9e87cd22524501ff7f84e3810134f851aa4ed7324", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381186810, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 58, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://portal.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:46:27.035153+00	t	2026-01-25 22:46:27.822425+00
15	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:46:27-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_dash_email", "os_name": "Windows", "tile_id": "tile_dashboard", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://mail.example.com", "page_url": "http://localhost/linknest/#/tile/tile_dashboard?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "17720c25d14c0488576475d6aef6e8f1f068bcc48ba15ea8ad26a26159ef71e5", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381186810, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 43, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://mail.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:46:27.04053+00	t	2026-01-25 22:46:27.822425+00
16	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:46:27-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_dash_sales", "os_name": "Windows", "tile_id": "tile_dashboard", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://reports.example.com/sales", "page_url": "http://localhost/linknest/#/tile/tile_dashboard?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "88c3f4cca1a7e78fe3a6efe68dc6e7010608e689650bc00d073d6dfc0e94b0f8", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381186810, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 58, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://reports.example.com/sales", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:46:27.045852+00	t	2026-01-25 22:46:27.822425+00
17	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:46:27-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_dash_hr", "os_name": "Windows", "tile_id": "tile_dashboard", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://reports.example.com/hr", "page_url": "http://localhost/linknest/#/tile/tile_dashboard?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "4c1ac150be6c3602e3851f64b512a5a9c20f3c2001f189fe4b7bb9c953dd8753", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381186868, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 42, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://reports.example.com/hr", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:46:27.051239+00	t	2026-01-25 22:46:27.822425+00
18	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:46:27-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_dash_admin", "os_name": "Windows", "tile_id": "tile_dashboard", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://admin.example.com", "page_url": "http://localhost/linknest/#/tile/tile_dashboard?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "c59987478de14eae445a8310b6967cc31940d66831c7c4127ed9d0cd4c24b10f", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381186868, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 62, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://admin.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:46:27.056437+00	t	2026-01-25 22:46:27.822425+00
23	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:46:33-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_analytics_reports", "os_name": "Windows", "tile_id": "tile_analytics", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://analytics.example.com", "page_url": "http://localhost/linknest/#/tile/tile_analytics?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "1e5a3da5bd6bc4b2a34a89c8cc41fb8dc83f454ef72437b924053708e21439d9", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381193149, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 41, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://analytics.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:46:33.385187+00	t	2026-01-25 22:46:33.867467+00
24	{"ok": true, "city": "Wekiwa Springs", "time": "2026-01-25T17:46:33-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_analytics_google", "os_name": "Windows", "tile_id": "tile_analytics", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://analytics.google.com", "page_url": "http://localhost/linknest/#/tile/tile_analytics?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "357def99a3b18d5151deb68caf808225f25611bba6246ca29ef2b6f0820ed7bf", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381193149, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": null, "response_type": "opaque", "error_category": "cors_opaque", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 130, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://analytics.google.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:46:33.391132+00	t	2026-01-25 22:46:33.867467+00
19	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:46:32-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_analytics_bi", "os_name": "Windows", "tile_id": "tile_analytics", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://bi.example.com", "page_url": "http://localhost/linknest/#/tile/tile_analytics?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "946cdf3c8ccdcf23a2d02390b831f1532618af2bf68a2b45dcda9ae7c29e58d9", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381192305, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 98, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://bi.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:46:32.608435+00	t	2026-01-25 22:46:33.867467+00
20	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:46:32-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_analytics_reports", "os_name": "Windows", "tile_id": "tile_analytics", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://analytics.example.com", "page_url": "http://localhost/linknest/#/tile/tile_analytics?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "4b072bd0c4f13e7596db243ca3d65926377d4dc6698253223114bab2e026005a", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381192305, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 143, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://analytics.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:46:32.614949+00	t	2026-01-25 22:46:33.867467+00
21	{"ok": true, "city": "Wekiwa Springs", "time": "2026-01-25T17:46:32-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_analytics_google", "os_name": "Windows", "tile_id": "tile_analytics", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://analytics.google.com", "page_url": "http://localhost/linknest/#/tile/tile_analytics?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "88502925add3ec17471f7842c7ef654cfef45d5ded2e1e29595fb98fcdce3c76", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381192305, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": null, "response_type": "opaque", "error_category": "cors_opaque", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 216, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://analytics.google.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:46:32.620358+00	t	2026-01-25 22:46:33.867467+00
22	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:46:33-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_analytics_bi", "os_name": "Windows", "tile_id": "tile_analytics", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://bi.example.com", "page_url": "http://localhost/linknest/#/tile/tile_analytics?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "3ee80480bff702540173a7d84d07f41677b26cd273537a587fc7867412f557a3", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381193149, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 41, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://bi.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:46:33.375945+00	t	2026-01-25 22:46:33.867467+00
25	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:47:20-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_analytics_bi", "os_name": "Windows", "tile_id": "tile_analytics", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://bi.example.com", "page_url": "http://localhost/linknest/#/tile/tile_analytics?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "78d4c7abe20b3a4c8492a7604c25a0317e082312292f9dd70063c390dc1b5d14", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381240311, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 48, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://bi.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:47:20.558927+00	t	2026-01-25 22:47:22.149866+00
26	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:47:20-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_analytics_reports", "os_name": "Windows", "tile_id": "tile_analytics", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://analytics.example.com", "page_url": "http://localhost/linknest/#/tile/tile_analytics?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "8d8578de4b97fee5713e6108df167bf07ac11679f542c31374a8a9cce6473cb2", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381240311, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 48, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://analytics.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:47:20.565973+00	t	2026-01-25 22:47:22.149866+00
27	{"ok": true, "city": "Wekiwa Springs", "time": "2026-01-25T17:47:20-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_analytics_google", "os_name": "Windows", "tile_id": "tile_analytics", "user_id": 2, "latitude": 28.7035496208061, "link_url": "https://analytics.google.com", "page_url": "http://localhost/linknest/#/tile/tile_analytics?from=public", "username": "admin", "final_url": null, "longitude": -81.41565546810432, "cache_mode": "no-store", "dedupe_key": "d1a2062d1a1e763351d865c4a06e5865921c281de798de68350519ac3648bcdc", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381240312, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": null, "response_type": "opaque", "error_category": "cors_opaque", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 131, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://analytics.google.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:47:20.570771+00	t	2026-01-25 22:47:22.149866+00
28	{"ip": "::1", "type": "user_login", "user_id": 2, "username": "admin", "timestamp": 1769381312, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "geolocation": {"latitude": 0, "timezone": "UTC", "city_name": "Unknown", "longitude": 0, "region_name": "Local Network", "country_code": "XX", "country_name": "Local/Private"}}	2026-01-25 22:48:32.279803+00	t	2026-01-25 22:48:32.550517+00
29	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:49:56-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_finance_accounting", "os_name": "Windows", "tile_id": "tile_finance", "user_id": 2, "latitude": 28.70369015773896, "link_url": "https://accounting.example.com", "page_url": "http://localhost/linknest/#/tile/tile_finance?from=public", "username": "admin", "final_url": null, "longitude": -81.41540265095306, "cache_mode": "no-store", "dedupe_key": "8b8f00d7adcf13374df8e25af7e11bd39ea90ce2880802472f095d79e529185d", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381396113, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 33, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://accounting.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:49:56.248978+00	t	2026-01-25 22:49:57.002854+00
30	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:49:56-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_finance_invoicing", "os_name": "Windows", "tile_id": "tile_finance", "user_id": 2, "latitude": 28.70369015773896, "link_url": "https://invoices.example.com", "page_url": "http://localhost/linknest/#/tile/tile_finance?from=public", "username": "admin", "final_url": null, "longitude": -81.41540265095306, "cache_mode": "no-store", "dedupe_key": "d6fc90b0496b539548f3b0b759b0386552d543acbc8cc8a056872261823f8898", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381396113, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 27, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://invoices.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:49:56.258585+00	t	2026-01-25 22:49:57.002854+00
31	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:49:56-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_finance_reports", "os_name": "Windows", "tile_id": "tile_finance", "user_id": 2, "latitude": 28.70369015773896, "link_url": "https://finance.example.com/reports", "page_url": "http://localhost/linknest/#/tile/tile_finance?from=public", "username": "admin", "final_url": null, "longitude": -81.41540265095306, "cache_mode": "no-store", "dedupe_key": "59314bc64adf6914c69def58339a8ea014555e397c1067b6e17c3d7feec8f4d6", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381396114, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 33, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://finance.example.com/reports", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:49:56.2637+00	t	2026-01-25 22:49:57.002854+00
32	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:49:56-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_finance_accounting", "os_name": "Windows", "tile_id": "tile_finance", "user_id": 2, "latitude": 28.70369015773896, "link_url": "https://accounting.example.com", "page_url": "http://localhost/linknest/#/tile/tile_finance?from=public", "username": "admin", "final_url": null, "longitude": -81.41540265095306, "cache_mode": "no-store", "dedupe_key": "a003f3ca0303b8d03206b9225583a98be53cc354b12843e457d5391d4898a499", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381396742, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 28, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://accounting.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:49:56.88391+00	t	2026-01-25 22:49:57.002854+00
33	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:49:56-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_finance_invoicing", "os_name": "Windows", "tile_id": "tile_finance", "user_id": 2, "latitude": 28.70369015773896, "link_url": "https://invoices.example.com", "page_url": "http://localhost/linknest/#/tile/tile_finance?from=public", "username": "admin", "final_url": null, "longitude": -81.41540265095306, "cache_mode": "no-store", "dedupe_key": "f240e3a711b6ce2f85a941eba58ead43db92b9f6a531dbeaddf46c95601dd4e0", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381396742, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 39, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://invoices.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:49:56.893362+00	t	2026-01-25 22:49:57.002854+00
34	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:49:56-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_finance_reports", "os_name": "Windows", "tile_id": "tile_finance", "user_id": 2, "latitude": 28.70369015773896, "link_url": "https://finance.example.com/reports", "page_url": "http://localhost/linknest/#/tile/tile_finance?from=public", "username": "admin", "final_url": null, "longitude": -81.41540265095306, "cache_mode": "no-store", "dedupe_key": "65dcf038c2a02e3cff17acfd963d94753db50982dd42b5614a8876663209d44d", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381396742, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 39, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://finance.example.com/reports", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:49:56.897951+00	t	2026-01-25 22:49:57.002854+00
35	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:50:09-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_finance_accounting", "os_name": "Windows", "tile_id": "tile_finance", "user_id": 2, "latitude": 28.70369015773896, "link_url": "https://accounting.example.com", "page_url": "http://localhost/linknest/#/tile/tile_finance?from=public", "username": "admin", "final_url": null, "longitude": -81.41540265095306, "cache_mode": "no-store", "dedupe_key": "e18db251033138b38f194c6b12cfcf95d57488a62064b978484988bc760dfd6a", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381408920, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 50, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://accounting.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:50:09.073579+00	t	2026-01-25 22:50:09.096422+00
36	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:50:09-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_finance_invoicing", "os_name": "Windows", "tile_id": "tile_finance", "user_id": 2, "latitude": 28.70369015773896, "link_url": "https://invoices.example.com", "page_url": "http://localhost/linknest/#/tile/tile_finance?from=public", "username": "admin", "final_url": null, "longitude": -81.41540265095306, "cache_mode": "no-store", "dedupe_key": "2f61d1158c30fb0e4d4b7978e8cc9119d6b498b1e0dfa48f6a19f35790fc6cf9", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381408920, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 43, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://invoices.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:50:09.083826+00	t	2026-01-25 22:50:09.096422+00
37	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:50:09-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_finance_reports", "os_name": "Windows", "tile_id": "tile_finance", "user_id": 2, "latitude": 28.70369015773896, "link_url": "https://finance.example.com/reports", "page_url": "http://localhost/linknest/#/tile/tile_finance?from=public", "username": "admin", "final_url": null, "longitude": -81.41540265095306, "cache_mode": "no-store", "dedupe_key": "34eafb021ad96de0f5ef5f2ff007d11687748fc8d345a0ebd670b48879f13940", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381408920, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 50, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://finance.example.com/reports", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:50:09.088933+00	t	2026-01-25 22:50:09.096422+00
38	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:50:13-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_cust_portal", "os_name": "Windows", "tile_id": "tile_customer_portal", "user_id": 2, "latitude": 28.70369015773896, "link_url": "https://customers.example.com", "page_url": "http://localhost/linknest/#/tile/tile_customer_portal?from=public", "username": "admin", "final_url": null, "longitude": -81.41540265095306, "cache_mode": "no-store", "dedupe_key": "103ee769b238f2c306fa6ccbdd1594fbdeed430e9dc75c43246d01fc3d1bebd8", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381413386, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 31, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://customers.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:50:13.53015+00	t	2026-01-25 22:50:15.145867+00
39	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:50:13-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_cust_support", "os_name": "Windows", "tile_id": "tile_customer_portal", "user_id": 2, "latitude": 28.70369015773896, "link_url": "https://support.example.com", "page_url": "http://localhost/linknest/#/tile/tile_customer_portal?from=public", "username": "admin", "final_url": null, "longitude": -81.41540265095306, "cache_mode": "no-store", "dedupe_key": "ecdf5a95e9ba7c52b80604cfc64d6110db03a34254ede87f9e4ab72505041545", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381413386, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 33, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://support.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:50:13.539774+00	t	2026-01-25 22:50:15.145867+00
40	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:50:13-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_cust_tickets", "os_name": "Windows", "tile_id": "tile_customer_portal", "user_id": 2, "latitude": 28.70369015773896, "link_url": "https://tickets.example.com", "page_url": "http://localhost/linknest/#/tile/tile_customer_portal?from=public", "username": "admin", "final_url": null, "longitude": -81.41540265095306, "cache_mode": "no-store", "dedupe_key": "d336408b4ca9bb72832833c55ced443d9d93417efcd7f2f0916ec4d1b624d200", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381413386, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 49, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://tickets.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:50:13.544684+00	t	2026-01-25 22:50:15.145867+00
41	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:50:18-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_servers_nagios", "os_name": "Windows", "tile_id": "tile_servers", "user_id": 2, "latitude": 28.70369015773896, "link_url": "https://nagios.example.com", "page_url": "http://localhost/linknest/#/tile/tile_servers?from=public", "username": "admin", "final_url": null, "longitude": -81.41540265095306, "cache_mode": "no-store", "dedupe_key": "a92522eb01f0783f1382c1bf6584d1bee40b053d6557a8eec8454360d6e7d052", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381417888, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 32, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://nagios.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:50:18.031016+00	t	2026-01-25 22:50:19.175642+00
42	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:50:18-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_servers_config", "os_name": "Windows", "tile_id": "tile_servers", "user_id": 2, "latitude": 28.70369015773896, "link_url": "https://config.example.com", "page_url": "http://localhost/linknest/#/tile/tile_servers?from=public", "username": "admin", "final_url": null, "longitude": -81.41540265095306, "cache_mode": "no-store", "dedupe_key": "bc8dd812f89b6a9b4246c7498d0d62aad9226a47eaa844a220103181b7f46779", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381417888, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 49, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://config.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:50:18.037375+00	t	2026-01-25 22:50:19.175642+00
43	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:50:20-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_servers_nagios", "os_name": "Windows", "tile_id": "tile_servers", "user_id": 2, "latitude": 28.70369015773896, "link_url": "https://nagios.example.com", "page_url": "http://localhost/linknest/#/tile/tile_servers?from=public", "username": "admin", "final_url": null, "longitude": -81.41540265095306, "cache_mode": "no-store", "dedupe_key": "5fc66e8acf7702778a3108d21dc91e8f7028b970809c5afb273606c0eae0ff65", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381420280, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 38, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://nagios.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:50:20.419699+00	t	2026-01-25 22:50:21.200363+00
44	{"ok": false, "city": "Wekiwa Springs", "time": "2026-01-25T17:50:20-05:00", "method": "HEAD", "region": "Florida", "link_id": "link_servers_config", "os_name": "Windows", "tile_id": "tile_servers", "user_id": 2, "latitude": 28.70369015773896, "link_url": "https://config.example.com", "page_url": "http://localhost/linknest/#/tile/tile_servers?from=public", "username": "admin", "final_url": null, "longitude": -81.41540265095306, "cache_mode": "no-store", "dedupe_key": "6546f3fb22f447537743ab4364c49f84c389a107a148db914e9f2b523535839b", "ip_address": "::1", "redirected": false, "session_id": "bt7dgr3u28nerma8v5hhnpp7p7", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381420280, "browser_name": "Chrome", "country_code": "US", "country_name": "United States", "download_time": null, "error_message": "Failed to fetch", "response_type": null, "error_category": "network", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": null, "page_size_bytes": null, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 37, "time_to_first_byte": null, "tls_handshake_time": null, "link_url_normalized": "https://config.example.com/", "tcp_connection_time": null, "dom_content_loaded_time": null}	2026-01-25 22:50:20.429176+00	t	2026-01-25 22:50:21.200363+00
45	{"ok": true, "city": "Test City", "time": "2026-01-25T17:59:00-05:00", "method": "HEAD", "region": "Test", "link_id": null, "os_name": "Windows", "tile_id": null, "user_id": 1, "latitude": 0, "link_url": "https://stackoverflow.com/", "page_url": "http://localhost:9333/diagnostic.html", "username": "zafar", "final_url": null, "longitude": 0, "cache_mode": "no-cache", "ip_address": "::1", "redirected": false, "session_id": "diagnostic-1769381937246", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381939260, "browser_name": "Chrome", "country_code": "US", "download_time": 0, "error_message": null, "response_type": "opaque", "error_category": "cors_opaque", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": 0, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 326, "time_to_first_byte": 0, "tls_handshake_time": 0, "link_url_normalized": "https://stackoverflow.com/", "tcp_connection_time": 0}	2026-01-25 22:59:00.062566+00	t	2026-01-25 22:59:00.11905+00
46	{"ok": true, "city": "Test City", "time": "2026-01-25T17:59:00-05:00", "method": "HEAD", "region": "Test", "link_id": null, "os_name": "Windows", "tile_id": null, "user_id": 1, "latitude": 0, "link_url": "https://google.com/", "page_url": "http://localhost:9333/diagnostic.html", "username": "zafar", "final_url": null, "longitude": 0, "cache_mode": "no-cache", "ip_address": "::1", "redirected": false, "session_id": "diagnostic-1769381937246", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381939260, "browser_name": "Chrome", "country_code": "US", "download_time": 0, "error_message": null, "response_type": "opaque", "error_category": "cors_opaque", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": 0, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 689, "time_to_first_byte": 0, "tls_handshake_time": 0, "link_url_normalized": "https://google.com/", "tcp_connection_time": 0}	2026-01-25 22:59:00.076463+00	t	2026-01-25 22:59:00.11905+00
47	{"ok": true, "city": "Test City", "time": "2026-01-25T17:59:00-05:00", "method": "HEAD", "region": "Test", "link_id": null, "os_name": "Windows", "tile_id": null, "user_id": 1, "latitude": 0, "link_url": "https://github.com/", "page_url": "http://localhost:9333/diagnostic.html", "username": "zafar", "final_url": null, "longitude": 0, "cache_mode": "no-cache", "ip_address": "::1", "redirected": false, "session_id": "diagnostic-1769381937246", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381939260, "browser_name": "Chrome", "country_code": "US", "download_time": 0, "error_message": null, "response_type": "opaque", "error_category": "cors_opaque", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": 0, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 158, "time_to_first_byte": 0, "tls_handshake_time": 0, "link_url_normalized": "https://github.com/", "tcp_connection_time": 0}	2026-01-25 22:59:00.076503+00	t	2026-01-25 22:59:00.11905+00
48	{"ok": true, "city": "Test City", "time": "2026-01-25T17:59:04-05:00", "method": "HEAD", "region": "Test", "link_id": null, "os_name": "Windows", "tile_id": null, "user_id": 1, "latitude": 0, "link_url": "https://github.com/", "page_url": "http://localhost:9333/diagnostic.html", "username": "zafar", "final_url": null, "longitude": 0, "cache_mode": "no-cache", "ip_address": "::1", "redirected": false, "session_id": "diagnostic-1769381937246", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381943571, "browser_name": "Chrome", "country_code": "US", "download_time": 0, "error_message": null, "response_type": "opaque", "error_category": "cors_opaque", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": 0, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 48, "time_to_first_byte": 0, "tls_handshake_time": 0, "link_url_normalized": "https://github.com/", "tcp_connection_time": 0}	2026-01-25 22:59:04.171444+00	t	2026-01-25 22:59:06.166972+00
49	{"ok": true, "city": "Test City", "time": "2026-01-25T17:59:04-05:00", "method": "HEAD", "region": "Test", "link_id": null, "os_name": "Windows", "tile_id": null, "user_id": 1, "latitude": 0, "link_url": "https://stackoverflow.com/", "page_url": "http://localhost:9333/diagnostic.html", "username": "zafar", "final_url": null, "longitude": 0, "cache_mode": "no-cache", "ip_address": "::1", "redirected": false, "session_id": "diagnostic-1769381937246", "timeout_ms": 5000, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", "device_type": "desktop", "attempted_at": 1769381943571, "browser_name": "Chrome", "country_code": "US", "download_time": 0, "error_message": null, "response_type": "opaque", "error_category": "cors_opaque", "browser_version": "144", "connection_type": "4g", "dns_lookup_time": 0, "http_status_code": 0, "is_authenticated": true, "measurement_type": "client", "screen_resolution": "1829x1029", "full_response_time": 216, "time_to_first_byte": 0, "tls_handshake_time": 0, "link_url_normalized": "https://stackoverflow.com/", "tcp_connection_time": 0}	2026-01-25 22:59:04.185183+00	t	2026-01-25 22:59:06.166972+00
\.


--
-- Data for Name: performance_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.performance_metrics ("time", link_url, link_id, page_url, measurement_type, user_id, username, session_id, is_authenticated, ip_address, continent_code, country_code, country_name, region_name, city_name, latitude, longitude, timezone, isp, dns_lookup_time, tcp_connection_time, tls_handshake_time, time_to_first_byte, dom_content_loaded_time, full_response_time, page_size_bytes, http_status_code, error_message, connection_type, device_type, browser_name, browser_version, os_name, screen_resolution, created_at) FROM stdin;
\.


--
-- Data for Name: user_geolocations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_geolocations (id, user_id, username, login_time, ip_address, continent_code, country_code, country_name, region_name, city_name, latitude, longitude, timezone, isp, session_id, user_agent, device_type, browser_name, os_name, is_new_location, last_seen) FROM stdin;
1	2	admin	2026-01-25 22:48:32.286968+00	::1	\N	US	United States	Florida	Wekiwa Springs	28.703690	-81.415403	America/New_York	\N	\N	\N	\N	\N	\N	t	2026-01-25 22:49:55.768509+00
\.


--
-- Name: chunk_column_stats_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_column_stats_id_seq', 1, false);


--
-- Name: chunk_constraint_name; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_constraint_name', 1, false);


--
-- Name: chunk_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_id_seq', 1, true);


--
-- Name: continuous_agg_migrate_plan_step_step_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.continuous_agg_migrate_plan_step_step_id_seq', 1, false);


--
-- Name: dimension_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_id_seq', 2, true);


--
-- Name: dimension_slice_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_slice_id_seq', 1, true);


--
-- Name: hypertable_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.hypertable_id_seq', 3, true);


--
-- Name: bgw_job_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_config; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_config.bgw_job_id_seq', 1002, true);


--
-- Name: alert_thresholds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.alert_thresholds_id_seq', 1, false);


--
-- Name: location_lookup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.location_lookup_id_seq', 3793, true);


--
-- Name: metrics_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.metrics_queue_id_seq', 49, true);


--
-- Name: user_geolocations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_geolocations_id_seq', 2, true);


--
-- Name: alert_thresholds alert_thresholds_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_thresholds
    ADD CONSTRAINT alert_thresholds_pkey PRIMARY KEY (id);


--
-- Name: link_latency_summary link_latency_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.link_latency_summary
    ADD CONSTRAINT link_latency_summary_pkey PRIMARY KEY (link_url);


--
-- Name: location_lookup location_lookup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location_lookup
    ADD CONSTRAINT location_lookup_pkey PRIMARY KEY (id);


--
-- Name: metrics_queue metrics_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.metrics_queue
    ADD CONSTRAINT metrics_queue_pkey PRIMARY KEY (id);


--
-- Name: user_geolocations user_geolocations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_geolocations
    ADD CONSTRAINT user_geolocations_pkey PRIMARY KEY (id);


--
-- Name: user_geolocations user_geolocations_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_geolocations
    ADD CONSTRAINT user_geolocations_user_id_key UNIQUE (user_id);


--
-- Name: _hyper_1_1_chunk_idx_perf_anonymous; Type: INDEX; Schema: _timescaledb_internal; Owner: postgres
--

CREATE INDEX _hyper_1_1_chunk_idx_perf_anonymous ON _timescaledb_internal._hyper_1_1_chunk USING btree (ip_address, "time" DESC) WHERE (NOT is_authenticated);


--
-- Name: _hyper_1_1_chunk_idx_perf_ip_time; Type: INDEX; Schema: _timescaledb_internal; Owner: postgres
--

CREATE INDEX _hyper_1_1_chunk_idx_perf_ip_time ON _timescaledb_internal._hyper_1_1_chunk USING btree (ip_address, "time" DESC) WHERE (ip_address IS NOT NULL);


--
-- Name: _hyper_1_1_chunk_idx_perf_measurement_type; Type: INDEX; Schema: _timescaledb_internal; Owner: postgres
--

CREATE INDEX _hyper_1_1_chunk_idx_perf_measurement_type ON _timescaledb_internal._hyper_1_1_chunk USING btree (measurement_type, "time" DESC);


--
-- Name: _hyper_1_1_chunk_idx_perf_region_time; Type: INDEX; Schema: _timescaledb_internal; Owner: postgres
--

CREATE INDEX _hyper_1_1_chunk_idx_perf_region_time ON _timescaledb_internal._hyper_1_1_chunk USING btree (country_code, region_name, "time" DESC);


--
-- Name: _hyper_1_1_chunk_idx_perf_url_time; Type: INDEX; Schema: _timescaledb_internal; Owner: postgres
--

CREATE INDEX _hyper_1_1_chunk_idx_perf_url_time ON _timescaledb_internal._hyper_1_1_chunk USING btree (link_url, "time" DESC);


--
-- Name: _hyper_1_1_chunk_idx_perf_user_time; Type: INDEX; Schema: _timescaledb_internal; Owner: postgres
--

CREATE INDEX _hyper_1_1_chunk_idx_perf_user_time ON _timescaledb_internal._hyper_1_1_chunk USING btree (user_id, "time" DESC) WHERE (user_id IS NOT NULL);


--
-- Name: _hyper_1_1_chunk_idx_perf_username_time; Type: INDEX; Schema: _timescaledb_internal; Owner: postgres
--

CREATE INDEX _hyper_1_1_chunk_idx_perf_username_time ON _timescaledb_internal._hyper_1_1_chunk USING btree (username, "time" DESC) WHERE (username IS NOT NULL);


--
-- Name: _hyper_1_1_chunk_performance_metrics_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: postgres
--

CREATE INDEX _hyper_1_1_chunk_performance_metrics_time_idx ON _timescaledb_internal._hyper_1_1_chunk USING btree ("time" DESC);


--
-- Name: _materialized_hypertable_3_bucket_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: postgres
--

CREATE INDEX _materialized_hypertable_3_bucket_idx ON _timescaledb_internal._materialized_hypertable_3 USING btree (bucket DESC);


--
-- Name: _materialized_hypertable_3_country_code_bucket_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: postgres
--

CREATE INDEX _materialized_hypertable_3_country_code_bucket_idx ON _timescaledb_internal._materialized_hypertable_3 USING btree (country_code, bucket DESC);


--
-- Name: _materialized_hypertable_3_country_name_bucket_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: postgres
--

CREATE INDEX _materialized_hypertable_3_country_name_bucket_idx ON _timescaledb_internal._materialized_hypertable_3 USING btree (country_name, bucket DESC);


--
-- Name: _materialized_hypertable_3_link_url_bucket_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: postgres
--

CREATE INDEX _materialized_hypertable_3_link_url_bucket_idx ON _timescaledb_internal._materialized_hypertable_3 USING btree (link_url, bucket DESC);


--
-- Name: _materialized_hypertable_3_measurement_type_bucket_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: postgres
--

CREATE INDEX _materialized_hypertable_3_measurement_type_bucket_idx ON _timescaledb_internal._materialized_hypertable_3 USING btree (measurement_type, bucket DESC);


--
-- Name: _materialized_hypertable_3_region_name_bucket_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: postgres
--

CREATE INDEX _materialized_hypertable_3_region_name_bucket_idx ON _timescaledb_internal._materialized_hypertable_3 USING btree (region_name, bucket DESC);


--
-- Name: idx_location_lookup_coords; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_location_lookup_coords ON public.location_lookup USING btree (latitude, longitude);


--
-- Name: idx_location_lookup_country; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_location_lookup_country ON public.location_lookup USING btree (country_code);


--
-- Name: idx_location_lookup_unique_city; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_location_lookup_unique_city ON public.location_lookup USING btree (country_code, region_name, city_name, latitude, longitude);


--
-- Name: idx_metrics_queue_unprocessed; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_metrics_queue_unprocessed ON public.metrics_queue USING btree (created_at) WHERE (processed = false);


--
-- Name: idx_perf_anonymous; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_perf_anonymous ON public.performance_metrics USING btree (ip_address, "time" DESC) WHERE (is_authenticated = false);


--
-- Name: idx_perf_ip_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_perf_ip_time ON public.performance_metrics USING btree (ip_address, "time" DESC) WHERE (ip_address IS NOT NULL);


--
-- Name: idx_perf_measurement_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_perf_measurement_type ON public.performance_metrics USING btree (measurement_type, "time" DESC);


--
-- Name: idx_perf_region_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_perf_region_time ON public.performance_metrics USING btree (country_code, region_name, "time" DESC);


--
-- Name: idx_perf_url_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_perf_url_time ON public.performance_metrics USING btree (link_url, "time" DESC);


--
-- Name: idx_perf_user_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_perf_user_time ON public.performance_metrics USING btree (user_id, "time" DESC) WHERE (user_id IS NOT NULL);


--
-- Name: idx_perf_username_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_perf_username_time ON public.performance_metrics USING btree (username, "time" DESC) WHERE (username IS NOT NULL);


--
-- Name: idx_summary_delta; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_summary_delta ON public.link_latency_summary USING btree (latency_delta DESC);


--
-- Name: idx_summary_health; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_summary_health ON public.link_latency_summary USING btree (health_status);


--
-- Name: idx_thresholds_enabled; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_thresholds_enabled ON public.alert_thresholds USING btree (is_enabled) WHERE (is_enabled = true);


--
-- Name: idx_user_geo_location; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_geo_location ON public.user_geolocations USING btree (country_code, region_name, city_name);


--
-- Name: idx_user_geo_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_geo_time ON public.user_geolocations USING btree (login_time DESC);


--
-- Name: idx_user_geo_user_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_geo_user_time ON public.user_geolocations USING btree (user_id, login_time DESC);


--
-- Name: performance_metrics_time_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX performance_metrics_time_idx ON public.performance_metrics USING btree ("time" DESC);


--
-- Name: _hyper_1_1_chunk trg_update_link_summary; Type: TRIGGER; Schema: _timescaledb_internal; Owner: postgres
--

CREATE TRIGGER trg_update_link_summary AFTER INSERT ON _timescaledb_internal._hyper_1_1_chunk FOR EACH ROW EXECUTE FUNCTION public.update_link_latency_summary();


--
-- Name: performance_metrics trg_update_link_summary; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_update_link_summary AFTER INSERT ON public.performance_metrics FOR EACH ROW EXECUTE FUNCTION public.update_link_latency_summary();


--
-- PostgreSQL database dump complete
--

\unrestrict WRhjzb7xXUoqa9Tr5YeUkfjsAxq9KA5y8cqvMqSswtFv73AW9c70jiI8aEbBSV3

