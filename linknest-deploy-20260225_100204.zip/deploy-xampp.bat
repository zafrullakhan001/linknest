@echo off
setlocal enabledelayedexpansion
REM ==========================================================
REM  LinkNest XAMPP Deployment Script (Windows)
REM  Run this script ONCE on the target computer to deploy.
REM  Works in ANY htdocs subfolder - you choose the name!
REM ==========================================================
echo.
echo  =============================================
echo     LinkNest - XAMPP Deployment (Windows)
echo  =============================================
echo.

REM ---- Ask for XAMPP location -----------------------------------------
set "XAMPP_ROOT=C:\xampp"
set /p "XAMPP_ROOT=XAMPP install path (press Enter for C:\xampp): "
if "%XAMPP_ROOT%"=="" set "XAMPP_ROOT=C:\xampp"
set "HTDOCS=%XAMPP_ROOT%\htdocs"

REM ---- Ask for subfolder name -----------------------------------------
set "SUBFOLDER=linknest"
set /p "SUBFOLDER=Install subfolder inside htdocs (press Enter for 'linknest'): "
if "%SUBFOLDER%"=="" set "SUBFOLDER=linknest"

set "INSTALL_DIR=%HTDOCS%\%SUBFOLDER%"
echo.
echo  XAMPP root  : %XAMPP_ROOT%
echo  Install dir : %INSTALL_DIR%
echo  URL will be : http://localhost/%SUBFOLDER%
echo.

REM ---- Verify XAMPP ---------------------------------------------------
if not exist "%HTDOCS%" (
    echo  ERROR: Cannot find %HTDOCS%
    echo  Make sure XAMPP is installed and you entered the correct path.
    pause
    exit /b 1
)

REM ---- Create / wipe install directory --------------------------------
if exist "%INSTALL_DIR%" (
    echo  Removing old installation at %INSTALL_DIR% ...
    rd /s /q "%INSTALL_DIR%"
)
mkdir "%INSTALL_DIR%"
echo  [OK] Install directory ready

REM ---- Copy all files from this package -------------------------------
echo  Copying application files...
set "PKG_DIR=%~dp0"
if "%PKG_DIR:~-1%"=="\" set "PKG_DIR=%PKG_DIR:~0,-1%"

for %%D in (api components contexts services dist docker data uploads scripts analytics monitorv2 hooks config migrations public src land) do (
    if exist "%PKG_DIR%\%%D" (
        xcopy "%PKG_DIR%\%%D" "%INSTALL_DIR%\%%D\" /E /I /Y >nul 2>&1
    )
)

for %%F in (index.html index.tsx index.css App.tsx types.ts router.php landing.php clones.php backup_restore.php .htaccess package.json package-lock.json vite.config.ts vite.docker.config.ts vite.runtime.config.ts tsconfig.json tailwind.config.js postcss.config.js composer.json sw-cache-first.php metadata.json) do (
    if exist "%PKG_DIR%\%%F" copy /Y "%PKG_DIR%\%%F" "%INSTALL_DIR%\%%F" >nul 2>&1
)

echo  [OK] Files copied

REM ---- Write .env with the chosen subfolder path ----------------------
echo  Writing .env ...
(
echo VITE_BASE_PATH=/%SUBFOLDER%
echo VITE_API_BASE=/%SUBFOLDER%/api
) > "%INSTALL_DIR%\.env"
echo  [OK] .env written  (VITE_BASE_PATH=/%SUBFOLDER%)

REM ---- Ensure data/ uploads/ logs/ exist -----------------------------
if not exist "%INSTALL_DIR%\data"    mkdir "%INSTALL_DIR%\data"
if not exist "%INSTALL_DIR%\uploads" mkdir "%INSTALL_DIR%\uploads"
if not exist "%INSTALL_DIR%\logs"    mkdir "%INSTALL_DIR%\logs"
echo  [OK] data/, uploads/, logs/ directories confirmed

REM ---- Rebuild frontend if subfolder name differs from 'linknest' -----
if /i NOT "%SUBFOLDER%"=="linknest" (
    echo.
    echo  NOTE: You chose a subfolder name other than 'linknest'.
    echo  The pre-built frontend (dist/) has '/linknest' baked in.
    echo  Checking if Node.js is available to rebuild...
    node --version >nul 2>&1
    if !ERRORLEVEL! EQU 0 (
        echo  Node.js found - rebuilding frontend for /%SUBFOLDER% ...
        cd /d "%INSTALL_DIR%"
        call npm install >nul 2>&1
        call npm run build >nul 2>&1
        if !ERRORLEVEL! EQU 0 (
            echo  [OK] Frontend rebuilt for /%SUBFOLDER%
        ) else (
            echo  [!!] Build failed. The app may not display correctly.
            echo       Try running 'npm install ^&^& npm run build' manually in:
            echo       %INSTALL_DIR%
        )
    ) else (
        echo  [!!] Node.js not found. The pre-built assets use '/linknest'.
        echo       To fix: install Node.js, then run in %INSTALL_DIR%:
        echo         npm install
        echo         npm run build
        echo       OR rename your subfolder to 'linknest' to use the pre-built assets.
    )
)

echo.
echo  =============================================
echo  Deployment Complete!
echo  =============================================
echo.
echo  1. Open XAMPP Control Panel
echo  2. Click [Start] next to Apache
echo  3. Browse to:  http://localhost/%SUBFOLDER%
echo  4. Default login:  admin / admin123
echo     IMPORTANT: Change the password immediately!
echo.
echo  If you see a 404, make sure mod_rewrite is enabled in XAMPP.
echo  See DEPLOYMENT_README.md for troubleshooting.
echo.
pause
