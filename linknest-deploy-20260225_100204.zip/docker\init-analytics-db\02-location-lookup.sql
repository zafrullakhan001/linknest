-- Geo location lookup table for offline reverse geocoding (lat/lon -> country, region, city)
CREATE TABLE IF NOT EXISTS location_lookup (
    id SERIAL PRIMARY KEY,
    country_code VARCHAR(2) NOT NULL,
    country_name VARCHAR(100) NOT NULL,
    region_name VARCHAR(100),
    city_name VARCHAR(100),
    latitude DECIMAL(10, 7) NOT NULL,
    longitude DECIMAL(10, 7) NOT NULL,
    population INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_location_lookup_coords
ON location_lookup(latitude, longitude);

CREATE INDEX IF NOT EXISTS idx_location_lookup_country
ON location_lookup(country_code);

CREATE UNIQUE INDEX IF NOT EXISTS idx_location_lookup_unique_city
ON location_lookup(country_code, region_name, city_name, latitude, longitude);
