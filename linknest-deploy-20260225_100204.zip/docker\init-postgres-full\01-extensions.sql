-- Create all extensions on first container init (when data dir is empty).
-- Requires shared_preload_libraries = 'timescaledb,pg_cron,pg_stat_statements'
-- (set in docker-compose).

-- TimescaleDB (time-series)
CREATE EXTENSION IF NOT EXISTS timescaledb;

-- pg_cron (scheduled jobs)
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- pg_stat_statements (SQL planning/execution stats)
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;

-- PostGIS (spatial/geographic)
CREATE EXTENSION IF NOT EXISTS postgis;

-- postgres_fdw (foreign data wrapper to other PostgreSQL servers)
CREATE EXTENSION IF NOT EXISTS postgres_fdw;

-- intarray (integer array operators and functions)
CREATE EXTENSION IF NOT EXISTS intarray;
