-- Load full analytics schema (TimescaleDB hypertables, metrics, views, policies)
\i /app/analytics/schema.sql
