-- Add last_seen column to user_geolocations for upsert-style updates
-- (INSERT ... ON CONFLICT (user_id) DO UPDATE SET last_seen = NOW())
ALTER TABLE user_geolocations
ADD COLUMN IF NOT EXISTS last_seen TIMESTAMPTZ DEFAULT NOW();

COMMENT ON COLUMN user_geolocations.last_seen IS 'Last time this user was seen at this location (for upsert updates)';
