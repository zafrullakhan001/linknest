-- Monitorv2 - Advanced Monitoring with TimescaleDB
-- Schema: zmonitoring
-- PostgreSQL with TimescaleDB extension
--
-- To create the database if it does not exist:
--   1. Connect to the 'postgres' database and run:
--      CREATE DATABASE your_db_name WITH ENCODING 'UTF8';
--   2. Connect to your_db_name and run this script.
-- Alternatively, use Setup schema or Restore in the app; the database is created automatically if missing.
--
-- Create schema
CREATE SCHEMA IF NOT EXISTS zmonitoring;

-- Enable TimescaleDB extension if available
CREATE EXTENSION IF NOT EXISTS timescaledb;

-- ============================================
-- MONITORS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS zmonitoring.monitors (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(20) NOT NULL CHECK (type IN ('url', 'keyword', 'port', 'ping')),
    target TEXT NOT NULL,
    port INTEGER,
    keyword TEXT,
    interval_minutes INTEGER DEFAULT 5,
    warning_threshold INTEGER DEFAULT 1,
    consecutive_failures INTEGER DEFAULT 0,
    timeout_seconds INTEGER,
    is_active BOOLEAN DEFAULT TRUE,
    email_notification BOOLEAN DEFAULT FALSE,
    last_notified_status VARCHAR(20),
    legacy_notify_pending BOOLEAN DEFAULT FALSE,
    legacy_email_disabled BOOLEAN DEFAULT FALSE,
    legacy_email_to TEXT,
    legacy_email_cc TEXT,
    legacy_email_from_name VARCHAR(255),
    legacy_email_from_email VARCHAR(255),
    legacy_email_subject_template TEXT,
    legacy_email_body_template TEXT,
    current_status VARCHAR(20) CHECK (current_status IN ('up', 'down', 'warning', 'unknown')),
    last_response_time_ms INTEGER,
    last_checked_at TIMESTAMPTZ,
    uptime_percentage DECIMAL(5,2) DEFAULT 100.00,
    total_checks BIGINT DEFAULT 0,
    failed_checks BIGINT DEFAULT 0,
    tab_name VARCHAR(100) DEFAULT 'General',
    group_name VARCHAR(100) DEFAULT 'Other',
    maintenance_start TIMESTAMPTZ,
    maintenance_end TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for monitors
CREATE INDEX IF NOT EXISTS idx_monitors_type ON zmonitoring.monitors(type);
CREATE INDEX IF NOT EXISTS idx_monitors_status ON zmonitoring.monitors(current_status);
CREATE INDEX IF NOT EXISTS idx_monitors_active ON zmonitoring.monitors(is_active);
CREATE INDEX IF NOT EXISTS idx_monitors_tab_group ON zmonitoring.monitors(tab_name, group_name);
CREATE INDEX IF NOT EXISTS idx_monitors_checked_at ON zmonitoring.monitors(last_checked_at);

-- ============================================
-- MONITOR CHECKS TABLE (TimescaleDB hypertable)
-- ============================================
CREATE TABLE IF NOT EXISTS zmonitoring.monitor_checks (
    id BIGSERIAL,
    monitor_id BIGINT NOT NULL REFERENCES zmonitoring.monitors(id) ON DELETE CASCADE,
    status VARCHAR(20) NOT NULL CHECK (status IN ('up', 'down', 'warning')),
    response_time_ms INTEGER,
    http_code INTEGER,
    details TEXT,
    checked_at TIMESTAMPTZ NOT NULL,
    error_message TEXT,
    dns_lookup_time_ms INTEGER,
    connect_time_ms INTEGER,
    ssl_handshake_time_ms INTEGER,
    ttfb_ms INTEGER, -- Time to first byte
    location VARCHAR(100), -- Geographic location of check
    PRIMARY KEY (id, checked_at)
);

-- Convert to hypertable for time-series data
-- Chunk size: 1 day, retention: configurable (default 90 days)
SELECT create_hypertable('zmonitoring.monitor_checks', 'checked_at', 
    chunk_time_interval => INTERVAL '1 day',
    if_not_exists => TRUE
);

-- Indexes for monitor_checks
CREATE INDEX IF NOT EXISTS idx_checks_monitor_id ON zmonitoring.monitor_checks(monitor_id, checked_at DESC);
CREATE INDEX IF NOT EXISTS idx_checks_status ON zmonitoring.monitor_checks(status, checked_at DESC);
CREATE INDEX IF NOT EXISTS idx_checks_monitor_status ON zmonitoring.monitor_checks(monitor_id, status, checked_at DESC);

-- ============================================
-- MONITOR AGGREGATES (1-hour buckets)
-- ============================================
CREATE TABLE IF NOT EXISTS zmonitoring.monitor_hourly_stats (
    id BIGSERIAL,
    monitor_id BIGINT NOT NULL REFERENCES zmonitoring.monitors(id) ON DELETE CASCADE,
    bucket TIMESTAMPTZ NOT NULL,
    total_checks INTEGER DEFAULT 0,
    up_count INTEGER DEFAULT 0,
    down_count INTEGER DEFAULT 0,
    warning_count INTEGER DEFAULT 0,
    avg_response_time_ms DECIMAL(10,2),
    min_response_time_ms INTEGER,
    max_response_time_ms INTEGER,
    p95_response_time_ms INTEGER,
    p99_response_time_ms INTEGER,
    uptime_percentage DECIMAL(5,2),
    PRIMARY KEY (id, bucket)
);

-- Convert to hypertable
SELECT create_hypertable('zmonitoring.monitor_hourly_stats', 'bucket', 
    chunk_time_interval => INTERVAL '7 days',
    if_not_exists => TRUE
);

CREATE INDEX IF NOT EXISTS idx_hourly_monitor_bucket ON zmonitoring.monitor_hourly_stats(monitor_id, bucket DESC);

-- ============================================
-- MONITOR DAILY STATS
-- ============================================
CREATE TABLE IF NOT EXISTS zmonitoring.monitor_daily_stats (
    id BIGSERIAL,
    monitor_id BIGINT NOT NULL REFERENCES zmonitoring.monitors(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    total_checks INTEGER DEFAULT 0,
    up_count INTEGER DEFAULT 0,
    down_count INTEGER DEFAULT 0,
    warning_count INTEGER DEFAULT 0,
    avg_response_time_ms DECIMAL(10,2),
    min_response_time_ms INTEGER,
    max_response_time_ms INTEGER,
    uptime_percentage DECIMAL(5,2),
    downtime_minutes INTEGER DEFAULT 0,
    PRIMARY KEY (monitor_id, date)
);

CREATE INDEX IF NOT EXISTS idx_daily_monitor_date ON zmonitoring.monitor_daily_stats(monitor_id, date DESC);

-- ============================================
-- NOTIFICATION RULES
-- ============================================
CREATE TABLE IF NOT EXISTS zmonitoring.notification_rules (
    id BIGSERIAL PRIMARY KEY,
    monitor_id BIGINT NOT NULL REFERENCES zmonitoring.monitors(id) ON DELETE CASCADE,
    name VARCHAR(255) DEFAULT 'Notification Rule',
    sort_order INTEGER DEFAULT 0,
    status_trigger VARCHAR(20) NOT NULL CHECK (status_trigger IN ('up', 'down', 'both')),
    time_window_start TIME,
    time_window_end TIME,
    days_of_week VARCHAR(20), -- comma-separated: 0=Sunday, 1=Monday, etc.
    subject_template TEXT NOT NULL DEFAULT '[{app_name} Monitor] {monitor_name} Status: {status}',
    body_template TEXT NOT NULL DEFAULT 'Monitor: {monitor_name}\nStatus: {status}\nTime: {time}\nDetails: {details}',
    from_name VARCHAR(255),
    from_email VARCHAR(255),
    cc_emails TEXT,
    is_enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_rules_monitor_id ON zmonitoring.notification_rules(monitor_id);
CREATE INDEX IF NOT EXISTS idx_rules_enabled ON zmonitoring.notification_rules(is_enabled);

-- ============================================
-- NOTIFICATION RECIPIENTS
-- ============================================
CREATE TABLE IF NOT EXISTS zmonitoring.notification_recipients (
    id BIGSERIAL PRIMARY KEY,
    rule_id BIGINT NOT NULL REFERENCES zmonitoring.notification_rules(id) ON DELETE CASCADE,
    email VARCHAR(255) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_recipients_rule_id ON zmonitoring.notification_recipients(rule_id);

-- ============================================
-- NOTIFICATION LOGS
-- ============================================
CREATE TABLE IF NOT EXISTS zmonitoring.notification_logs (
    id BIGSERIAL,
    rule_id BIGINT REFERENCES zmonitoring.notification_rules(id) ON DELETE SET NULL,
    monitor_id BIGINT NOT NULL REFERENCES zmonitoring.monitors(id) ON DELETE CASCADE,
    recipient_email VARCHAR(255) NOT NULL,
    status_trigger VARCHAR(20) NOT NULL,
    sent_at TIMESTAMPTZ NOT NULL,
    subject TEXT NOT NULL,
    success BOOLEAN DEFAULT TRUE,
    error_message TEXT,
    PRIMARY KEY (id, sent_at)
);

-- Convert to hypertable
SELECT create_hypertable('zmonitoring.notification_logs', 'sent_at', 
    chunk_time_interval => INTERVAL '7 days',
    if_not_exists => TRUE
);

CREATE INDEX IF NOT EXISTS idx_notif_logs_monitor ON zmonitoring.notification_logs(monitor_id, sent_at DESC);
CREATE INDEX IF NOT EXISTS idx_notif_logs_rule ON zmonitoring.notification_logs(rule_id, sent_at DESC);

-- ============================================
-- USER MONITOR PERMISSIONS
-- ============================================
CREATE TABLE IF NOT EXISTS zmonitoring.user_monitor_permissions (
    user_id INTEGER NOT NULL,
    monitor_id BIGINT NOT NULL REFERENCES zmonitoring.monitors(id) ON DELETE CASCADE,
    can_view BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (user_id, monitor_id)
);

CREATE INDEX IF NOT EXISTS idx_perm_user_id ON zmonitoring.user_monitor_permissions(user_id);
CREATE INDEX IF NOT EXISTS idx_perm_monitor_id ON zmonitoring.user_monitor_permissions(monitor_id);

-- ============================================
-- INCIDENTS TABLE (for tracking outages)
-- ============================================
CREATE TABLE IF NOT EXISTS zmonitoring.incidents (
    id BIGSERIAL PRIMARY KEY,
    monitor_id BIGINT NOT NULL REFERENCES zmonitoring.monitors(id) ON DELETE CASCADE,
    started_at TIMESTAMPTZ NOT NULL,
    ended_at TIMESTAMPTZ,
    duration_seconds INTEGER,
    initial_status VARCHAR(20) NOT NULL,
    root_cause TEXT,
    acknowledged BOOLEAN DEFAULT FALSE,
    acknowledged_by INTEGER,
    acknowledged_at TIMESTAMPTZ,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_incidents_monitor ON zmonitoring.incidents(monitor_id, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_incidents_active ON zmonitoring.incidents(ended_at) WHERE ended_at IS NULL;

-- ============================================
-- MAINTENANCE WINDOWS
-- ============================================
CREATE TABLE IF NOT EXISTS zmonitoring.maintenance_windows (
    id BIGSERIAL PRIMARY KEY,
    monitor_id BIGINT NOT NULL REFERENCES zmonitoring.monitors(id) ON DELETE CASCADE,
    start_time TIMESTAMPTZ NOT NULL,
    end_time TIMESTAMPTZ NOT NULL,
    description TEXT,
    is_recurring BOOLEAN DEFAULT FALSE,
    recurrence_pattern VARCHAR(50), -- 'daily', 'weekly', 'monthly'
    created_by INTEGER,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_maintenance_monitor ON zmonitoring.maintenance_windows(monitor_id, start_time);
-- Note: Cannot use NOW() in index predicate as it's not IMMUTABLE
-- The query planner will use idx_maintenance_monitor effectively
-- CREATE INDEX IF NOT EXISTS idx_maintenance_active ON zmonitoring.maintenance_windows(start_time, end_time) WHERE end_time > NOW();

-- ============================================
-- VIEWS FOR COMMON QUERIES
-- ============================================

-- View: Current monitor status with latest check info
CREATE OR REPLACE VIEW zmonitoring.v_monitor_status AS
SELECT 
    m.*,
    mc.status as latest_status,
    mc.response_time_ms as latest_response_time,
    mc.details as latest_details,
    mc.checked_at as latest_check_time,
    mc.http_code as latest_http_code,
    EXTRACT(EPOCH FROM (NOW() - m.last_checked_at))/60 as minutes_since_check
FROM zmonitoring.monitors m
LEFT JOIN LATERAL (
    SELECT * FROM zmonitoring.monitor_checks 
    WHERE monitor_id = m.id 
    ORDER BY checked_at DESC 
    LIMIT 1
) mc ON true;

-- View: Uptime summary for last 24 hours
CREATE OR REPLACE VIEW zmonitoring.v_uptime_24h AS
SELECT 
    monitor_id,
    COUNT(*) as total_checks,
    COUNT(*) FILTER (WHERE status = 'up') as up_count,
    COUNT(*) FILTER (WHERE status = 'down') as down_count,
    COUNT(*) FILTER (WHERE status = 'warning') as warning_count,
    ROUND(100.0 * COUNT(*) FILTER (WHERE status = 'up') / NULLIF(COUNT(*), 0), 2) as uptime_percentage,
    AVG(response_time_ms) FILTER (WHERE status = 'up') as avg_response_time
FROM zmonitoring.monitor_checks
WHERE checked_at >= NOW() - INTERVAL '24 hours'
GROUP BY monitor_id;

-- View: Active incidents
CREATE OR REPLACE VIEW zmonitoring.v_active_incidents AS
SELECT 
    i.*,
    m.name as monitor_name,
    m.target as monitor_target,
    m.type as monitor_type,
    EXTRACT(EPOCH FROM (NOW() - i.started_at))/60 as duration_minutes
FROM zmonitoring.incidents i
JOIN zmonitoring.monitors m ON i.monitor_id = m.id
WHERE i.ended_at IS NULL;

-- ============================================
-- FUNCTIONS
-- ============================================

-- Function: Update monitor stats after check
CREATE OR REPLACE FUNCTION zmonitoring.update_monitor_stats()
RETURNS TRIGGER AS $$
BEGIN
    -- Update monitors table with latest status
    UPDATE zmonitoring.monitors
    SET 
        current_status = NEW.status,
        last_response_time_ms = NEW.response_time_ms,
        last_checked_at = NEW.checked_at,
        total_checks = total_checks + 1,
        failed_checks = CASE WHEN NEW.status IN ('down', 'warning') THEN failed_checks + 1 ELSE failed_checks END,
        consecutive_failures = CASE 
            WHEN NEW.status IN ('down', 'warning') THEN consecutive_failures + 1 
            ELSE 0 
        END,
        updated_at = NOW()
    WHERE id = NEW.monitor_id;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for update_monitor_stats
DROP TRIGGER IF EXISTS trg_update_monitor_stats ON zmonitoring.monitor_checks;
CREATE TRIGGER trg_update_monitor_stats
    AFTER INSERT ON zmonitoring.monitor_checks
    FOR EACH ROW
    EXECUTE FUNCTION zmonitoring.update_monitor_stats();

-- Function: Calculate uptime percentage for a monitor
CREATE OR REPLACE FUNCTION zmonitoring.calculate_uptime(
    p_monitor_id BIGINT,
    p_start_time TIMESTAMPTZ,
    p_end_time TIMESTAMPTZ
) RETURNS DECIMAL(5,2) AS $$
DECLARE
    v_total INTEGER;
    v_up INTEGER;
    v_uptime DECIMAL(5,2);
BEGIN
    SELECT 
        COUNT(*),
        COUNT(*) FILTER (WHERE status = 'up')
    INTO v_total, v_up
    FROM zmonitoring.monitor_checks
    WHERE monitor_id = p_monitor_id
    AND checked_at BETWEEN p_start_time AND p_end_time;
    
    IF v_total > 0 THEN
        v_uptime := ROUND(100.0 * v_up / v_total, 2);
    ELSE
        v_uptime := 100.00;
    END IF;
    
    RETURN v_uptime;
END;
$$ LANGUAGE plpgsql;

-- Function: Aggregate hourly stats (can be called by a cron job)
CREATE OR REPLACE FUNCTION zmonitoring.aggregate_hourly_stats(
    p_hour TIMESTAMPTZ DEFAULT date_trunc('hour', NOW() - INTERVAL '1 hour')
)
RETURNS INTEGER AS $$
DECLARE
    v_count INTEGER := 0;
BEGIN
    INSERT INTO zmonitoring.monitor_hourly_stats (
        monitor_id, bucket, total_checks, up_count, down_count, warning_count,
        avg_response_time_ms, min_response_time_ms, max_response_time_ms,
        p95_response_time_ms, p99_response_time_ms, uptime_percentage
    )
    SELECT 
        monitor_id,
        p_hour as bucket,
        COUNT(*) as total_checks,
        COUNT(*) FILTER (WHERE status = 'up') as up_count,
        COUNT(*) FILTER (WHERE status = 'down') as down_count,
        COUNT(*) FILTER (WHERE status = 'warning') as warning_count,
        ROUND(AVG(response_time_ms), 2) as avg_response_time_ms,
        MIN(response_time_ms) as min_response_time_ms,
        MAX(response_time_ms) as max_response_time_ms,
        PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY response_time_ms)::INTEGER as p95_response_time_ms,
        PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY response_time_ms)::INTEGER as p99_response_time_ms,
        ROUND(100.0 * COUNT(*) FILTER (WHERE status = 'up') / NULLIF(COUNT(*), 0), 2) as uptime_percentage
    FROM zmonitoring.monitor_checks
    WHERE checked_at >= p_hour
    AND checked_at < p_hour + INTERVAL '1 hour'
    GROUP BY monitor_id
    ON CONFLICT DO NOTHING;
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    RETURN v_count;
END;
$$ LANGUAGE plpgsql;

-- Function: Clean up old data (retention policy)
CREATE OR REPLACE FUNCTION zmonitoring.cleanup_old_data(
    p_checks_retention_days INTEGER DEFAULT 90,
    p_logs_retention_days INTEGER DEFAULT 365
)
RETURNS TABLE (deleted_checks BIGINT, deleted_logs BIGINT, deleted_hourly BIGINT) AS $$
DECLARE
    v_deleted_checks BIGINT;
    v_deleted_logs BIGINT;
    v_deleted_hourly BIGINT;
BEGIN
    -- Delete old check records
    DELETE FROM zmonitoring.monitor_checks
    WHERE checked_at < NOW() - (p_checks_retention_days || ' days')::INTERVAL;
    GET DIAGNOSTICS v_deleted_checks = ROW_COUNT;
    
    -- Delete old notification logs
    DELETE FROM zmonitoring.notification_logs
    WHERE sent_at < NOW() - (p_logs_retention_days || ' days')::INTERVAL;
    GET DIAGNOSTICS v_deleted_logs = ROW_COUNT;
    
    -- Delete old hourly stats (keep longer than raw data)
    DELETE FROM zmonitoring.monitor_hourly_stats
    WHERE bucket < NOW() - ((p_checks_retention_days + 365) || ' days')::INTERVAL;
    GET DIAGNOSTICS v_deleted_hourly = ROW_COUNT;
    
    RETURN QUERY SELECT v_deleted_checks, v_deleted_logs, v_deleted_hourly;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- CONTINUOUS AGGREGATES (if TimescaleDB is available)
-- ============================================
-- Note: Continuous aggregates are created separately after schema setup
-- to avoid errors if TimescaleDB version doesn't support them
-- 
-- To create continuous aggregates manually, run:
--
-- CREATE MATERIALIZED VIEW zmonitoring.monitor_stats_1hour
-- WITH (timescaledb.continuous) AS
-- SELECT
--     time_bucket('1 hour', checked_at) as bucket,
--     monitor_id,
--     COUNT(*) as total_checks,
--     COUNT(*) FILTER (WHERE status = 'up') as up_count,
--     COUNT(*) FILTER (WHERE status = 'down') as down_count,
--     COUNT(*) FILTER (WHERE status = 'warning') as warning_count,
--     AVG(response_time_ms) as avg_response_time,
--     MIN(response_time_ms) as min_response_time,
--     MAX(response_time_ms) as max_response_time
-- FROM zmonitoring.monitor_checks
-- GROUP BY time_bucket('1 hour', checked_at), monitor_id
-- WITH NO DATA;
--
-- Then add policy:
-- SELECT add_continuous_aggregate_policy('zmonitoring.monitor_stats_1hour',
--     start_offset => INTERVAL '1 month',
--     end_offset => INTERVAL '1 hour',
--     schedule_interval => INTERVAL '1 hour'
-- );

-- ============================================
-- DEFAULT DATA
-- ============================================

-- Insert a sample monitor for testing (optional, can be removed)
-- INSERT INTO zmonitoring.monitors (name, type, target, interval_minutes, tab_name, group_name)
-- VALUES ('Google', 'url', 'https://www.google.com', 5, 'General', 'Other');
