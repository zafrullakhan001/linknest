﻿#!/usr/bin/env bash
# ==========================================================
#  LinkNest XAMPP / Apache Deployment Script (Linux / macOS)
#  Works in ANY htdocs subfolder - you choose the name!
# ==========================================================
set -euo pipefail

PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo "  ============================================="
echo "     LinkNest - XAMPP Deployment (Linux/macOS)"
echo "  ============================================="
echo ""

# ---- Ask for XAMPP location -------------------------------------------
read -rp "  XAMPP install path [/opt/lampp]: " XAMPP_ROOT
XAMPP_ROOT="${XAMPP_ROOT:-/opt/lampp}"
HTDOCS="$XAMPP_ROOT/htdocs"

# ---- Ask for subfolder name -------------------------------------------
read -rp "  Install subfolder inside htdocs [linknest]: " SUBFOLDER
SUBFOLDER="${SUBFOLDER:-linknest}"

INSTALL_DIR="$HTDOCS/$SUBFOLDER"
echo ""
echo "  XAMPP root  : $XAMPP_ROOT"
echo "  Install dir : $INSTALL_DIR"
echo "  URL will be : http://localhost/$SUBFOLDER"
echo ""

if [ ! -d "$HTDOCS" ]; then
    echo "  ERROR: Cannot find $HTDOCS"
    echo "  Make sure XAMPP is installed and you entered the correct path."
    exit 1
fi

if [ -d "$INSTALL_DIR" ]; then
    echo "  Removing old installation..."
    rm -rf "$INSTALL_DIR"
fi
mkdir -p "$INSTALL_DIR"
echo "  [OK] Install directory ready"

echo "  Copying application files..."
cp -r "$PKG_DIR/." "$INSTALL_DIR/"
rm -f "$INSTALL_DIR/deploy-xampp.sh"
rm -f "$INSTALL_DIR/deploy-xampp.bat"
echo "  [OK] Files copied"

echo "  Writing .env ..."
cat > "$INSTALL_DIR/.env" <<ENVEOF
VITE_BASE_PATH=/$SUBFOLDER
VITE_API_BASE=/$SUBFOLDER/api
ENVEOF
echo "  [OK] .env written (VITE_BASE_PATH=/$SUBFOLDER)"

mkdir -p "$INSTALL_DIR/data"
mkdir -p "$INSTALL_DIR/uploads"
mkdir -p "$INSTALL_DIR/logs"

chmod -R 755 "$INSTALL_DIR"
chmod -R 777 "$INSTALL_DIR/data"    2>/dev/null || true
chmod -R 777 "$INSTALL_DIR/uploads" 2>/dev/null || true
chmod -R 777 "$INSTALL_DIR/logs"    2>/dev/null || true
echo "  [OK] Permissions set"

# ---- Rebuild if subfolder differs from 'linknest' --------------------
if [ "$SUBFOLDER" != "linknest" ]; then
    echo ""
    echo "  NOTE: Subfolder is '$SUBFOLDER', not 'linknest'."
    echo "  The pre-built dist/ has '/linknest' baked in. Checking for Node.js..."
    if command -v node &>/dev/null; then
        echo "  Node.js found - rebuilding frontend for /$SUBFOLDER ..."
        cd "$INSTALL_DIR"
        npm install --silent
        npm run build --silent
        echo "  [OK] Frontend rebuilt for /$SUBFOLDER"
    else
        echo "  [!!] Node.js not found. The pre-built assets reference '/linknest'."
        echo "       To fix: install Node.js then run inside $INSTALL_DIR:"
        echo "         npm install && npm run build"
        echo "       OR rename the subfolder to 'linknest' to skip rebuilding."
    fi
fi

echo ""
echo "  ============================================="
echo "  Deployment Complete!"
echo "  ============================================="
echo ""
echo "  1. Start XAMPP: sudo $XAMPP_ROOT/manager-linux-x64.run"
echo "  2. Open: http://localhost/$SUBFOLDER"
echo "  3. Default login: admin / admin123"
echo "     IMPORTANT: Change the password immediately!"
echo ""
