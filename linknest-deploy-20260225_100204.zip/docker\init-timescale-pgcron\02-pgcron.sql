-- Enable pg_cron in the default database (runs on first container init)
CREATE EXTENSION IF NOT EXISTS pg_cron;
