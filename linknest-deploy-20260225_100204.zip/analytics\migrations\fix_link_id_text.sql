-- Fix column type for performance_metrics.link_id
-- Some installations already have link_id as INTEGER; LinkNest link IDs are TEXT (e.g. "link_dash_home").
-- This migration converts link_id to TEXT safely.

DO $$
BEGIN
  -- Only attempt conversion if the column exists and is not already text
  IF EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_name = 'performance_metrics'
      AND column_name = 'link_id'
      AND data_type <> 'text'
  ) THEN
    -- Drop indexes that may depend on the old type (safe if missing)
    EXECUTE 'DROP INDEX IF EXISTS idx_perf_link_time';

    -- Convert existing integer values to text
    EXECUTE 'ALTER TABLE performance_metrics ALTER COLUMN link_id TYPE TEXT USING link_id::text';
  END IF;
END $$;

DO $$
BEGIN
  RAISE NOTICE 'Ensured performance_metrics.link_id is TEXT';
END $$;

