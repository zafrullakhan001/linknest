-- ================================================================================
-- Quick Data Verification Script
-- Run this in your PostgreSQL client to check if data is being captured correctly
-- ================================================================================

-- 1. Check recent metrics (last 5)
SELECT 
    time,
    left(link_url, 40) as url,
    measurement_type,
    username,
    ip_address::text as ip,
    country_code,
    city_name,
    full_response_time as latency_ms
FROM performance_metrics
ORDER BY time DESC
LIMIT 5;

-- 2. Count metrics by username
SELECT 
    COALESCE(username, '(Anonymous)') as username,
    COUNT(*) as total_measurements,
    AVG(full_response_time)::int as avg_latency_ms
FROM performance_metrics
WHERE time >= NOW() - INTERVAL '24 hours'
GROUP BY username
ORDER BY total_measurements DESC;

-- 3. Count metrics by IP address
SELECT 
    COALESCE(ip_address::text, '(NULL)') as ip_address,
    COALESCE(username, '(Anonymous)') as username,
    COUNT(*) as measurements,
    country_code,
    city_name
FROM performance_metrics
WHERE time >= NOW() - INTERVAL '24 hours'
GROUP BY ip_address, username, country_code, city_name
ORDER BY measurements DESC
LIMIT 10;

-- 4. Geolocation quality check
SELECT 
    COUNT(*) as total_metrics,
    COUNT(*) FILTER (WHERE username IS NOT NULL) as has_username,
    COUNT(*) FILTER (WHERE ip_address IS NOT NULL) as has_ip,
    COUNT(*) FILTER (WHERE country_code != 'XX') as has_valid_country,
    COUNT(*) FILTER (WHERE latitude != 0 OR longitude != 0) as has_valid_coords,
    COUNT(*) FILTER (
        WHERE username IS NOT NULL 
        AND ip_address IS NOT NULL 
        AND country_code != 'XX'
    ) as fully_populated
FROM performance_metrics
WHERE time >= NOW() - INTERVAL '24 hours';

-- 5. Check queue processing status
SELECT 
    COUNT(*) as total,
    COUNT(*) FILTER (WHERE processed = FALSE) as pending,
    COUNT(*) FILTER (WHERE processed = TRUE) as processed,
    MAX(created_at) as last_queued,
    MAX(processed_at) as last_processed
FROM metrics_queue;

-- ================================================================================
-- EXPECTED RESULTS:
-- ================================================================================
-- Query 1: Should show recent metrics with username and IP populated
-- Query 2: Should show different usernames (or Anonymous) with their metrics
-- Query 3: Should show IP addresses with their associated usernames
-- Query 4: Should show high percentages for has_username, has_ip, has_valid_country
-- Query 5: Should show pending approaching 0 and processed increasing
-- ================================================================================
