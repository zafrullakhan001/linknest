-- Add username column to performance_metrics table
-- This allows tracking which user experienced specific latencies

-- Add username column to performance_metrics
ALTER TABLE performance_metrics 
ADD COLUMN IF NOT EXISTS username VARCHAR(255);

-- Create an index for username queries
CREATE INDEX IF NOT EXISTS idx_perf_username_time 
ON performance_metrics (username, time DESC) 
WHERE username IS NOT NULL;

-- Add comment to document the column
COMMENT ON COLUMN performance_metrics.username IS 'Username of the user who made the request. Captured from session data for easier drill-down analysis of user-specific performance issues.';

-- Success message
DO $$
BEGIN
    RAISE NOTICE 'Successfully added username column to performance_metrics table';
    RAISE NOTICE 'Created index idx_perf_username_time for efficient username-based queries';
END $$;
