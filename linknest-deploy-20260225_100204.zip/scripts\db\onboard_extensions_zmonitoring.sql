-- Onboard all extensions to database zmonitoring (including pg_cron).
-- For pg_cron to work in zmonitoring, the server must use cron.database_name=zmonitoring.
-- Set PG_CRON_DATABASE=zmonitoring and recreate the PG-full container, then run this script.
-- Run: psql -h localhost -p 5433 -U postgres -d zmonitoring -f onboard_extensions_zmonitoring.sql
-- Or:  docker exec -i PG-full psql -U postgres -d zmonitoring -f /path/to/this/file

CREATE EXTENSION IF NOT EXISTS timescaledb;
CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS postgres_fdw;
CREATE EXTENSION IF NOT EXISTS intarray;
