-- Support ON CONFLICT (user_id) in PHP upserts: one row per user.
-- Remove duplicate user_id rows (keep latest by id), then add UNIQUE(user_id).

-- 1. Delete duplicates: keep the row with the highest id per user_id
DELETE FROM user_geolocations a
USING user_geolocations b
WHERE a.user_id = b.user_id AND a.id < b.id;

-- 2. Add unique constraint so INSERT ... ON CONFLICT (user_id) DO UPDATE works (idempotent)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'user_geolocations'::regclass AND conname = 'user_geolocations_user_id_key'
  ) THEN
    ALTER TABLE user_geolocations ADD CONSTRAINT user_geolocations_user_id_key UNIQUE (user_id);
  END IF;
END $$;
