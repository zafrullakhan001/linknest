-- Add IP address indexes for better anonymous user tracking
-- These indexes improve query performance when filtering by IP address

-- General IP address index for all queries by IP
CREATE INDEX IF NOT EXISTS idx_perf_ip_time 
ON performance_metrics (ip_address, time DESC) 
WHERE ip_address IS NOT NULL;

-- Specific index for anonymous users (not authenticated)
-- This is particularly useful for tracking public/anonymous user performance
CREATE INDEX IF NOT EXISTS idx_perf_anonymous 
ON performance_metrics (ip_address, time DESC) 
WHERE is_authenticated = FALSE;

-- Add comment to document the purpose
COMMENT ON INDEX idx_perf_ip_time IS 'Index for efficient IP-based queries, useful for tracking performance by IP address';
COMMENT ON INDEX idx_perf_anonymous IS 'Index for anonymous user queries - tracks public users by IP address when they are not logged in';

-- Success message
DO $$
BEGIN
    RAISE NOTICE 'Successfully added IP address indexes for anonymous user tracking';
    RAISE NOTICE 'Created idx_perf_ip_time for general IP queries';
    RAISE NOTICE 'Created idx_perf_anonymous for anonymous user queries';
END $$;
