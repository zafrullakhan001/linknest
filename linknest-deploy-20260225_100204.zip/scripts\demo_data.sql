-- ============================================
-- Demo Data SQL Script for LinkNest
-- This script removes existing tiles, links, and monitors
-- and populates the database with fictional demo data for YouTube presentations
-- ============================================

-- Disable foreign key checks temporarily
PRAGMA foreign_keys = OFF;

-- ============================================
-- CLEAR EXISTING DATA
-- ============================================

-- Clear related tables first (respecting dependencies)
DELETE FROM monitor_logs;
DELETE FROM user_monitor_permissions;
DELETE FROM monitors;
DELETE FROM user_link_favorites;
DELETE FROM user_tile_favorites;
DELETE FROM user_tile_permissions;
DELETE FROM rich_text_content;
DELETE FROM links;
DELETE FROM sections;
DELETE FROM tabs;
DELETE FROM tile_arrangements;
DELETE FROM category_arrangements;
DELETE FROM tiles;

-- Reset auto-increment for monitors
DELETE FROM sqlite_sequence WHERE name = "monitors";

-- ============================================
-- INSERT TILES
-- ============================================

INSERT INTO tiles (id, user_id, title, description, emoji, theme_color, "group", position, created_at, visibility) VALUES
('tile_dashboard', NULL, 'Company Dashboard', 'Main operations dashboard for daily activities', '📊', '#3B82F6', 'Main', 0, strftime('%s', 'now'), 'public'),
('tile_dev_tools', NULL, 'Development Tools', 'Essential tools for developers', '⚙️', '#10B981', 'Development', 1, strftime('%s', 'now'), 'public'),
('tile_cloud_services', NULL, 'Cloud Services', 'Access to cloud platforms and services', '☁️', '#8B5CF6', 'Infrastructure', 2, strftime('%s', 'now'), 'public'),
('tile_communication', NULL, 'Communication Hub', 'Team communication and collaboration tools', '💬', '#EC4899', 'Collaboration', 3, strftime('%s', 'now'), 'public'),
('tile_documentation', NULL, 'Documentation Center', 'Company wiki and knowledge base', '📚', '#F59E0B', 'Resources', 4, strftime('%s', 'now'), 'public');

-- ============================================
-- INSERT TABS
-- ============================================

INSERT INTO tabs (id, tile_id, title, position) VALUES
('tab_dashboard_main', 'tile_dashboard', 'Main Tab', 0),
('tab_dev_main', 'tile_dev_tools', 'Development', 0),
('tab_cloud_main', 'tile_cloud_services', 'Cloud Platforms', 0),
('tab_comm_main', 'tile_communication', 'Communication', 0),
('tab_docs_main', 'tile_documentation', 'Documentation', 0);

-- ============================================
-- INSERT SECTIONS
-- ============================================

-- Dashboard sections
INSERT INTO sections (id, tile_id, tab_id, title, position) VALUES
('sec_dashboard_quick', 'tile_dashboard', 'tab_dashboard_main', 'Quick Links', 0),
('sec_dashboard_reports', 'tile_dashboard', 'tab_dashboard_main', 'Reports & Analytics', 1),
('sec_dashboard_admin', 'tile_dashboard', 'tab_dashboard_main', 'Admin Tools', 2);

-- Development Tools sections
INSERT INTO sections (id, tile_id, tab_id, title, position) VALUES
('sec_dev_code', 'tile_dev_tools', 'tab_dev_main', 'Code Repositories', 0),
('sec_dev_ci', 'tile_dev_tools', 'tab_dev_main', 'CI/CD Pipelines', 1),
('sec_dev_testing', 'tile_dev_tools', 'tab_dev_main', 'Testing Platforms', 2);

-- Cloud Services sections
INSERT INTO sections (id, tile_id, tab_id, title, position) VALUES
('sec_cloud_aws', 'tile_cloud_services', 'tab_cloud_main', 'AWS Services', 0),
('sec_cloud_azure', 'tile_cloud_services', 'tab_cloud_main', 'Azure Services', 1),
('sec_cloud_gcp', 'tile_cloud_services', 'tab_cloud_main', 'Google Cloud', 2);

-- Communication sections
INSERT INTO sections (id, tile_id, tab_id, title, position) VALUES
('sec_comm_team', 'tile_communication', 'tab_comm_main', 'Team Collaboration', 0),
('sec_comm_video', 'tile_communication', 'tab_comm_main', 'Video Conferencing', 1);

-- Documentation sections
INSERT INTO sections (id, tile_id, tab_id, title, position) VALUES
('sec_docs_wiki', 'tile_documentation', 'tab_docs_main', 'Wiki & Knowledge Base', 0),
('sec_docs_api', 'tile_documentation', 'tab_docs_main', 'API Documentation', 1);

-- ============================================
-- INSERT LINKS
-- ============================================

-- Dashboard - Quick Links
INSERT INTO links (id, section_id, label, url, position, health_status) VALUES
('link_dash_home', 'sec_dashboard_quick', 'Company Homepage', 'https://example.com', 0, 'unknown'),
('link_dash_portal', 'sec_dashboard_quick', 'Employee Portal', 'https://portal.example.com', 1, 'unknown'),
('link_dash_email', 'sec_dashboard_quick', 'Email System', 'https://mail.example.com', 2, 'unknown'),
('link_dash_calendar', 'sec_dashboard_quick', 'Company Calendar', 'https://calendar.example.com', 3, 'unknown');

-- Dashboard - Reports
INSERT INTO links (id, section_id, label, url, position, health_status) VALUES
('link_dash_sales', 'sec_dashboard_reports', 'Sales Dashboard', 'https://reports.example.com/sales', 0, 'unknown'),
('link_dash_hr', 'sec_dashboard_reports', 'HR Analytics', 'https://reports.example.com/hr', 1, 'unknown'),
('link_dash_finance', 'sec_dashboard_reports', 'Finance Reports', 'https://reports.example.com/finance', 2, 'unknown');

-- Dashboard - Admin
INSERT INTO links (id, section_id, label, url, position, health_status) VALUES
('link_dash_admin', 'sec_dashboard_admin', 'Admin Panel', 'https://admin.example.com', 0, 'unknown'),
('link_dash_settings', 'sec_dashboard_admin', 'System Settings', 'https://admin.example.com/settings', 1, 'unknown');

-- Dev Tools - Code Repositories
INSERT INTO links (id, section_id, label, url, position, health_status) VALUES
('link_dev_github', 'sec_dev_code', 'GitHub Organization', 'https://github.com/example-org', 0, 'unknown'),
('link_dev_gitlab', 'sec_dev_code', 'GitLab Projects', 'https://gitlab.com/example', 1, 'unknown'),
('link_dev_bitbucket', 'sec_dev_code', 'Bitbucket Repos', 'https://bitbucket.org/example', 2, 'unknown');

-- Dev Tools - CI/CD
INSERT INTO links (id, section_id, label, url, position, health_status) VALUES
('link_dev_jenkins', 'sec_dev_ci', 'Jenkins', 'https://jenkins.example.com', 0, 'unknown'),
('link_dev_circleci', 'sec_dev_ci', 'CircleCI', 'https://circleci.com/gh/example', 1, 'unknown'),
('link_dev_travis', 'sec_dev_ci', 'Travis CI', 'https://travis-ci.com/example', 2, 'unknown');

-- Dev Tools - Testing
INSERT INTO links (id, section_id, label, url, position, health_status) VALUES
('link_dev_testrail', 'sec_dev_testing', 'TestRail', 'https://testrail.example.com', 0, 'unknown'),
('link_dev_jira', 'sec_dev_testing', 'Jira Test Management', 'https://jira.example.com', 1, 'unknown');

-- Cloud - AWS
INSERT INTO links (id, section_id, label, url, position, health_status) VALUES
('link_cloud_aws_console', 'sec_cloud_aws', 'AWS Console', 'https://console.aws.amazon.com', 0, 'unknown'),
('link_cloud_aws_cloudwatch', 'sec_cloud_aws', 'CloudWatch', 'https://console.aws.amazon.com/cloudwatch', 1, 'unknown'),
('link_cloud_aws_s3', 'sec_cloud_aws', 'S3 Buckets', 'https://s3.console.aws.amazon.com', 2, 'unknown');

-- Cloud - Azure
INSERT INTO links (id, section_id, label, url, position, health_status) VALUES
('link_cloud_azure_portal', 'sec_cloud_azure', 'Azure Portal', 'https://portal.azure.com', 0, 'unknown'),
('link_cloud_azure_devops', 'sec_cloud_azure', 'Azure DevOps', 'https://dev.azure.com/example', 1, 'unknown');

-- Cloud - GCP
INSERT INTO links (id, section_id, label, url, position, health_status) VALUES
('link_cloud_gcp_console', 'sec_cloud_gcp', 'GCP Console', 'https://console.cloud.google.com', 0, 'unknown'),
('link_cloud_gcp_monitoring', 'sec_cloud_gcp', 'GCP Monitoring', 'https://console.cloud.google.com/monitoring', 1, 'unknown');

-- Communication - Team
INSERT INTO links (id, section_id, label, url, position, health_status) VALUES
('link_comm_slack', 'sec_comm_team', 'Slack Workspace', 'https://example.slack.com', 0, 'unknown'),
('link_comm_teams', 'sec_comm_team', 'Microsoft Teams', 'https://teams.microsoft.com', 1, 'unknown'),
('link_comm_discord', 'sec_comm_team', 'Discord Server', 'https://discord.gg/example', 2, 'unknown');

-- Communication - Video
INSERT INTO links (id, section_id, label, url, position, health_status) VALUES
('link_comm_zoom', 'sec_comm_video', 'Zoom', 'https://zoom.us', 0, 'unknown'),
('link_comm_meet', 'sec_comm_video', 'Google Meet', 'https://meet.google.com', 1, 'unknown');

-- Documentation - Wiki
INSERT INTO links (id, section_id, label, url, position, health_status) VALUES
('link_docs_confluence', 'sec_docs_wiki', 'Confluence', 'https://wiki.example.com', 0, 'unknown'),
('link_docs_notion', 'sec_docs_wiki', 'Notion Workspace', 'https://notion.so/example', 1, 'unknown');

-- Documentation - API
INSERT INTO links (id, section_id, label, url, position, health_status) VALUES
('link_docs_swagger', 'sec_docs_api', 'API Swagger Docs', 'https://api.example.com/docs', 0, 'unknown'),
('link_docs_postman', 'sec_docs_api', 'Postman Collection', 'https://postman.com/workspace/example', 1, 'unknown');

-- ============================================
-- INSERT TILE ARRANGEMENTS
-- ============================================

INSERT INTO tile_arrangements (user_id, tile_id, position, group_name) VALUES
(0, 'tile_dashboard', 0, 'Main'),
(0, 'tile_dev_tools', 1, 'Development'),
(0, 'tile_cloud_services', 2, 'Infrastructure'),
(0, 'tile_communication', 3, 'Collaboration'),
(0, 'tile_documentation', 4, 'Resources');

-- ============================================
-- INSERT MONITORS
-- ============================================

INSERT INTO monitors (
    name, type, target, port, keyword, interval, warning_threshold,
    is_active, tab_name, group_name, last_status, created_at, updated_at
) VALUES
('Main Website', 'url', 'https://example.com', NULL, NULL, 5, 1, 1, 'Production', 'Web Services', 'up', strftime('%s', 'now'), strftime('%s', 'now')),
('API Gateway', 'url', 'https://api.example.com/health', NULL, 'healthy', 2, 1, 1, 'Production', 'Web Services', 'up', strftime('%s', 'now'), strftime('%s', 'now')),
('Database Server', 'port', 'db.example.com', 3306, NULL, 5, 2, 1, 'Production', 'Infrastructure', 'up', strftime('%s', 'now'), strftime('%s', 'now')),
('Redis Cache', 'port', 'redis.example.com', 6379, NULL, 5, 1, 1, 'Production', 'Infrastructure', 'up', strftime('%s', 'now'), strftime('%s', 'now')),
('Email Server', 'ping', 'mail.example.com', NULL, NULL, 10, 2, 1, 'Production', 'Infrastructure', 'up', strftime('%s', 'now'), strftime('%s', 'now')),
('Staging Environment', 'url', 'https://staging.example.com', NULL, NULL, 10, 1, 1, 'Staging', 'Web Services', 'up', strftime('%s', 'now'), strftime('%s', 'now')),
('CDN Status', 'url', 'https://cdn.example.com', NULL, NULL, 15, 1, 1, 'Production', 'Web Services', 'up', strftime('%s', 'now'), strftime('%s', 'now')),
('Load Balancer', 'ping', 'lb.example.com', NULL, NULL, 5, 1, 1, 'Production', 'Infrastructure', 'up', strftime('%s', 'now'), strftime('%s', 'now')),
('Monitoring Dashboard', 'url', 'https://monitor.example.com', NULL, 'dashboard', 5, 2, 1, 'Internal', 'Tools', 'up', strftime('%s', 'now'), strftime('%s', 'now')),
('Backup Server', 'port', 'backup.example.com', 22, NULL, 30, 2, 1, 'Infrastructure', 'Storage', 'up', strftime('%s', 'now'), strftime('%s', 'now'));

-- Re-enable foreign key checks
PRAGMA foreign_keys = ON;

-- ============================================
-- END OF SCRIPT
-- ============================================
