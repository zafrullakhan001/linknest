import React, { useRef, useEffect, useState } from 'react';

interface RichTextEditorProps {
    value: string;
    onChange: (value: string) => void;
    placeholder?: string;
    className?: string;
}

const EMOJI_CATEGORIES = {
    servers: ['🖥️', '💾', '🖨️', '📡', '🔄', '⚙️', '🔧', '🛠️', '📦', '🗄️', '🗃️', '📊', '📈', '📉', '🔌', '🔋', '⚡', '🌐', '🌍', '🌎', '🖱️', '⌨️', '🖲️', '💿', '💽', '📀', '📼', '📷', '📸', '📹', '🎥'],
    cloud: ['☁️', '🌥️', '⛅', '🌤️', '☀️', '🌦️', '🌧️', '⛈️', '🌩️', '🌨️', '❄️', '☂️', '☔', '🌈', '🌊', '💧', '💨', '🌪️', '🌀', '🌫️'],
    onprem: ['🏢', '🏭', '🏗️', '🏛️', '🏘️', '🏠', '🏡', '🏚️', '🏙️', '🌆', '🌇', '🌃', '🌉', '🌁', '🗼', '🗽', '⛪', '🕌', '🕍', '🛕'],
    hospital: ['🏥', '⚕️', '🩺', '💊', '💉', '🩹', '🩼', '🦽', '🦼', '🚑', '🚨', '🏨', '👨‍⚕️', '👩‍⚕️', '🧑‍⚕️', '👨‍🔬', '👩‍🔬', '🧑‍🔬', '🔬', '🧪', '🫀', '🫁', '🧠', '🦷', '🦴'],
    technology: ['💻', '⌨️', '🖱️', '🖲️', '🖨️', '🖥️', '📱', '📲', '💾', '💿', '📀', '📼', '📷', '📸', '📹', '🎥', '📽️', '🎞️', '📺', '📻', '📟', '☎️', '📞', '📠', '📧'],
    network: ['🌐', '📡', '📶', '📞', '☎️', '📠', '📧', '📨', '📩', '📤', '📥', '📦', '📪', '📫', '📬', '📭', '📮', '🗳️', '📯', '📜', '🔗', '⛓️', '🔌', '💡', '⚡'],
    security: ['🔐', '🔒', '🔓', '🔑', '🗝️', '🛡️', '⚔️', '🗡️', '🔪', '🛠️', '🔧', '🔩', '⚙️', '⛓️', '🔗', '🔫', '💣', '🧨', '🎯', '🚨', '🚔', '🚓', '👮', '🕵️', '🦹'],
    data: ['📊', '📈', '📉', '📋', '📌', '📍', '🗂️', '📁', '📂', '🗂️', '🗄️', '🗃️', '📑', '📃', '📄', '📜', '📰', '📓', '📔', '📒', '📕', '📗', '📘', '📙', '📚'],
    communication: ['💬', '💭', '🗨️', '🗯️', '💢', '👤', '👥', '🗣️', '👂', '👃', '👀', '👁️', '👄', '💋', '💌', '💍', '💎', '🎁', '🎉', '🎊'],
    popular: ['😀', '😃', '😄', '😁', '😆', '😅', '🤣', '😂', '🙂', '🙃', '😉', '😊', '😇', '🥰', '😍', '🤩', '😘', '😗', '😚', '😙', '😋', '😛', '😜', '🤪', '😝'],
    objects: ['📱', '⌚', '📷', '📹', '🎥', '📺', '📻', '🔊', '🔉', '🔈', '🔇', '📢', '📣', '📯', '🔔', '🔕', '📻', '📡', '💻', '🖥️', '🖨️', '⌨️', '🖱️', '🖲️', '🖱️'],
    symbols: ['❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔', '❣️', '💕', '💞', '💓', '💗', '💖', '💘', '💝', '💟', '☮️', '✝️', '☪️', '🕉️', '☸️', '✡️']
};

export const RichTextEditor: React.FC<RichTextEditorProps> = ({
    value,
    onChange,
    placeholder = 'Enter text...',
    className = ''
}) => {
    const editorRef = useRef<HTMLDivElement>(null);
    const savedRangeRef = useRef<Range | null>(null);
    const isInternalUpdateRef = useRef(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [showEmojiPicker, setShowEmojiPicker] = useState(false);
    const [emojiActiveTab, setEmojiActiveTab] = useState<string>('popular');
    const [emojiSearchTerm, setEmojiSearchTerm] = useState('');

    useEffect(() => {
        // Only update if the change came from outside (not from user input)
        if (editorRef.current && value !== editorRef.current.innerHTML && !isInternalUpdateRef.current) {
            editorRef.current.innerHTML = value || '';
        }
        isInternalUpdateRef.current = false;
    }, [value]);

    const handleInput = () => {
        if (editorRef.current) {
            isInternalUpdateRef.current = true;
            onChange(editorRef.current.innerHTML);
        }
    };

    const saveSelection = () => {
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0 && editorRef.current) {
            const range = selection.getRangeAt(0);
            if (editorRef.current.contains(range.commonAncestorContainer)) {
                savedRangeRef.current = range.cloneRange();
            }
        }
    };

    const restoreSelection = () => {
        if (savedRangeRef.current && editorRef.current) {
            const selection = window.getSelection();
            if (selection) {
                selection.removeAllRanges();
                selection.addRange(savedRangeRef.current);
                editorRef.current.focus();
            }
        } else if (editorRef.current) {
            // No saved selection, create range at end
            const range = document.createRange();
            range.selectNodeContents(editorRef.current);
            range.collapse(false);
            const selection = window.getSelection();
            if (selection) {
                selection.removeAllRanges();
                selection.addRange(range);
            }
            editorRef.current.focus();
        }
    };

    const getCurrentRange = (): Range | null => {
        if (!editorRef.current) return null;

        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0) {
            const range = selection.getRangeAt(0);
            if (editorRef.current.contains(range.commonAncestorContainer)) {
                return range;
            }
        }
        return null;
    };

    const wrapSelection = (tagName: string, attributes: Record<string, string> = {}) => {
        if (!editorRef.current) return;

        editorRef.current.focus();
        restoreSelection();

        const range = getCurrentRange();
        if (!range) {
            // No selection, create range at end
            const newRange = document.createRange();
            newRange.selectNodeContents(editorRef.current);
            newRange.collapse(false);
            const selection = window.getSelection();
            if (selection) {
                selection.removeAllRanges();
                selection.addRange(newRange);
            }
            return;
        }

        if (range.collapsed) {
            // No selection, just insert the element
            const element = document.createElement(tagName);
            Object.entries(attributes).forEach(([key, value]) => {
                if (key === 'style' && typeof value === 'string') {
                    element.setAttribute('style', value);
                } else {
                    element.setAttribute(key, value);
                }
            });
            range.insertNode(element);
            // Move cursor inside
            range.setStart(element, 0);
            range.setEnd(element, 0);
            const selection = window.getSelection();
            if (selection) {
                selection.removeAllRanges();
                selection.addRange(range);
            }
        } else {
            // Has selection, wrap it
            try {
                const element = document.createElement(tagName);
                Object.entries(attributes).forEach(([key, value]) => {
                    if (key === 'style' && typeof value === 'string') {
                        element.setAttribute('style', value);
                    } else {
                        element.setAttribute(key, value);
                    }
                });
                range.surroundContents(element);
            } catch (e) {
                // surroundContents failed, try alternative
                const contents = range.extractContents();
                const element = document.createElement(tagName);
                Object.entries(attributes).forEach(([key, value]) => {
                    if (key === 'style' && typeof value === 'string') {
                        element.setAttribute('style', value);
                    } else {
                        element.setAttribute(key, value);
                    }
                });
                element.appendChild(contents);
                range.insertNode(element);
            }
        }

        // Use setTimeout to ensure the DOM is updated before calling handleInput
        setTimeout(() => {
            handleInput();
        }, 0);
    };

    const applyFormat = (command: string, value?: string) => {
        if (!editorRef.current) return;

        // Save selection before any operations
        saveSelection();
        
        // Focus and restore selection
        editorRef.current.focus();
        
        // Small delay to ensure focus is set
        setTimeout(() => {
            if (!editorRef.current) return;
            
            restoreSelection();
            
            // Ensure we have a valid selection
            const selection = window.getSelection();
            if (!selection || selection.rangeCount === 0) {
                // No selection, create one at the end
                const range = document.createRange();
                range.selectNodeContents(editorRef.current);
                range.collapse(false);
                selection?.removeAllRanges();
                selection?.addRange(range);
            }

            try {
                // Execute the command
                const success = document.execCommand(command, false, value);
                
                if (!success) {
                    console.warn(`Format command failed: ${command}`);
                }
                
                // Update the value after formatting
                setTimeout(() => {
                    handleInput();
                    // Save selection again after formatting
                    saveSelection();
                }, 0);
            } catch (e) {
                console.error(`Format command error: ${command}`, e);
            }
        }, 10);
    };

    const applyFontSize = (size: string) => {
        const sizeMap: Record<string, string> = {
            '1': '0.75rem',
            '2': '0.875rem',
            '3': '1rem',
            '4': '1.125rem',
            '5': '1.25rem',
            '6': '1.5rem',
            '7': '2rem'
        };
        const fontSize = sizeMap[size] || sizeMap['3'];
        wrapSelection('span', { style: `font-size: ${fontSize};` });
    };

    const applyFontFamily = (font: string) => {
        wrapSelection('span', { style: `font-family: ${font};` });
    };

    const applyHeading = (level: string) => {
        const tagName = `h${level}`;
        wrapSelection(tagName, {});
    };

    const insertLink = () => {
        if (!editorRef.current) return;

        editorRef.current.focus();
        restoreSelection();

        const selection = window.getSelection();
        const selectedText = selection && selection.rangeCount > 0 ? selection.toString() : '';

        const url = prompt('Enter URL:', selectedText || '');
        if (url && url.trim()) {
            const linkText = selectedText || url;
            const linkUrl = url.startsWith('http://') || url.startsWith('https://') ? url : `https://${url}`;

            const range = getCurrentRange();
            if (range) {
                if (!range.collapsed && selectedText) {
                    // Replace selected text with link
                    range.deleteContents();
                    const link = document.createElement('a');
                    link.href = linkUrl;
                    link.target = '_blank';
                    link.rel = 'noopener noreferrer';
                    link.textContent = linkText;
                    range.insertNode(link);
                    range.collapse(false);
                } else {
                    // Insert link at cursor
                    const link = document.createElement('a');
                    link.href = linkUrl;
                    link.target = '_blank';
                    link.rel = 'noopener noreferrer';
                    link.textContent = linkText;
                    range.insertNode(link);
                    range.collapse(false);
                }
                const sel = window.getSelection();
                if (sel) {
                    sel.removeAllRanges();
                    sel.addRange(range);
                }
                setTimeout(() => {
                    handleInput();
                }, 0);
            }
        }
    };

    const insertHTML = (html: string) => {
        if (!editorRef.current) return;

        editorRef.current.focus();
        restoreSelection();

        const range = getCurrentRange();
        if (range) {
            if (!range.collapsed) {
                range.deleteContents();
            }
            const div = document.createElement('div');
            div.innerHTML = html;
            const fragment = document.createDocumentFragment();
            while (div.firstChild) {
                fragment.appendChild(div.firstChild);
            }
            range.insertNode(fragment);
            range.collapse(false);
            setTimeout(() => {
                handleInput();
            }, 0);
        } else {
            // No range, insert at end
            const newRange = document.createRange();
            newRange.selectNodeContents(editorRef.current);
            newRange.collapse(false);
            const div = document.createElement('div');
            div.innerHTML = html;
            const fragment = document.createDocumentFragment();
            while (div.firstChild) {
                fragment.appendChild(div.firstChild);
            }
            newRange.insertNode(fragment);
            newRange.collapse(false);
            const selection = window.getSelection();
            if (selection) {
                selection.removeAllRanges();
                selection.addRange(newRange);
            }
            setTimeout(() => {
                handleInput();
            }, 0);
        }
    };

    const insertDate = () => {
        const now = new Date();
        const dateStr = now.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
        insertHTML(`<span style="font-weight: 600;">${dateStr}</span>`);
    };

    const insertTime = () => {
        const now = new Date();
        const timeStr = now.toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit'
        });
        insertHTML(`<span style="font-weight: 600;">${timeStr}</span>`);
    };

    const insertEmoji = (emoji: string) => {
        insertHTML(emoji);
        setShowEmojiPicker(false);
    };

    const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        // Validate file type
        const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/svg+xml', 'image/webp'];
        if (!allowedTypes.includes(file.type)) {
            alert('Invalid file type. Allowed: JPEG, PNG, GIF, SVG, WebP');
            return;
        }

        // Validate file size (max 5MB)
        const maxSize = 5 * 1024 * 1024; // 5MB
        if (file.size > maxSize) {
            alert('File size too large. Maximum size: 5MB');
            return;
        }

        // Create form data
        const formData = new FormData();
        formData.append('image', file);

        try {
            // Resolve API base dynamically (same pattern as other services)
            let apiBase = '/api';
            if (typeof window !== 'undefined') {
                const path = window.location.pathname || '';
                if (path !== '/' && path.length > 1) {
                    const cleanPath = path.replace(/\/[^/]*$/, '').replace(/\/$/, '');
                    if (cleanPath && cleanPath !== '/') {
                        apiBase = `${cleanPath}/api`;
                    }
                }
            }
            
            const response = await fetch(`${apiBase}/uploads.php/rich-text-image`, {
                method: 'POST',
                body: formData,
                credentials: 'include'
            });

            if (!response.ok) {
                const error = await response.json().catch(() => ({ error: 'Upload failed' }));
                throw new Error(error.error || 'Upload failed');
            }

            const data = await response.json();
            if (data.success && data.url) {
                // Insert image at cursor position
                const img = document.createElement('img');
                img.src = data.url;
                img.style.maxWidth = '100%';
                img.style.height = 'auto';
                img.alt = file.name;

                editorRef.current?.focus();
                restoreSelection();

                const range = getCurrentRange();
                if (range) {
                    if (!range.collapsed) {
                        range.deleteContents();
                    }
                    range.insertNode(img);
                    range.collapse(false);
                    const selection = window.getSelection();
                    if (selection) {
                        selection.removeAllRanges();
                        selection.addRange(range);
                    }
                    setTimeout(() => {
                        handleInput();
                    }, 0);
                }
            } else {
                throw new Error(data.error || 'Upload failed');
            }
        } catch (error) {
            console.error('Image upload error:', error);
            alert(`Failed to upload image: ${error instanceof Error ? error.message : 'Unknown error'}`);
        } finally {
            // Reset file input
            if (fileInputRef.current) {
                fileInputRef.current.value = '';
            }
        }
    };

    const emojiCategories = [
        { id: 'popular', name: 'Popular', emojis: EMOJI_CATEGORIES.popular },
        { id: 'servers', name: 'Servers', emojis: EMOJI_CATEGORIES.servers },
        { id: 'cloud', name: 'Cloud', emojis: EMOJI_CATEGORIES.cloud },
        { id: 'technology', name: 'Tech', emojis: EMOJI_CATEGORIES.technology },
        { id: 'network', name: 'Network', emojis: EMOJI_CATEGORIES.network },
        { id: 'security', name: 'Security', emojis: EMOJI_CATEGORIES.security },
        { id: 'data', name: 'Data', emojis: EMOJI_CATEGORIES.data },
        { id: 'hospital', name: 'Medical', emojis: EMOJI_CATEGORIES.hospital },
        { id: 'onprem', name: 'On-Prem', emojis: EMOJI_CATEGORIES.onprem },
        { id: 'communication', name: 'Chat', emojis: EMOJI_CATEGORIES.communication },
        { id: 'objects', name: 'Objects', emojis: EMOJI_CATEGORIES.objects },
        { id: 'symbols', name: 'Symbols', emojis: EMOJI_CATEGORIES.symbols }
    ];

    const allEmojis = emojiCategories.flatMap(cat => cat.emojis);
    const uniqueEmojis = Array.from(new Set(allEmojis));

    const filteredEmojis = emojiSearchTerm
        ? uniqueEmojis.filter(emoji => emoji.includes(emojiSearchTerm))
        : emojiCategories.find(cat => cat.id === emojiActiveTab)?.emojis || [];

    return (
        <div className={`rich-text-editor ${className}`}>
            {/* Toolbar */}
            <div
                className="flex flex-wrap items-center gap-1 p-2 bg-slate-100 dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 rounded-t-lg border-b-0"
                onMouseDown={(e) => e.preventDefault()}
            >
                {/* Text Formatting */}
                <div className="flex items-center gap-1 border-r border-slate-300 dark:border-slate-600 pr-2 mr-1">
                    <button
                        type="button"
                        onMouseDown={(e) => {
                            e.preventDefault();
                            saveSelection();
                        }}
                        onClick={(e) => {
                            e.preventDefault();
                            applyFormat('bold');
                        }}
                        className="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-700 rounded transition-colors"
                        title="Bold"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M6 4h8a4 4 0 014 4 4 4 0 01-4 4H6z" />
                            <path strokeLinecap="round" strokeLinejoin="round" d="M6 12h9a4 4 0 014 4 4 4 0 01-4 4H6z" />
                        </svg>
                    </button>
                    <button
                        type="button"
                        onMouseDown={(e) => {
                            e.preventDefault();
                            saveSelection();
                        }}
                        onClick={(e) => {
                            e.preventDefault();
                            applyFormat('italic');
                        }}
                        className="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-700 rounded transition-colors"
                        title="Italic"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                        </svg>
                    </button>
                    <button
                        type="button"
                        onMouseDown={(e) => {
                            e.preventDefault();
                            saveSelection();
                        }}
                        onClick={(e) => {
                            e.preventDefault();
                            applyFormat('underline');
                        }}
                        className="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-700 rounded transition-colors"
                        title="Underline"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M4 20h16M6 4v8a6 6 0 0012 0V4" />
                        </svg>
                    </button>
                    <button
                        type="button"
                        onMouseDown={(e) => {
                            e.preventDefault();
                            saveSelection();
                        }}
                        onClick={(e) => {
                            e.preventDefault();
                            applyFormat('strikeThrough');
                        }}
                        className="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-700 rounded transition-colors"
                        title="Strikethrough"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M6 12h12M9 6h6M9 18h6" />
                        </svg>
                    </button>
                </div>

                {/* Headings */}
                <div className="flex items-center gap-1 border-r border-slate-300 dark:border-slate-600 pr-2 mr-1">
                    <select
                        onFocus={saveSelection}
                        onMouseDown={(e) => {
                            e.stopPropagation();
                            saveSelection();
                        }}
                        onChange={(e) => {
                            const level = e.target.value;
                            if (level) {
                                applyHeading(level);
                            }
                            e.target.value = '';
                        }}
                        className="text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded px-1.5 py-1 text-slate-700 dark:text-slate-300"
                        defaultValue=""
                    >
                        <option value="">Heading</option>
                        <option value="1">Heading 1</option>
                        <option value="2">Heading 2</option>
                        <option value="3">Heading 3</option>
                        <option value="4">Heading 4</option>
                        <option value="5">Heading 5</option>
                        <option value="6">Heading 6</option>
                    </select>
                </div>

                {/* Subscript/Superscript */}
                <div className="flex items-center gap-1 border-r border-slate-300 dark:border-slate-600 pr-2 mr-1">
                    <button
                        type="button"
                        onMouseDown={(e) => {
                            e.preventDefault();
                            saveSelection();
                        }}
                        onClick={(e) => {
                            e.preventDefault();
                            applyFormat('subscript');
                        }}
                        className="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-700 rounded transition-colors text-xs font-bold"
                        title="Subscript"
                    >
                        x<sub>2</sub>
                    </button>
                    <button
                        type="button"
                        onMouseDown={(e) => {
                            e.preventDefault();
                            saveSelection();
                        }}
                        onClick={(e) => {
                            e.preventDefault();
                            applyFormat('superscript');
                        }}
                        className="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-700 rounded transition-colors text-xs font-bold"
                        title="Superscript"
                    >
                        x<sup>2</sup>
                    </button>
                </div>

                {/* Hyperlink */}
                <div className="flex items-center gap-1 border-r border-slate-300 dark:border-slate-600 pr-2 mr-1">
                    <button
                        type="button"
                        onMouseDown={(e) => {
                            e.preventDefault();
                            saveSelection();
                        }}
                        onClick={(e) => {
                            e.preventDefault();
                            insertLink();
                        }}
                        className="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-700 rounded transition-colors"
                        title="Insert Link"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                        </svg>
                    </button>
                </div>

                {/* Font Size */}
                <div className="flex items-center gap-1 border-r border-slate-300 dark:border-slate-600 pr-2 mr-1">
                    <select
                        onFocus={saveSelection}
                        onMouseDown={(e) => {
                            e.stopPropagation();
                            saveSelection();
                        }}
                        onChange={(e) => {
                            const size = e.target.value;
                            if (size) {
                                applyFontSize(size);
                            }
                            e.target.value = '';
                        }}
                        className="text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded px-1.5 py-1 text-slate-700 dark:text-slate-300"
                        defaultValue=""
                    >
                        <option value="">Size</option>
                        <option value="1">Small</option>
                        <option value="2">Medium-Small</option>
                        <option value="3">Normal</option>
                        <option value="4">Medium-Large</option>
                        <option value="5">Large</option>
                        <option value="6">X-Large</option>
                        <option value="7">XX-Large</option>
                    </select>
                </div>

                {/* Font Family */}
                <div className="flex items-center gap-1 border-r border-slate-300 dark:border-slate-600 pr-2 mr-1">
                    <select
                        onFocus={saveSelection}
                        onMouseDown={(e) => {
                            e.stopPropagation();
                            saveSelection();
                        }}
                        onChange={(e) => {
                            const font = e.target.value;
                            if (font) {
                                applyFontFamily(font);
                            }
                            e.target.value = '';
                        }}
                        className="text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded px-1.5 py-1 text-slate-700 dark:text-slate-300"
                        defaultValue=""
                    >
                        <option value="">Font</option>
                        <option value="Arial">Arial</option>
                        <option value="Helvetica">Helvetica</option>
                        <option value="Times New Roman">Times New Roman</option>
                        <option value="Courier New">Courier New</option>
                        <option value="Verdana">Verdana</option>
                        <option value="Georgia">Georgia</option>
                        <option value="Palatino">Palatino</option>
                        <option value="Garamond">Garamond</option>
                        <option value="Comic Sans MS">Comic Sans MS</option>
                        <option value="Trebuchet MS">Trebuchet MS</option>
                        <option value="Impact">Impact</option>
                    </select>
                </div>

                {/* Text Color */}
                <div className="flex items-center gap-1 border-r border-slate-300 dark:border-slate-600 pr-2 mr-1">
                    <input
                        type="color"
                        onFocus={saveSelection}
                        onMouseDown={(e) => {
                            e.stopPropagation();
                            saveSelection();
                        }}
                        onChange={(e) => {
                            wrapSelection('span', { style: `color: ${e.target.value};` });
                        }}
                        className="w-7 h-7 border border-slate-300 dark:border-slate-600 rounded cursor-pointer"
                        title="Text Color"
                    />
                </div>

                {/* Background Color */}
                <div className="flex items-center gap-1 border-r border-slate-300 dark:border-slate-600 pr-2 mr-1">
                    <input
                        type="color"
                        onFocus={saveSelection}
                        onMouseDown={(e) => {
                            e.stopPropagation();
                            saveSelection();
                        }}
                        onChange={(e) => {
                            wrapSelection('span', { style: `background-color: ${e.target.value};` });
                        }}
                        className="w-7 h-7 border border-slate-300 dark:border-slate-600 rounded cursor-pointer"
                        title="Background Color"
                    />
                </div>

                {/* Alignment */}
                <div className="flex items-center gap-1 border-r border-slate-300 dark:border-slate-600 pr-2 mr-1">
                    <button
                        type="button"
                        onMouseDown={(e) => {
                            e.preventDefault();
                            saveSelection();
                        }}
                        onClick={(e) => {
                            e.preventDefault();
                            applyFormat('justifyLeft');
                        }}
                        className="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-700 rounded transition-colors"
                        title="Align Left"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M3 12h18M3 6h18M3 18h18" />
                        </svg>
                    </button>
                    <button
                        type="button"
                        onMouseDown={(e) => {
                            e.preventDefault();
                            saveSelection();
                        }}
                        onClick={(e) => {
                            e.preventDefault();
                            applyFormat('justifyCenter');
                        }}
                        className="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-700 rounded transition-colors"
                        title="Align Center"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M3 12h18M9 6h6M9 18h6" />
                        </svg>
                    </button>
                    <button
                        type="button"
                        onMouseDown={(e) => {
                            e.preventDefault();
                            saveSelection();
                        }}
                        onClick={(e) => {
                            e.preventDefault();
                            applyFormat('justifyRight');
                        }}
                        className="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-700 rounded transition-colors"
                        title="Align Right"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M3 12h18M3 6h12M3 18h12" />
                        </svg>
                    </button>
                </div>

                {/* Date/Time */}
                <div className="flex items-center gap-1 border-r border-slate-300 dark:border-slate-600 pr-2 mr-1">
                    <button
                        type="button"
                        onMouseDown={(e) => {
                            e.preventDefault();
                            saveSelection();
                        }}
                        onClick={(e) => {
                            e.preventDefault();
                            insertDate();
                        }}
                        className="px-2 py-1 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                        title="Insert Date"
                    >
                        📅 Date
                    </button>
                    <button
                        type="button"
                        onMouseDown={(e) => {
                            e.preventDefault();
                            saveSelection();
                        }}
                        onClick={(e) => {
                            e.preventDefault();
                            insertTime();
                        }}
                        className="px-2 py-1 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                        title="Insert Time"
                    >
                        🕐 Time
                    </button>
                </div>

                {/* Emoji Picker */}
                <div className="flex items-center gap-1 border-r border-slate-300 dark:border-slate-600 pr-2 mr-1 relative">
                    <button
                        type="button"
                        onMouseDown={(e) => {
                            e.preventDefault();
                            saveSelection();
                        }}
                        onClick={(e) => {
                            e.preventDefault();
                            setShowEmojiPicker(!showEmojiPicker);
                        }}
                        className="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-700 rounded transition-colors"
                        title="Insert Emoji"
                    >
                        <span className="text-lg">😀</span>
                    </button>
                    {showEmojiPicker && (
                        <>
                            <div 
                                className="fixed inset-0 z-[9998]" 
                                onClick={() => setShowEmojiPicker(false)}
                            ></div>
                            <div 
                                className="absolute z-[9999] bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 rounded-xl shadow-2xl w-96 max-h-[500px] flex flex-col overflow-hidden"
                                style={{ top: '100%', left: 0, marginTop: '4px' }}
                                onClick={(e) => e.stopPropagation()}
                            >
                                {/* Search */}
                                <div className="p-2 border-b border-slate-100 dark:border-slate-700 bg-gradient-to-r from-slate-50 to-white dark:from-slate-900/50 dark:to-slate-800">
                                    <input
                                        type="text"
                                        value={emojiSearchTerm}
                                        onChange={(e) => {
                                            setEmojiSearchTerm(e.target.value);
                                            if (e.target.value) {
                                                setEmojiActiveTab('');
                                            }
                                        }}
                                        placeholder="Search emojis..."
                                        className="w-full text-sm px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-500 text-slate-900 dark:text-white"
                                        autoFocus
                                    />
                                </div>

                                {/* Tabs */}
                                {!emojiSearchTerm && (
                                    <div className="flex border-b border-slate-200 dark:border-slate-700 overflow-x-auto">
                                        {emojiCategories.map(category => (
                                            <button
                                                key={category.id}
                                                onClick={() => {
                                                    setEmojiActiveTab(category.id);
                                                    setEmojiSearchTerm('');
                                                }}
                                                className={`px-3 py-2 text-xs font-medium whitespace-nowrap border-b-2 transition-colors ${emojiActiveTab === category.id
                                                    ? 'border-brand-500 text-brand-600 dark:text-brand-400 bg-brand-50 dark:bg-brand-900/20'
                                                    : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:border-slate-300 dark:hover:border-slate-600'
                                                    }`}
                                            >
                                                {category.name}
                                            </button>
                                        ))}
                                    </div>
                                )}

                                {/* Emoji Grid */}
                                <div className="flex-1 overflow-y-auto p-3">
                                    {filteredEmojis.length > 0 ? (
                                        <div className="flex flex-wrap gap-1.5">
                                            {filteredEmojis.map((emoji, idx) => (
                                                <button
                                                    key={idx}
                                                    type="button"
                                                    onClick={() => insertEmoji(emoji)}
                                                    className="text-2xl hover:bg-brand-100 dark:hover:bg-brand-900/30 p-2 rounded-lg transition-all hover:scale-110"
                                                >
                                                    {emoji}
                                                </button>
                                            ))}
                                        </div>
                                    ) : emojiSearchTerm ? (
                                        <div className="text-center py-8 text-sm text-slate-500 dark:text-slate-400">
                                            No emojis found. Try a different search term.
                                        </div>
                                    ) : null}
                                </div>

                                {/* Footer */}
                                <div className="p-2 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50 flex items-center justify-center">
                                    <a
                                        href="https://emojipedia.org"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-xs text-brand-600 dark:text-brand-400 hover:text-brand-700 dark:hover:text-brand-300 flex items-center gap-1.5"
                                    >
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-3.5 h-3.5">
                                            <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 6H5.25A2.25 2.25 0 003 8.25v10.5A2.25 2.25 0 005.25 21h10.5A2.25 2.25 0 0018 18.75V10.5m-10.5 6L21 3m0 0h-5.25M21 3v5.25" />
                                        </svg>
                                        Get more emojis from Emojipedia
                                    </a>
                                </div>
                            </div>
                        </>
                    )}
                </div>

                {/* Image Upload */}
                <div className="flex items-center gap-1 border-r border-slate-300 dark:border-slate-600 pr-2 mr-1">
                    <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/jpeg,image/jpg,image/png,image/gif,image/svg+xml,image/webp"
                        onChange={handleImageUpload}
                        className="hidden"
                    />
                    <button
                        type="button"
                        onMouseDown={(e) => {
                            e.preventDefault();
                            saveSelection();
                        }}
                        onClick={(e) => {
                            e.preventDefault();
                            fileInputRef.current?.click();
                        }}
                        className="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-700 rounded transition-colors"
                        title="Insert Image"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
                        </svg>
                    </button>
                </div>

                {/* Clear Formatting */}
                <button
                    type="button"
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={() => {
                        if (!editorRef.current) return;
                        
                        editorRef.current.focus();
                        restoreSelection();
                        
                        const selection = window.getSelection();
                        if (selection && selection.rangeCount > 0) {
                            const range = selection.getRangeAt(0);
                            
                            if (range.collapsed) {
                                // No selection - clear all formatting in the editor
                                const textContent = editorRef.current.textContent || '';
                                editorRef.current.innerHTML = '';
                                const textNode = document.createTextNode(textContent);
                                editorRef.current.appendChild(textNode);
                                
                                // Set cursor at end
                                const newRange = document.createRange();
                                newRange.selectNodeContents(editorRef.current);
                                newRange.collapse(false);
                                selection.removeAllRanges();
                                selection.addRange(newRange);
                            } else {
                                // Has selection - remove formatting from selected text
                                try {
                                    // First try removeFormat
                                    document.execCommand('removeFormat', false);
                                    
                                    // Then remove all inline styles and tags, keeping only text
                                    const selectedContent = range.extractContents();
                                    const textContent = selectedContent.textContent || '';
                                    
                                    // Create a text node with just the text
                                    const textNode = document.createTextNode(textContent);
                                    range.insertNode(textNode);
                                    
                                    // Collapse range after inserted text
                                    range.collapse(false);
                                    selection.removeAllRanges();
                                    selection.addRange(range);
                                } catch (e) {
                                    // Fallback: just extract text content
                                    const selectedContent = range.extractContents();
                                    const textContent = selectedContent.textContent || '';
                                    const textNode = document.createTextNode(textContent);
                                    range.insertNode(textNode);
                                    range.collapse(false);
                                    selection.removeAllRanges();
                                    selection.addRange(range);
                                }
                            }
                            
                            setTimeout(() => {
                                handleInput();
                            }, 0);
                        } else {
                            // No selection - clear all formatting
                            const textContent = editorRef.current.textContent || '';
                            editorRef.current.innerHTML = '';
                            const textNode = document.createTextNode(textContent);
                            editorRef.current.appendChild(textNode);
                            
                            // Set cursor at end
                            const newRange = document.createRange();
                            newRange.selectNodeContents(editorRef.current);
                            newRange.collapse(false);
                            const sel = window.getSelection();
                            if (sel) {
                                sel.removeAllRanges();
                                sel.addRange(newRange);
                            }
                            
                            setTimeout(() => {
                                handleInput();
                            }, 0);
                        }
                    }}
                    className="px-2 py-1 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                    title="Clear Formatting"
                >
                    Clear
                </button>
            </div>

            {/* Editor */}
            <div
                ref={editorRef}
                contentEditable
                onInput={handleInput}
                onBlur={handleInput}
                onMouseUp={saveSelection}
                onKeyUp={saveSelection}
                className="min-h-[60px] bg-slate-50 dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-700 rounded-b-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/50 transition-all"
                style={{
                    whiteSpace: 'pre-wrap',
                    wordBreak: 'break-word'
                }}
                data-placeholder={placeholder}
                suppressContentEditableWarning
            />

            <style>{`
                .rich-text-editor [contenteditable][data-placeholder]:empty:before {
                    content: attr(data-placeholder);
                    color: #94a3b8;
                    pointer-events: none;
                }
                .rich-text-editor [contenteditable]:focus {
                    outline: none;
                }
                .rich-text-editor h1 { font-size: 2em; font-weight: bold; margin: 0.67em 0; }
                .rich-text-editor h2 { font-size: 1.5em; font-weight: bold; margin: 0.75em 0; }
                .rich-text-editor h3 { font-size: 1.17em; font-weight: bold; margin: 0.83em 0; }
                .rich-text-editor h4 { font-size: 1em; font-weight: bold; margin: 1.12em 0; }
                .rich-text-editor h5 { font-size: 0.83em; font-weight: bold; margin: 1.5em 0; }
                .rich-text-editor h6 { font-size: 0.75em; font-weight: bold; margin: 1.67em 0; }
                .rich-text-editor img { max-width: 100%; height: auto; display: block; margin: 0.5em 0; }
            `}</style>
        </div>
    );
};
